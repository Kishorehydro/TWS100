# GRACE TWSA Reconstruction Workflow (Godavari study area)

A modular Python pipeline that reconstructs GRACE-derived Terrestrial
Water Storage Anomalies (TWSA) at every grid cell inside a study-area
polygon, trained on 8 GLDAS NOAH predictors. By default it fits Random
Forest, ANN, and linear-regression/persistence/climatology baselines
(LSTM/BiLSTM are implemented and available but OFF by default -- see
`config.py`'s `models_to_run` -- to cut runtime). It also builds one
area-weighted basin-average series and reconstructs that too, including
a fixed-hyperparameter sensitivity comparison for RF/ANN (see section 6).

**v4 speed fix**: RF/ANN hyperparameters are tuned (full grid search)
ONCE on the cheap basin-average series, then reused directly -- no
per-cell grid search -- at every grid cell (see "Basin-average
reconstruction" below and `config.py`'s `grid_cell_hyperparameter_source`).
This is the main runtime lever for a whole-basin run; a log line and a
`progress.txt` file report how many cells are done and the estimated
time remaining (see section 4).

## 1. Installation

```bash
pip install -r requirements.txt
```

Needs Python 3.10+. TensorFlow and SHAP are the heaviest dependencies;
everything else is standard scientific-Python.

## 2. Input data (as configured in `config.py`)

This is the **v2** version of the pipeline: it assumes the GLDAS-derived
predictor data handed to it is already bias-corrected across any
GLDAS-2.0/2.1-style forcing-product boundary, already in consistent
physical units, and already regridded onto the GRACE/JPL 0.5° grid -- all
done upstream by you, outside this codebase. See the long comment at the
top of `config.py` ("v2 NOTE") for exactly what that means and what to
check before running.

| Role | File | Notes |
|---|---|---|
| GRACE/GRACE-FO target | `GRCTellus.JPL.200204_202508.GLO.RL06.3M.MSCNv04CRI.nc` | JPL CRI-filtered mascons, 0.5°, `lwe_thickness` (cm) |
| Predictors | `cfg.paths.predictor_files` (one or more NetCDFs, chronological order) | your already bias-corrected / unit-fixed / regridded GLDAS-derived data |
| Precipitation | `cfg.paths.imd_precip_nc` | real IMD gridded rainfall file; used wherever it has coverage, GLDAS precipitation is the documented fallback elsewhere |
| Study area | `Godavari_River_Basin.shp` | any CRS; reprojected to EPSG:4326 on load |

Edit the paths in `config.py::PathsConfig`, and double-check
`config.py::VariableNamesConfig` (especially the `imd_*` fields, which are
common-convention guesses, not verified against your actual IMD file) --
or point the `TWSA_CONFIG_FILE` environment variable at a YAML file
overriding any subset of fields.

## 3. Correctness decisions worth knowing before you run this

**JPL gain factor** (target side, unchanged from the original design). The
JPL file ships a `scale_factor` grid whose own `description` attribute
says it is meant to be used WITH the CRI-filtered mascon solution (a
different correction than the CRI coastal-leakage filter already baked
into `lwe_thickness`). Because this workflow reconstructs TWSA per grid
cell rather than one basin-average series, the gain factor is applied
(`data_io.py::load_grace_jpl`): `twsa = lwe_thickness * scale_factor`.

**Predictor concatenation, not bias correction** (predictor side, v2).
If you list more than one file in `cfg.paths.predictor_files`, they are
concatenated by `temporal.py::concatenate_predictor_files` with NO
correction math -- any month present in more than one file takes the
value from whichever file is LATER in the list. The old overlap bias-
correction/splice functions (`compute_overlap_bias_correction`,
`splice_predictor_series`) are still in `temporal.py`, fully documented,
for the case where you ever need to process a not-yet-corrected input --
they are just not called by default anymore.

**Precipitation: real IMD, with a documented GLDAS fallback.**
`temporal.py::build_final_precipitation_series` uses your real IMD file
wherever it has non-missing data for a given month/cell (and that month
is within `cfg.temporal.imd_precip_documented_end`), and falls back to the
predictor file's own (already-corrected) GLDAS precipitation variable
everywhere else. Every month's TRUE source is recorded, per cell, in
`11_precipitation_comparison/precipitation_source_table.csv` -- a month is
never silently mislabeled as IMD-observed.

## 4. Running it

```bash
python pipeline.py                 # full run, every masked grid cell, baseline+RF+ANN (default)
python pipeline.py --max-cells 5    # smoke test: first 5 cells only
python pipeline.py --skip-shap --skip-drought   # faster run, core validation only
python pipeline.py --precip-source GLDAS    # scenario A: GLDAS Rainf_f_tavg only, no IMD
python pipeline.py --precip-source IMD      # scenario B: real IMD where available, GLDAS fallback
python pipeline.py --skip-basin-average     # skip the basin-average + sensitivity step (STEP 4b)
python pipeline.py --models baseline,random_forest,ann,lstm,bilstm   # bring LSTM/BiLSTM back
```

A full run over a basin-sized polygon is computationally heavy: budget
for hours depending on cell count and whether you have a GPU for the
Keras (ANN) models. Use `--max-cells` to validate the setup before
committing to a full run, and consider raising `cfg.models.n_jobs` /
trimming `cfg.models.rf_param_grid` / `ann_param_grid` for a faster first
pass. LSTM/BiLSTM are the most expensive families and are OFF by default
(see the v3 note above); re-enable them with `--models` once you have
time to spare.

**Monitoring a long run (v4)**: every grid cell logs a line like
`PROGRESS: cell 814/2200 done (37.0%). This cell took 11s. Elapsed:
2h31m. Avg: 11.2s/cell. Est. remaining: 3h52m (812 modeled, 2 skipped so
far).` as soon as it finishes, and the SAME line is (over)written to
`outputs/.../progress.txt` -- so you can check `cat outputs/.../progress.txt`
at any time instead of scrolling the log. If you started a run before
this feature was added, it won't appear retroactively; restart with the
updated code to get it.

**Why grid cells are now fast (v4)**: per-fold-per-cell hyperparameter
grid search was the dominant cost of a whole-basin run (by default: 18
RF fits + 1 refit, and 8 full Keras ANN trainings + 1 refit, PER FOLD
PER CELL). `config.py`'s `grid_cell_hyperparameter_source` now defaults
to `"basin_average_tuned"`: the basin-average series (see below) is
tuned ONCE with the full grid search, and that one hyperparameter set is
then used DIRECTLY at every fold of every grid cell -- collapsing the
per-cell cost to 1 RF fit + 1 ANN training per fold. Only the per-grid-
cell CV-fold evaluation and the final-test/reconstruction refits still
run per cell; the expensive search itself runs exactly once. Set
`grid_cell_hyperparameter_source = "per_cell_tuned"` in `config.py` to
restore the original (much slower) per-cell grid search, or
`"manual"` + `manual_fixed_hyperparameters` to supply your own fixed
values without running the basin-average tuning step at all.

## 5. What each module does

| Module | Spec section | Responsibility |
|---|---|---|
| `config.py` | 1 | every path, variable name, time range, hyperparameter grid |
| `utils.py` | 1, 14 | logging, seeding, small helpers |
| `data_io.py` | 1 | load + validate GRACE/predictor-files/IMD/shapefile; gain factor; grid diagnostics |
| `spatial.py` | 2 | polygon masking; alignment check (regridding kept, but off by default -- see config.py v2 note) |
| `temporal.py` | 3 | monthly alignment; predictor concatenation (no correction, v2 default); real IMD + GLDAS precipitation blending; missing-data report; legacy bias-correction/splice functions kept for optional reuse |
| `features.py` | 4, 5 | RH derivation; 24-feature lag table; LSTM/BiLSTM lookback sequences; correlation screening |
| `preprocessing.py` | 3, 6 | training-fold-only imputation and min-max normalization |
| `models.py` | 7 | RF/ANN/LSTM/BiLSTM/linear/baselines + time-ordered hyperparameter search |
| `validation.py` | 7, 8 | per-cell rolling-origin CV, pooled OOF metrics, final-test (2021-2024) |
| `drought.py` | 9 | TWSA-based drought index, event detection, drought-period metrics |
| `interpretation.py` | 11 | SHAP for RF (exact) / ANN / LSTM / BiLSTM (approximate) |
| `reconstruction.py` | 12 | refit on all GRACE-observed months; predict 1948-2024; ensemble |
| `export.py` | 13 | every CSV/NetCDF output, one writer per required output |
| `pipeline.py` | all | orchestrates the above end to end |

## 6. Outputs (`outputs/`)

Numbered subdirectories match the spec's required-outputs list (section
13). `01_reconstructed_twsa/` holds the main deliverable as ONE NetCDF
FILE PER MODEL FAMILY rather than a single file with a model dimension:
`reconstructed_twsa_linear_regression_1948_2024.nc`,
`_random_forest_...`, `_ann_...`, `_lstm_...`, `_bilstm_...`, and
`_ensemble_...` (the unweighted mean across whichever families were
fit) -- each with dims `time x lat x lon` plus a `grace_observed`
boolean flag per time/cell so you can tell reconstruction apart from
observation at a glance. Only the families actually fit for at least one
cell get a file. `02_validation_metrics/` through `12_model_diagnostics/`
hold everything else, as tidy long-format CSVs keyed by
`(lat, lon, fold/model)` so they are easy to filter, pivot, or
re-aggregate.

### Two precipitation scenarios, side by side

`pipeline.py --precip-source GLDAS` and `pipeline.py --precip-source IMD`
each produce a COMPLETE, independent copy of every output above --
reconstruction NetCDFs included -- under its own subfolder:
`outputs/precip_GLDAS/01_reconstructed_twsa/...` vs.
`outputs/precip_IMD/01_reconstructed_twsa/...`. `GLDAS` uses only
GLDAS's own `Rainf_f_tavg` for the whole 1948-2024 record (the IMD file
is not read at all); `IMD` uses real IMD observations wherever available
and GLDAS as the documented fallback (the longstanding default). Run
both to compare the two precipitation choices cell-by-cell, model-by-
model, without either run overwriting the other's files.

### Basin-average reconstruction + hyperparameter sensitivity (`13_basin_average/`)

Every run (unless `--skip-basin-average`) first builds ONE area-weighted
basin-average series -- `basin_average.py`'s `compute_cell_weights`
weights every masked cell by `overlap_fraction x cos(latitude)` (true
surface area on a lat/lon grid, plus the exact fractional polygon overlap
for cells the basin boundary cuts through), renormalized per month/
variable over whichever cells have data that month -- and runs two
things on it, for baseline/RF/ANN only, **before** the per-grid-cell loop
(v4: so its tuned hyperparameters can be reused there -- see "Why grid
cells are now fast" in section 4):

1. **The same pipeline as any grid cell** (rolling-origin CV -> single
   "best" selected hyperparameter -> final test -> 1948-2024
   reconstruction), written into `13_basin_average/` using every normal
   writer, tagged with the sentinel coordinate pair `(0.0, 0.0)` --
   nowhere near the real Godavari grid, so it's unmistakable in any CSV.
   The reconstruction NetCDFs follow the same per-model naming as
   `01_reconstructed_twsa/` (`reconstructed_twsa_<model>_1948_2024.nc`),
   just with a single `(lat=0.0, lon=0.0)` grid point.
2. **A fixed-hyperparameter sensitivity comparison**
   (`basin_average_hparam_sensitivity_metrics.csv` and
   `..._reconstruction.csv`) across 3 preset complexity tiers for
   random_forest and ann -- `config.py`'s `ModelConfig.
   rf_sensitivity_configs` / `ann_sensitivity_configs` (`low_complexity`,
   `medium_complexity`, `high_complexity`), with NO tuning, so any
   accuracy difference reflects only the hyperparameter choice. This is
   for a manuscript figure showing how final-test (2021-2024) RMSE/MAE/
   Pearson-r and the 1948-2024 reconstruction shift with model
   complexity. **Basin-average only** -- grid cells are not re-run
   through these 3 preset tiers. Edit the three tiers directly in
   `config.py` if the manuscript needs different values.

Note the change from earlier versions: grid cells no longer keep their
OWN independently-CV-tuned "best" hyperparameter -- by default (v4) they
all use the SAME hyperparameter set selected here, at the basin-average
level (see section 4's "Why grid cells are now fast"). `grid_cell_hyperparameter_source
= "per_cell_tuned"` in `config.py` restores independent per-cell tuning.

Running this once with `--precip-source GLDAS` and once with
`--precip-source IMD` gives the basin-average comparison (both the
"best-hyperparameter" reconstruction and the 3-tier sensitivity sweep)
for both precipitation scenarios, under their respective
`outputs/precip_GLDAS/13_basin_average/` and
`outputs/precip_IMD/13_basin_average/` folders.

## 7. Known limitations (documented rather than hidden)

- **Leave-one-drought-out**: literal per-event retraining across 5 model
  families x thousands of cells is not computationally tractable here.
  Drought-period metrics instead reuse the already out-of-sample
  (temporal-CV / final-test) predictions -- every drought event is still
  scored by a model that never trained on it, which is the actual
  property the spec is protecting; see `drought.py`'s module docstring.
- **SHAP for neural networks** uses `shap.GradientExplainer` (falling
  back to `shap.KernelExplainer`), both approximations, not exact
  attributions like the RF `TreeExplainer`. This is recorded in every
  exported SHAP row's `method` column.
- **IMD precipitation** (`cfg.precipitation_source = "IMD"` by default in
  this v2 config) substitutes real IMD values wherever they exist and are
  within `cfg.temporal.imd_precip_documented_end`; if `cfg.paths.imd_precip_nc`
  is unset or the file is missing/unreadable, or for any month outside its
  coverage, the pipeline falls back to GLDAS precipitation -- never
  silently labeling a GLDAS-filled month as IMD-observed. Check
  `11_precipitation_comparison/precipitation_source_table.csv` for the
  exact per-month, per-decision source.
- **Regridding is off by default in v2** for the main predictor files
  (`cfg.predictors_already_on_grace_grid = True`), since they're assumed
  already on the GRACE grid; the pipeline only verifies alignment and
  raises a clear error if it's wrong. It still regrids the IMD file by
  default (`cfg.imd_already_on_grace_grid = False`), using the same
  area-weighted block average described in `spatial.py`'s module
  docstring -- not a general-purpose conservative remapper (no xESMF
  dependency), and worth revisiting if your IMD grid doesn't nest cleanly
  into the GRACE grid the way 0.25° GLDAS does.
- **Computational cost** is still the main practical limitation, though
  v4's basin-average-tuned fixed hyperparameters (section 4) removed the
  single biggest cost (per-fold-per-cell grid search). What's left per
  grid cell is: up to 5 model families' CV-fold fits (4 folds), a
  final-test refit, and a full-record (1948-2024) reconstruction refit --
  all with hyperparameters already decided, so no repeated search.
  Profile on a handful of cells (`--max-cells`) before committing to a
  full basin-wide run, watch `outputs/.../progress.txt` once it's
  running, and expect to parallelize across cells (e.g. with `joblib` or
  a job array) for production use -- the per-cell function
  (`validation.run_cell_validation` + `reconstruction.reconstruct_cell`)
  is already a clean, side-effect-free unit of work for that.

## 8. Testing

`tests/test_smoke.py` runs the full pipeline logic (features -> models ->
validation -> drought -> SHAP -> reconstruction -> export) on a small
synthetic dataset (a few grid cells, a few years of fabricated monthly
data) so the code's correctness can be checked quickly without needing
the real multi-gigabyte GLDAS files or a long run. It is not a
scientific validation of the real reconstruction -- it only confirms the
pipeline runs end-to-end and produces outputs of the expected shape.

```bash
python -m pytest tests/ -v
```
