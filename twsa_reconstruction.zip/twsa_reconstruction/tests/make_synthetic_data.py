"""
Generates small, synthetic-but-structurally-realistic GRACE JPL, predictor
(GLDAS-derived, "already corrected" per the v2 pipeline), IMD
precipitation, and study-area-shapefile files for the smoke test in
test_smoke.py. Matches the variable names and conventions that data_io.py
actually checks for (verified against the user's real files), but at a
tiny spatial/temporal extent so the whole pipeline runs in well under a
minute. These two "predictor" files are deliberately generated with the
SAME per-variable seeds/scales (no synthetic bias between them) since the
v2 pipeline no longer bias-corrects -- it assumes that is already true.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import xarray as xr


def _fake_signal(n_time, n_lat, n_lon, seed, seasonal_amp=1.0, trend=0.0, noise=0.1):
    rng = np.random.RandomState(seed)
    t = np.arange(n_time)
    seasonal = seasonal_amp * np.sin(2 * np.pi * t / 12.0)
    base = seasonal + trend * t / n_time
    field = base[:, None, None] + noise * rng.randn(n_time, n_lat, n_lon)
    spatial_pattern = rng.rand(n_lat, n_lon) * 0.5 + 0.75
    return field * spatial_pattern[None, :, :]


def make_grace_jpl(path: Path, lat: np.ndarray, lon: np.ndarray, start="2003-01", end="2024-12"):
    time = pd.date_range(start, end, freq="MS") + pd.Timedelta(days=15)
    n_t, n_la, n_lo = len(time), len(lat), len(lon)

    lwe = _fake_signal(n_t, n_la, n_lo, seed=1, seasonal_amp=15.0, trend=-5.0, noise=2.0).astype(np.float32)
    uncertainty = np.abs(_fake_signal(n_t, n_la, n_lo, seed=2, seasonal_amp=1.0, trend=0.0, noise=0.3)).astype(np.float32) + 1.0
    scale_factor = (np.random.RandomState(3).rand(n_la, n_lo) * 1.5 + 0.7).astype(np.float32)
    land_mask = np.ones((n_la, n_lo), dtype=np.float32)
    gad = _fake_signal(n_t, n_la, n_lo, seed=4, seasonal_amp=2.0, trend=0.0, noise=0.5).astype(np.float32)

    # sprinkle a few missing months, like the real JPL "months_missing" list
    missing_idx = [5, 40, 90]
    for i in missing_idx:
        if i < n_t:
            lwe[i] = -99999.0
            uncertainty[i] = -99999.0

    ds = xr.Dataset(
        {
            "lwe_thickness": (("time", "lat", "lon"), lwe),
            "uncertainty": (("time", "lat", "lon"), uncertainty),
            "scale_factor": (("lat", "lon"), scale_factor),
            "land_mask": (("lat", "lon"), land_mask),
            "GAD": (("time", "lat", "lon"), gad),
        },
        coords={"time": (("time",), np.arange(n_t), {"units": "days since 2002-01-01T00:00:00Z"}),
                "lat": lat, "lon": lon},
    )
    # overwrite time coord with real datetime64 values but keep units attr for realism
    ds = ds.assign_coords(time=time)
    for v in ["lwe_thickness", "uncertainty"]:
        ds[v].attrs["_FillValue"] = -99999.0
        ds[v].attrs["units"] = "cm"
    ds["scale_factor"].attrs["_FillValue"] = -99999.0
    ds["scale_factor"].attrs["units"] = "dimensionless"
    ds["scale_factor"].attrs["description"] = "Gridded scale factors to be used with mascon solution that has the CRI filter applied; based on CLM data from 2002-2009."
    ds.attrs["time_mean_removed"] = "2004.000 to 2009.999"
    ds.attrs["title"] = "SYNTHETIC JPL GRACE and GRACE-FO MASCON RL06.3Mv04 CRI (test fixture)"
    ds.to_netcdf(path)
    return path


def make_gldas_noah(path: Path, lat: np.ndarray, lon: np.ndarray, start: str, end: str, source_attr: str):
    time = pd.date_range(start, end, freq="MS")
    n_t, n_la, n_lo = len(time), len(lat), len(lon)

    def var(seed, **kw):
        return _fake_signal(n_t, n_la, n_lo, seed=seed, **kw).astype(np.float32)

    rainf = np.abs(var(10, seasonal_amp=2e-5, noise=5e-6))
    evap = np.abs(var(11, seasonal_amp=1e-5, noise=3e-6))
    wind = np.abs(var(12, seasonal_amp=1.0, noise=0.3)) + 2.0
    soil_layers = [np.abs(var(13 + i, seasonal_amp=10.0, noise=2.0)) + 50.0 for i in range(4)]
    tair = var(20, seasonal_amp=8.0, noise=1.0) + 298.0
    qair = np.abs(var(21, seasonal_amp=0.003, noise=0.001)) + 0.012
    psurf = var(22, seasonal_amp=200.0, noise=50.0) + 95000.0
    swdown = np.abs(var(23, seasonal_amp=40.0, noise=10.0)) + 180.0
    lwdown = np.abs(var(24, seasonal_amp=20.0, noise=5.0)) + 350.0

    missing_mask_idx = [3, 50]
    data_vars = {
        "Rainf_f_tavg": (("time", "lat", "lon"), rainf),
        "Evap_tavg": (("time", "lat", "lon"), evap),
        "Wind_f_inst": (("time", "lat", "lon"), wind),
        "SoilMoi0_10cm_inst": (("time", "lat", "lon"), soil_layers[0]),
        "SoilMoi10_40cm_inst": (("time", "lat", "lon"), soil_layers[1]),
        "SoilMoi40_100cm_inst": (("time", "lat", "lon"), soil_layers[2]),
        "SoilMoi100_200cm_inst": (("time", "lat", "lon"), soil_layers[3]),
        "Tair_f_inst": (("time", "lat", "lon"), tair),
        "Qair_f_inst": (("time", "lat", "lon"), qair),
        "Psurf_f_inst": (("time", "lat", "lon"), psurf),
        "SWdown_f_tavg": (("time", "lat", "lon"), swdown),
        "LWdown_f_tavg": (("time", "lat", "lon"), lwdown),
    }
    for i in missing_mask_idx:
        if i < n_t:
            for v in data_vars:
                data_vars[v][1][i] = -9999.0

    ds = xr.Dataset(data_vars, coords={"time": time, "lat": lat, "lon": lon})
    ds.attrs["source"] = source_attr
    ds.attrs["institution"] = "NASA GSFC (synthetic test fixture)"
    ds.attrs["missing_value"] = np.float32(-9999.0)
    for v in data_vars:
        ds[v].attrs["missing_value"] = np.float32(-9999.0)
    ds.to_netcdf(path)
    return path


def make_imd_precipitation(path: Path, lat: np.ndarray, lon: np.ndarray, start: str, end: str):
    """
    A synthetic IMD-style gridded precipitation file on a finer-than-GRACE
    native grid (so the pipeline's IMD regrid-to-GRACE-grid path actually
    gets exercised), covering only PART of the full reconstruction window
    and with a few internal gaps -- so the smoke test also exercises the
    "fall back to GLDAS outside IMD coverage" branch of
    temporal.build_final_precipitation_series.
    """
    time = pd.date_range(start, end, freq="MS")
    n_t, n_la, n_lo = len(time), len(lat), len(lon)
    rainfall = np.abs(_fake_signal(n_t, n_la, n_lo, seed=99, seasonal_amp=3.0, noise=1.0)) + 2.0
    rainfall = rainfall.astype(np.float32)

    # a short internal gap, like missing IMD months
    gap_idx = [10, 11, 12]
    for i in gap_idx:
        if i < n_t:
            rainfall[i] = np.nan

    ds = xr.Dataset(
        {"RAINFALL": (("time", "lat", "lon"), rainfall)},
        coords={"time": time, "lat": lat, "lon": lon},
    )
    ds["RAINFALL"].attrs["units"] = "mm/day"
    ds.attrs["title"] = "SYNTHETIC IMD gridded rainfall (test fixture)"
    ds.to_netcdf(path)
    return path


def make_study_area_shapefile(path: Path, lat_bounds, lon_bounds):
    import geopandas as gpd
    from shapely.geometry import box

    poly = box(lon_bounds[0], lat_bounds[0], lon_bounds[1], lat_bounds[1])
    gdf = gpd.GeoDataFrame({"name": ["synthetic_test_basin"]}, geometry=[poly], crs="EPSG:4326")
    gdf.to_file(path)
    return path


def build_all(root: Path) -> dict:
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)

    grace_lat = np.round(np.arange(15.25, 20.25, 0.5), 3)   # 10 points
    grace_lon = np.round(np.arange(78.25, 83.25, 0.5), 3)   # 10 points
    # IMD grid: finer than GRACE (native 0.25deg), NOT pre-regridded --
    # exercises the IMD regrid-to-GRACE-grid path (cfg.imd_already_on_grace_grid=False).
    imd_lat = np.round(np.arange(15.0, 20.5, 0.25), 3)
    imd_lon = np.round(np.arange(78.0, 83.5, 0.25), 3)

    grace_path = make_grace_jpl(root / "GRCTellus.JPL.synthetic.nc", grace_lat, grace_lon)
    # Predictor files are generated DIRECTLY on the GRACE grid, to simulate
    # the user's own already-regridded-to-the-GRACE-grid predictor data
    # (cfg.predictors_already_on_grace_grid=True, the v2 default) -- the
    # pipeline only verifies alignment for these, it does not regrid them.
    gldas21_path = make_gldas_noah(
        root / "GLDAS_NOAH_2000_2024_monthly.nc", grace_lat, grace_lon,
        "2000-01", "2024-12", source_attr="Noah_v3.6 forced with GDAS-AGRMET-GPCPv13rA1",
    )
    gldas20_path = make_gldas_noah(
        root / "GLDAS_NOAH_1948_2014_monthly.nc", grace_lat, grace_lon,
        "1948-01", "2014-12", source_attr="Noah_v3.6 forced with Princeton_V2.2",
    )
    shp_path = make_study_area_shapefile(root / "synthetic_basin.shp", (16.0, 19.0), (79.0, 82.0))

    # IMD covers only part of the reconstruction window -- exercises both
    # the IMD-regrid path (finer native grid than GRACE) and the
    # GLDAS-fallback-outside-IMD-coverage path.
    imd_path = make_imd_precipitation(root / "IMD_precipitation_synthetic.nc", imd_lat, imd_lon, "2001-01", "2020-12")

    return {
        "grace_jpl_nc": str(grace_path),
        # chronological order: historical file first, recent file second --
        # matches config.PathsConfig.predictor_files' expected ordering.
        "predictor_files": [str(gldas20_path), str(gldas21_path)],
        "imd_precip_nc": str(imd_path),
        "study_area_shp": str(shp_path),
    }


if __name__ == "__main__":
    import sys
    out = build_all(Path(sys.argv[1]) if len(sys.argv) > 1 else Path("./synthetic_fixture"))
    print(out)
