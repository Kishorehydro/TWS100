"""
End-to-end smoke test. Builds small synthetic GRACE/predictor/IMD/
shapefile fixtures (see make_synthetic_data.py) and runs the real (v2)
pipeline over a couple of grid cells with trimmed-down hyperparameter
grids/epochs, so every module's logic gets exercised (predictor
concatenation, IMD regridding + precipitation blending, masking, lag/
sequence features, correlation screening, normalization, RF/ANN/LSTM/
BiLSTM training + tuning, temporal CV, final test, drought validation,
SHAP, reconstruction, and every export writer) without needing the real
multi-gigabyte input files or a long run.

This is NOT a scientific validation of the real Godavari reconstruction
-- it only proves the pipeline runs end-to-end on realistic-shaped data
and produces outputs of the expected structure.
"""

import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.make_synthetic_data import build_all  # noqa: E402
from config import Config  # noqa: E402


@pytest.fixture(scope="module")
def synthetic_cfg(tmp_path_factory):
    root = tmp_path_factory.mktemp("twsa_fixture")
    paths = build_all(root)

    cfg = Config()
    cfg.paths.grace_jpl_nc = paths["grace_jpl_nc"]
    cfg.paths.predictor_files = paths["predictor_files"]
    cfg.paths.imd_precip_nc = paths["imd_precip_nc"]
    cfg.paths.study_area_shp = paths["study_area_shp"]
    cfg.paths.output_dir = str(root / "outputs")
    cfg.paths.log_dir = str(root / "logs")
    # The shipped defaults now match one specific user's deployment
    # (humidity_precomputed_var="Qair_f_inst", no surface pressure
    # available; imd_already_on_grace_grid=True, since THEIR IMD file was
    # pre-regridded). Override both back here so the smoke test keeps
    # exercising: (a) the true-relative-humidity derivation path (Qair+
    # Tair+Psurf -> Tetens), since the synthetic predictor fixture has all
    # three; (b) the IMD regrid-to-GRACE-grid path, since the synthetic
    # IMD fixture is deliberately built on a finer, NOT-pre-regridded grid.
    cfg.varnames.humidity_precomputed_var = None
    cfg.imd_already_on_grace_grid = False

    # Trim compute cost for the smoke test while still exercising every path.
    cfg.models.ann_epochs = 15
    cfg.models.ann_patience = 5
    cfg.models.rnn_epochs = 15
    cfg.models.rnn_patience = 5
    cfg.models.ann_param_grid = {"hidden_units": [(8,)], "dropout": [0.0], "learning_rate": [1e-3]}
    cfg.models.rnn_param_grid = {"units": [8], "dropout": [0.0], "learning_rate": [1e-3]}
    cfg.models.rf_param_grid = {"n_estimators": [50], "max_depth": [5], "min_samples_leaf": [1]}
    cfg.features.min_training_months = 24
    cfg.max_grid_cells = 2
    return cfg


def test_full_pipeline_runs_end_to_end(synthetic_cfg):
    import pipeline

    pipeline.run_pipeline(synthetic_cfg, max_cells=synthetic_cfg.max_grid_cells, skip_shap=False, skip_drought=False)

    outdirs = synthetic_cfg.paths.subdirs()

    # v3: one NetCDF file PER MODEL FAMILY, not one combined file with a
    # 'model' dimension -- see export.py::export_reconstruction_netcdf.
    recon_files = sorted(outdirs["reconstruction"].glob("reconstructed_twsa_*_1948_2024.nc"))
    assert recon_files, "No per-model reconstructed TWSA NetCDF files were written."
    found_models = {f.name[len("reconstructed_twsa_"):-len("_1948_2024.nc")] for f in recon_files}
    # v3: lstm/bilstm are OFF by default (see config.py's models_to_run and
    # pipeline.py's v3 note) -- only baseline (linear_regression)/RF/ANN
    # plus their ensemble should be fit for at least one cell.
    assert {"linear_regression", "random_forest", "ann", "ensemble"} <= found_models, found_models
    assert "lstm" not in found_models and "bilstm" not in found_models, found_models

    import xarray as xr
    for f in recon_files:
        ds = xr.open_dataset(f)
        assert "twsa_reconstructed" in ds
        assert "grace_observed" in ds
        assert set(ds["twsa_reconstructed"].dims) == {"time", "lat", "lon"}
        assert ds.sizes["time"] > 0
        assert ds.attrs.get("precipitation_source_policy") == synthetic_cfg.precipitation_source
        ds.close()

    assert (outdirs["validation"] / "foldwise_validation_metrics.csv").exists()
    assert (outdirs["validation"] / "pooled_out_of_fold_predictions.csv").exists()
    assert (outdirs["final_test"] / "final_test_metrics.csv").exists()
    assert (outdirs["hyperparams"] / "selected_hyperparameters.csv").exists()
    assert (outdirs["feature_selection"] / "feature_selection_summary.csv").exists()
    assert (outdirs["correlation"] / "correlation_matrices_long_format.csv").exists()
    assert (outdirs["normalization"] / "normalization_diagnostics.csv").exists()
    assert (outdirs["forcing_consistency"] / "predictor_preprocessing_provenance.csv").exists()
    assert (outdirs["precip_comparison"] / "precipitation_source_table.csv").exists()
    assert (outdirs["diagnostics"] / "model_diagnostics_and_skipped_cells.csv").exists()

    import pandas as pd
    fold_metrics = pd.read_csv(outdirs["validation"] / "foldwise_validation_metrics.csv")
    assert len(fold_metrics) > 0, "No fold metrics were produced -- validation logic likely did not run."
    assert fold_metrics["rmse"].notna().any()

    final_test = pd.read_csv(outdirs["final_test"] / "final_test_metrics.csv")
    assert len(final_test) > 0, "No final-test metrics were produced."

    # --- STEP 4b: basin-average reconstruction + hyperparameter sensitivity ---
    basin_dir = outdirs["basin_average"]
    basin_recon_files = sorted(basin_dir.glob("reconstructed_twsa_*_1948_2024.nc"))
    assert basin_recon_files, "No basin-average per-model reconstructed TWSA NetCDF files were written."
    for f in basin_recon_files:
        ds = xr.open_dataset(f)
        assert set(ds["twsa_reconstructed"].dims) == {"time", "lat", "lon"}
        assert ds.sizes["lat"] == 1 and ds.sizes["lon"] == 1
        assert float(ds["lat"].values[0]) == 0.0 and float(ds["lon"].values[0]) == 0.0, (
            "Basin-average reconstruction should be tagged with the sentinel (0.0, 0.0) coordinate."
        )
        ds.close()

    assert (basin_dir / "foldwise_validation_metrics.csv").exists()
    assert (basin_dir / "basin_average_hparam_sensitivity_metrics.csv").exists()
    assert (basin_dir / "basin_average_hparam_sensitivity_reconstruction.csv").exists()

    sens_metrics = pd.read_csv(basin_dir / "basin_average_hparam_sensitivity_metrics.csv")
    assert len(sens_metrics) > 0, "No basin-average hyperparameter-sensitivity metrics were produced."
    assert set(sens_metrics["config_label"].unique()) == {"low_complexity", "medium_complexity", "high_complexity"}
    assert set(sens_metrics["model"].unique()) <= {"random_forest", "ann"}
    assert sens_metrics["rmse"].notna().any(), "All basin-average sensitivity RMSE values are NaN."
    assert (sens_metrics["n"] > 0).all(), "A sensitivity config was scored on zero final-test samples."

    sens_recon = pd.read_csv(basin_dir / "basin_average_hparam_sensitivity_reconstruction.csv")
    assert len(sens_recon) > 0, "No basin-average hyperparameter-sensitivity reconstruction rows were produced."

    # --- v4: grid cells use FIXED, basin-average-tuned hyperparameters ---
    # (config.py's grid_cell_hyperparameter_source default
    # "basin_average_tuned") -- every grid cell's selected RF/ANN
    # hyperparameters for a given fold must equal the basin average's own
    # hyperparameters for that SAME fold, since the per-cell grid search is
    # now skipped entirely. selected_hyperparameters.csv rows are written
    # per (lat, lon, fold, model); the basin average is tagged with the
    # sentinel (0.0, 0.0) coordinate, which lives in basin_dir's own copy
    # of the same CSV.
    grid_hparams = pd.read_csv(outdirs["hyperparams"] / "selected_hyperparameters.csv")
    basin_hparams = pd.read_csv(basin_dir / "selected_hyperparameters.csv")
    for model in ("random_forest", "ann"):
        grid_rows = grid_hparams[grid_hparams["model"] == model]
        basin_rows = basin_hparams[basin_hparams["model"] == model]
        assert len(grid_rows) > 0 and len(basin_rows) > 0, f"No {model} hyperparameter rows found for grid cells or basin average."
        for fold_i in sorted(grid_rows["fold"].unique()):
            basin_match = basin_rows[basin_rows["fold"] == fold_i]
            if not len(basin_match):
                continue
            expected = basin_match.iloc[0]["params_json"]
            got = grid_rows[grid_rows["fold"] == fold_i]["params_json"].unique()
            assert list(got) == [expected], (
                f"Grid-cell {model} hyperparameters for fold {fold_i} ({list(got)}) do not match "
                f"the basin-average-tuned hyperparameters ({expected}) -- the v4 fixed-hyperparameter "
                "wiring (pipeline.py's _resolve_grid_fixed_hyperparameters / validation.py's "
                "fixed_hyperparameters) is not taking effect."
            )

    # --- v4: progress reporting ---
    progress_path = outdirs["root"] / "progress.txt"
    assert progress_path.exists(), "progress.txt was not written during the per-grid-cell loop."
    progress_text = progress_path.read_text()
    assert progress_text.startswith("PROGRESS:")
    assert "100.0%" in progress_text, f"progress.txt does not reflect completion: {progress_text!r}"


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v", "-s"]))
