"""
data_io.py
==========
Section 1 of the spec: data input and configuration.

Responsibilities:
  - Read the GRACE-derived TWSA target, the already-preprocessed GLDAS-
    derived predictor file(s), the IMD precipitation file, and the
    study-area polygon.
  - Validate that each input has the expected variables/dimensions/time
    coverage before anything downstream touches it.
  - Report basic grid/units/missing-data bookkeeping across inputs (for
    transparency, not to drive any correction -- see the v2 note in
    config.py: bias correction, unit conversion, and regridding of the
    GLDAS-derived predictor data are assumed already done upstream by the
    user).
  - Apply the JPL gain factor to the GRACE target (see config.py for the
    reasoning; re-stated briefly at the call site below). This is on the
    TARGET side and is unchanged from the original workflow.

Everything here is read-only with respect to the source files: outputs are
new xarray Datasets / GeoDataFrames in memory, nothing is modified on disk.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import xarray as xr

from config import Config
from utils import get_logger, PipelineError

log = get_logger()


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------
def validate_dataset(ds: xr.Dataset, required_vars: List[str], required_dims: List[str], name: str) -> None:
    missing_vars = [v for v in required_vars if v not in ds.variables]
    missing_dims = [d for d in required_dims if d not in ds.dims]
    if missing_vars:
        raise PipelineError(f"[{name}] missing required variable(s): {missing_vars}")
    if missing_dims:
        raise PipelineError(f"[{name}] missing required dimension(s): {missing_dims}")
    log.info("[%s] validated: variables=%s dims=%s", name, required_vars, dict(ds.sizes))


def _standardize_monthly_time(ds: xr.Dataset, time_dim: str) -> xr.Dataset:
    """Re-stamp the time coordinate to month-start timestamps (the project-wide
    monthly convention, see config.TemporalConfig.timestamp_convention).

    Some real products (verified: the JPL mascon file) occasionally publish
    TWO raw time-steps that fall inside the same calendar month -- e.g. a
    partial-month solution either side of a data gap (2012-01-01 and
    2012-01-16 both map to 2012-01 in the real Godavari JPL file). After
    rounding to month-start, these become duplicate labels, which breaks
    every later `.reindex()`/`.sel()` by time with "cannot reindex on an
    axis with duplicate labels". Rather than let that surface as a cryptic
    per-cell crash, duplicates are detected here and collapsed with a
    plain mean across whatever time-varying variables exist for that
    month (never silently -- always logged with exactly which months and
    how many raw steps were involved). This is a simple arithmetic mean,
    not a re-derived, uncertainty-weighted combination.
    """
    times = pd.to_datetime(ds[time_dim].values)
    month_start = pd.DatetimeIndex(times).to_period("M").to_timestamp(how="start")
    ds = ds.assign_coords({time_dim: month_start})

    if pd.Index(month_start).has_duplicates:
        counts = pd.Series(month_start).value_counts()
        dup_months = counts[counts > 1].sort_index()
        log.warning(
            "%d calendar month(s) had more than one raw time-step collapse onto the same "
            "month-start label (likely partial-month solutions straddling a data gap). "
            "Averaging the duplicate raw steps for: %s. This affects only the time-varying "
            "variables in this dataset; see data_io.py::_standardize_monthly_time.",
            len(dup_months), [f"{m.strftime('%Y-%m')} (x{n})" for m, n in dup_months.items()],
        )
        # Collapse only the variables that actually vary over time -- naively
        # grouping the whole Dataset would broadcast time-INDEPENDENT
        # variables (e.g. a static lat/lon gain-factor grid) into gaining a
        # spurious time dimension.
        time_vars = [v for v in ds.data_vars if time_dim in ds[v].dims]
        static_vars = [v for v in ds.data_vars if time_dim not in ds[v].dims]
        collapsed = ds[time_vars].groupby(time_dim).mean(dim=time_dim, skipna=True, keep_attrs=True)
        for v in static_vars:
            collapsed[v] = ds[v]
        collapsed.attrs.update(ds.attrs)
        ds = collapsed

    return ds


# ---------------------------------------------------------------------------
# GRACE JPL mascon loader (unchanged from the original workflow)
# ---------------------------------------------------------------------------
def load_grace_jpl(cfg: Config) -> xr.Dataset:
    """
    Load the JPL CRI-filtered mascon product and apply the gain factor.

    lwe_thickness is already a TWS *anomaly* (2004.000-2009.999 mean removed,
    per the file's own `time_mean_removed` attribute) in centimeters. The
    file's `scale_factor` grid is documented (in its own `description`
    attribute) as the gain factor to use WITH this CRI-filtered product --
    it corrects signal damping from the mascon inversion's regularization,
    which is a separate effect from the CRI coastal-leakage correction
    already baked into lwe_thickness. Because this workflow models each
    grid cell individually (not one basin-averaged series, where the
    damping effect would largely cancel), the gain factor is applied here:

        twsa_corrected = lwe_thickness * scale_factor
        uncertainty_corrected = uncertainty * scale_factor

    GAD (the ocean/atmosphere dealiasing term) is left untouched -- it is
    not subject to the same land-mascon inversion damping.
    """
    vn = cfg.varnames
    path = cfg.paths.grace_jpl_nc
    log.info("Loading GRACE JPL mascon file: %s", path)
    ds = xr.open_dataset(path, mask_and_scale=False)

    validate_dataset(
        ds,
        required_vars=[vn.grace_twsa_var, vn.grace_uncertainty_var, vn.grace_scale_factor_var],
        required_dims=[vn.grace_lat, vn.grace_lon, vn.grace_time],
        name="GRACE_JPL",
    )

    fill = vn.grace_fill_value
    twsa_raw = ds[vn.grace_twsa_var].where(ds[vn.grace_twsa_var] != fill)
    uncertainty_raw = ds[vn.grace_uncertainty_var].where(ds[vn.grace_uncertainty_var] != fill)
    gain = ds[vn.grace_scale_factor_var].where(ds[vn.grace_scale_factor_var] != fill)

    twsa_corrected = twsa_raw * gain
    twsa_corrected.attrs.update(
        units="cm",
        long_name="Gain-factor-corrected TWS anomaly (lwe_thickness * scale_factor)",
        gain_factor_applied="True",
        gain_factor_source=vn.grace_scale_factor_var,
    )
    uncertainty_corrected = uncertainty_raw * gain
    uncertainty_corrected.attrs.update(units="cm", gain_factor_applied="True")

    out = xr.Dataset(
        {
            "twsa": twsa_corrected,
            "twsa_uncertainty": uncertainty_corrected,
            "gain_factor": gain,
        },
        coords={
            vn.grace_lat: ds[vn.grace_lat],
            vn.grace_lon: ds[vn.grace_lon],
            vn.grace_time: ds[vn.grace_time],
        },
    )
    if vn.grace_land_mask_var in ds:
        out["grace_land_mask"] = ds[vn.grace_land_mask_var]

    out = out.rename({vn.grace_lat: "lat", vn.grace_lon: "lon", vn.grace_time: "time"})
    out = _standardize_monthly_time(out, "time")
    out.attrs["source_file"] = path
    out.attrs["native_resolution_deg"] = 0.5
    out.attrs["note"] = (
        "lwe_thickness already represents a TWS anomaly with 2004-2009 mean "
        "removed; CRI coastal-leakage correction already applied; gain "
        "factor (scale_factor) applied here on top for grid-cell-scale use."
    )
    log.info(
        "GRACE JPL loaded: %d months (%s to %s), grid %d x %d",
        out.sizes["time"], str(out.time.values[0])[:10], str(out.time.values[-1])[:10],
        out.sizes["lat"], out.sizes["lon"],
    )
    return out


# ---------------------------------------------------------------------------
# Predictor file loader (your already bias-corrected / unit-fixed /
# regridded GLDAS-derived data -- see the v2 note in config.py)
# ---------------------------------------------------------------------------
def load_predictor_file(path: str, cfg: Config, label: str) -> xr.Dataset:
    """
    Load one predictor NetCDF file and standardize it:
      - mask the configured missing-value sentinel to NaN (skipped
        entirely if `cfg.varnames.predictor_missing_value` is None)
      - rename coords to lat/lon/time
      - re-stamp time to month-start
      - sum the configured soil-moisture layers into a single
        `soil_moisture_total`
      - carry through either the configured humidity variable directly (if
        `cfg.varnames.humidity_precomputed_var` is set -- used AS-IS, no
        conversion, whatever physical quantity it actually is) or
        `specific_humidity` + `surface_pressure` (for features.py to
        derive true relative humidity from)

    This function does NOT bias-correct, unit-convert, or regrid anything
    -- per the v2 note in config.py, that is assumed already done to this
    file before it reaches this pipeline. It only validates structure and
    standardizes names/time-stamping so the rest of the pipeline can treat
    every predictor file identically regardless of how many you supply.
    """
    vn = cfg.varnames
    log.info("Loading predictor file (%s): %s", label, path)
    ds = xr.open_dataset(path, mask_and_scale=False)

    base_required = [
        vn.precipitation, vn.temperature, vn.evapotranspiration, vn.wind_speed,
        vn.shortwave_down, vn.longwave_down,
    ] + list(vn.soil_moisture_layers)

    humidity_precomputed = bool(vn.humidity_precomputed_var) and vn.humidity_precomputed_var in ds.variables
    if vn.humidity_precomputed_var:
        if vn.humidity_precomputed_var not in ds.variables:
            raise PipelineError(
                f"[predictor:{label}] cfg.varnames.humidity_precomputed_var='{vn.humidity_precomputed_var}' "
                "is set but that variable is not in this file. Either add it, or set "
                "humidity_precomputed_var=None in config.py to derive true relative humidity "
                "from specific_humidity/surface_pressure instead."
            )
        required = base_required + [vn.humidity_precomputed_var]
    else:
        required = base_required + [vn.specific_humidity, vn.surface_pressure]

    validate_dataset(
        ds, required_vars=required,
        required_dims=[vn.predictor_lat, vn.predictor_lon, vn.predictor_time],
        name=f"predictor:{label}",
    )

    if vn.predictor_missing_value is not None:
        ds = ds.where(ds != vn.predictor_missing_value)  # broadcasts across all data variables

    soil_total = sum(ds[v] for v in vn.soil_moisture_layers)
    soil_total.attrs.update(long_name="Total profile soil moisture (configured layers, summed)")

    keep_vars = [vn.precipitation, vn.temperature, vn.evapotranspiration, vn.wind_speed,
                 vn.shortwave_down, vn.longwave_down]
    if humidity_precomputed:
        keep_vars.append(vn.humidity_precomputed_var)
    else:
        keep_vars += [vn.specific_humidity, vn.surface_pressure]

    out = ds[keep_vars].copy()
    out["soil_moisture_total"] = soil_total
    out = out.rename({vn.predictor_lat: "lat", vn.predictor_lon: "lon", vn.predictor_time: "time"})
    out = _standardize_monthly_time(out, "time")
    out.attrs["source_file"] = path
    out.attrs["label"] = label
    out.attrs["humidity_precomputed"] = str(humidity_precomputed)
    out.attrs["humidity_source_var"] = vn.humidity_precomputed_var if humidity_precomputed else (
        f"derived from {vn.specific_humidity} + {vn.surface_pressure}"
    )
    log.info(
        "Predictor file %s loaded: %d months (%s to %s), grid %d x %d, humidity precomputed=%s (%s)",
        label, out.sizes["time"], str(out.time.values[0])[:10], str(out.time.values[-1])[:10],
        out.sizes["lat"], out.sizes["lon"], humidity_precomputed, out.attrs["humidity_source_var"],
    )
    return out


def load_all_predictor_files(cfg: Config) -> List[xr.Dataset]:
    """Load every file in cfg.paths.predictor_files, in the order given."""
    paths = cfg.paths.predictor_files
    if not paths:
        raise PipelineError("cfg.paths.predictor_files is empty -- add at least one predictor NetCDF path.")
    datasets = []
    for i, path in enumerate(paths):
        datasets.append(load_predictor_file(path, cfg, label=f"file{i}"))
    return datasets


# ---------------------------------------------------------------------------
# IMD precipitation loader
# ---------------------------------------------------------------------------
def load_imd_precipitation(cfg: Config) -> Optional[xr.Dataset]:
    """
    Load the real IMD gridded precipitation file configured at
    cfg.paths.imd_precip_nc, if any. Returns None (with a clear log
    message, never a silent crash) if no path is configured or the file
    cannot be opened/validated -- callers must treat None as "fall back to
    GLDAS precipitation for the entire period" and document that, exactly
    as before.

    NOTE: the variable/coordinate names below
    (cfg.varnames.imd_lat/imd_lon/imd_time/imd_precip_var) are common-
    convention guesses and will likely need correcting to match your
    actual IMD file -- check them in config.py.
    """
    path = cfg.paths.imd_precip_nc
    if not path:
        log.info("No IMD precipitation file configured (cfg.paths.imd_precip_nc is None); "
                 "GLDAS precipitation will be used for the entire period.")
        return None

    vn = cfg.varnames
    log.info("Loading IMD precipitation file: %s", path)
    try:
        ds = xr.open_dataset(path, mask_and_scale=False)
        validate_dataset(
            ds, required_vars=[vn.imd_precip_var],
            required_dims=[vn.imd_lat, vn.imd_lon, vn.imd_time],
            name="IMD_precipitation",
        )
    except Exception as exc:  # pragma: no cover - defensive IO guard
        log.warning(
            "IMD precipitation file at %s could not be loaded/validated (%s). "
            "Falling back to GLDAS precipitation for the entire period.", path, exc,
        )
        return None

    if vn.imd_missing_value is not None:
        ds = ds.where(ds != vn.imd_missing_value)

    out = ds[[vn.imd_precip_var]].rename({
        vn.imd_lat: "lat", vn.imd_lon: "lon", vn.imd_time: "time", vn.imd_precip_var: "precipitation_imd",
    })
    out = _standardize_monthly_time(out, "time")
    out.attrs["source_file"] = path
    log.info(
        "IMD precipitation loaded: %d months (%s to %s), grid %d x %d",
        out.sizes["time"], str(out.time.values[0])[:10], str(out.time.values[-1])[:10],
        out.sizes["lat"], out.sizes["lon"],
    )
    return out


# ---------------------------------------------------------------------------
# Study-area polygon loader
# ---------------------------------------------------------------------------
def load_study_area(cfg: Config):
    import geopandas as gpd

    path = cfg.paths.study_area_shp
    log.info("Loading study-area polygon: %s", path)
    gdf = gpd.read_file(path)
    if gdf.crs is None:
        log.warning("Study-area shapefile has no CRS defined; assuming EPSG:4326.")
        gdf = gdf.set_crs(epsg=4326)
    elif gdf.crs.to_epsg() != 4326:
        log.info("Reprojecting study-area polygon from %s to EPSG:4326.", gdf.crs)
        gdf = gdf.to_crs(epsg=4326)
    if gdf.empty:
        raise PipelineError(f"Study-area shapefile at {path} contains no geometries.")
    log.info("Study area loaded: %d feature(s), bounds=%s", len(gdf), tuple(gdf.total_bounds))
    return gdf


# ---------------------------------------------------------------------------
# Cross-dataset diagnostic report
# ---------------------------------------------------------------------------
@dataclass
class GridDiagnostics:
    name: str
    lat_res: float
    lon_res: float
    lat_range: tuple
    lon_range: tuple
    time_start: str
    time_end: str
    n_months: int
    missing_value_convention: str


def describe_grid(ds: xr.Dataset, name: str, missing_convention: str) -> GridDiagnostics:
    lat = np.sort(ds["lat"].values)
    lon = np.sort(ds["lon"].values)
    lat_res = float(np.round(np.median(np.diff(lat)), 6)) if len(lat) > 1 else float("nan")
    lon_res = float(np.round(np.median(np.diff(lon)), 6)) if len(lon) > 1 else float("nan")
    times = pd.to_datetime(ds["time"].values)
    return GridDiagnostics(
        name=name,
        lat_res=lat_res,
        lon_res=lon_res,
        lat_range=(float(lat.min()), float(lat.max())),
        lon_range=(float(lon.min()), float(lon.max())),
        time_start=str(times.min())[:10],
        time_end=str(times.max())[:10],
        n_months=len(times),
        missing_value_convention=missing_convention,
    )


def report_input_differences(grace_ds: xr.Dataset, predictor_datasets: Dict[str, xr.Dataset], cfg: Config) -> pd.DataFrame:
    """
    Build a one-row-per-dataset diagnostic table of resolution, extent, and
    time coverage for every input -- purely informational (no correction is
    driven by this report; see the v2 note in config.py). Logged and saved
    to outputs/10_forcing_consistency/input_grid_diagnostics.csv by export.py.
    """
    rows = []
    rows.append(describe_grid(
        grace_ds, "GRACE_JPL",
        missing_convention="_FillValue=-99999.0 (masked to NaN on load)",
    ))
    missing_note = (
        f"sentinel={cfg.varnames.predictor_missing_value} (masked to NaN on load)"
        if cfg.varnames.predictor_missing_value is not None else "none applied (assumed already NaN)"
    )
    for label, ds in predictor_datasets.items():
        rows.append(describe_grid(ds, f"predictor:{label}", missing_convention=missing_note))

    df = pd.DataFrame([r.__dict__ for r in rows])
    for _, row in df.iterrows():
        log.info(
            "GRID DIAGNOSTIC | %-20s | res=%.4fx%.4f deg | lat=%s lon=%s | time=%s..%s (%d mo) | missing=%s",
            row["name"], row["lat_res"], row["lon_res"], row["lat_range"], row["lon_range"],
            row["time_start"], row["time_end"], row["n_months"], row["missing_value_convention"],
        )
    predictor_rows = df[df["name"] != "GRACE_JPL"]
    if len(predictor_rows) and (predictor_rows["lat_res"].nunique() > 1 or predictor_rows["lon_res"].nunique() > 1):
        log.warning(
            "Predictor files have DIFFERENT native resolutions from each other (%s). "
            "This pipeline no longer regrids them (see config.py v2 note) -- make sure "
            "this is intentional (e.g. they are already all on the GRACE grid).",
            predictor_rows[["name", "lat_res", "lon_res"]].to_dict("records"),
        )
    return df
