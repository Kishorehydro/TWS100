"""
basin_average.py
=================
Builds an area-weighted BASIN-AVERAGE monthly time series (one pseudo
grid-cell representing the whole masked study area) from every grid
cell's predictors + GRACE TWSA, then:

  1. Runs the SAME per-cell pipeline as any real grid cell (rolling-
     origin CV -> single "best" selected hyperparameter per family ->
     final test -> 1948-2024 reconstruction; see pipeline.py's STEP 4b)
     on this basin-average series, for baseline/random_forest/ann only
     (lstm/bilstm removed from the default pipeline -- see config.py).
     This reuses validation.run_cell_validation / reconstruction.
     reconstruct_cell / export.py's existing writers UNCHANGED, with the
     basin average addressed by the sentinel coordinate pair
     (BASIN_LAT, BASIN_LON) = (0.0, 0.0) -- nowhere near the real
     Godavari grid (~17-22N, ~73-83E), so it is unmistakable in any CSV/
     NetCDF it ends up in and can never collide with a real cell's row.

  2. Runs a FIXED-hyperparameter SENSITIVITY comparison (`run_hparam_
     sensitivity`) across 3 preset complexity tiers for random_forest and
     ann (config.py's ModelConfig.rf_sensitivity_configs /
     ann_sensitivity_configs) -- no tuning, by design: the point is to
     show how final-test accuracy and the 1948-2024 reconstruction change
     with hyperparameter choice, for a manuscript figure. This is basin-
     average-only; every per-grid-cell reconstruction keeps using its own
     nested-CV-selected single "best" hyperparameter set, unchanged.

Weighting
---------
On a regular lat/lon grid, a cell's true surface area is proportional to
cos(latitude) (meridians converge toward the poles). That is combined
with each cell's fractional polygon-overlap with the study-area boundary
(spatial.build_cell_mask's `overlap_df`, already computed for every
masked cell -- ~1.0 for interior cells, less for cells the basin boundary
cuts through) to get each cell's basin-average weight. Weights are
renormalized PER MONTH, PER VARIABLE over whichever cells have non-NaN
data that month/variable, so one cell's missing month does not bias the
average toward whichever cells happen to still have data.
"""

from __future__ import annotations

import json
from typing import Dict, Tuple

import numpy as np
import pandas as pd
import xarray as xr

import features as feat
import models as mdl
import preprocessing as prep
import validation as val
from config import Config
from utils import get_logger, clear_keras_memory

log = get_logger()

# Sentinel "cell" coordinates for the basin average -- see module
# docstring. Chosen far from the real Godavari grid on purpose.
BASIN_LAT = 0.0
BASIN_LON = 0.0


def compute_cell_weights(
    lat_values: np.ndarray, lon_values: np.ndarray, mask: np.ndarray, overlap_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    One row per masked grid cell: lat, lon, weight = overlap_fraction *
    cos(latitude in radians). NOT yet normalized to sum to 1 -- the
    caller (build_basin_average_dataframe) renormalizes per month/
    variable over whichever cells are actually non-NaN that month, since
    a static normalization would silently misweight any month with
    missing data at one or more cells.
    """
    overlap_lookup: Dict[Tuple[float, float], float] = {
        (float(r.lat), float(r.lon)): float(r.overlap_fraction) for r in overlap_df.itertuples()
    }
    rows = []
    for i, lat in enumerate(lat_values):
        for j, lon in enumerate(lon_values):
            if not mask[i, j]:
                continue
            frac = overlap_lookup.get((float(lat), float(lon)), 1.0)
            w = frac * np.cos(np.deg2rad(float(lat)))
            rows.append({"lat": float(lat), "lon": float(lon), "weight": w})
    weights_df = pd.DataFrame(rows)
    log.info(
        "Basin-average weights computed for %d masked grid cell(s) (overlap_fraction x cos(lat)): "
        "min=%.4f, max=%.4f, mean=%.4f.",
        len(weights_df), weights_df["weight"].min(), weights_df["weight"].max(), weights_df["weight"].mean(),
    )
    return weights_df


def build_basin_average_dataframe(
    predictor_ds: xr.Dataset, grace_ds: xr.Dataset, weights_df: pd.DataFrame, cfg: Config,
) -> pd.DataFrame:
    """
    Returns ONE monthly DataFrame (same columns as pipeline.py's per-cell
    build_cell_dataframe: the 8 canonical predictors + 'twsa'), built by
    taking the per-month, per-variable weighted average across every
    masked grid cell, renormalizing weights over whichever cells are
    non-NaN for that month/variable (see module docstring).
    """
    import pipeline as pl  # local import: pipeline.py imports this module too (STEP 4b);
    # by the time this function is actually CALLED (well after both
    # modules finish their own top-level imports), pipeline's own
    # extract_cell_raw_vars is fully available -- see its use below.

    time_index = pd.DatetimeIndex(predictor_ds["time"].values)
    cell_frames = []
    cell_weights = []
    for row in weights_df.itertuples():
        lat, lon, w = float(row.lat), float(row.lon), float(row.weight)
        raw_vars = pl.extract_cell_raw_vars(predictor_ds, cfg, lat, lon)
        df_cell = feat.build_predictor_target_frame(raw_vars, time_index)
        twsa_cell = grace_ds["twsa"].sel(lat=lat, lon=lon)
        twsa_series = pd.Series(twsa_cell.values, index=pd.DatetimeIndex(grace_ds["time"].values))
        df_cell["twsa"] = twsa_series.reindex(df_cell.index)
        cell_frames.append(df_cell)
        cell_weights.append(w)

    log.info("Basin average: aggregating %d masked grid cell(s) into one weighted pseudo-cell "
              "(sentinel coordinates [%.1f, %.1f], not a real grid location).", len(cell_frames), BASIN_LAT, BASIN_LON)

    columns = cell_frames[0].columns
    weights_arr = np.array(cell_weights)
    out = pd.DataFrame(index=time_index, columns=columns, dtype=float)
    for col in columns:
        stacked = np.column_stack([f[col].values for f in cell_frames])  # (n_time, n_cells)
        valid = ~np.isnan(stacked)
        w_bcast = np.broadcast_to(weights_arr, stacked.shape)
        weighted = np.where(valid, stacked * w_bcast, 0.0)
        w_sum = np.where(valid, w_bcast, 0.0).sum(axis=1)
        with np.errstate(invalid="ignore", divide="ignore"):
            avg = np.where(w_sum > 0, weighted.sum(axis=1) / w_sum, np.nan)
        out[col] = avg

    twsa_stack = np.column_stack([f["twsa"].values for f in cell_frames])
    n_contrib = (~np.isnan(twsa_stack)).sum(axis=1)
    n_months_with_data = int((n_contrib > 0).sum())
    log.info(
        "Basin-average TWSA: %d/%d months have at least one contributing GRACE-observed cell "
        "(median %d of %d cells contributing per month that has any data).",
        n_months_with_data, len(time_index),
        int(np.median(n_contrib[n_contrib > 0])) if n_months_with_data else 0, len(cell_frames),
    )
    return out


def run_hparam_sensitivity(df_basin: pd.DataFrame, cfg: Config) -> Dict[str, object]:
    """
    Fixed-hyperparameter sensitivity comparison for random_forest and ann
    on the basin-average series -- see module docstring. Returns:
      {"metrics": DataFrame[model, config_label, hyperparams_json,
                             rmse, mae, pearson_r, n, period],
       "reconstruction": DataFrame[time, model, config_label,
                                    twsa_reconstructed, grace_observed],
       "retained_features": list[str]}
    """
    X_tab_all, y_tab_all = feat.make_tabular_dataset(df_basin, lags=cfg.features.lags_tabular)

    dev_start, dev_end = cfg.temporal.grace_development_start, cfg.temporal.grace_development_end
    ft_start, ft_end = cfg.temporal.final_test_start, cfg.temporal.final_test_end
    recon_start, recon_fit_end = dev_start, ft_end

    X_dev, y_dev = val._tabular_fold_slice(X_tab_all, y_tab_all, dev_start, dev_end)
    X_ft, y_ft = val._tabular_fold_slice(X_tab_all, y_tab_all, ft_start, ft_end)

    empty = {"metrics": pd.DataFrame(), "reconstruction": pd.DataFrame(), "retained_features": []}
    if len(X_dev) < cfg.features.min_training_months or len(X_ft) == 0:
        log.warning(
            "Basin-average hyperparameter sensitivity skipped: insufficient development-period "
            "(%d rows, need >=%d) or final-test (%d rows) data.",
            len(X_dev), cfg.features.min_training_months, len(X_ft),
        )
        return empty

    # Feature screening re-fit ONCE on the development period, shared by
    # every config of both model families -- exactly like validation.py's
    # final-test section / reconstruction.py's refit -- so differences in
    # accuracy across configs reflect ONLY the hyperparameter choice,
    # never a different feature set.
    retained, removed, _ = feat.screen_correlated_features(X_dev, y_dev, threshold=cfg.features.correlation_threshold)
    log.info(
        "Basin average: hyperparameter-sensitivity feature screening (dev period %s..%s, |r|>%.2f) "
        "retained %d/%d features: %s%s",
        dev_start, dev_end, cfg.features.correlation_threshold, len(retained), len(X_dev.columns),
        retained, f"; dropped {removed}" if removed else "",
    )

    X_dev_r, X_ft_r = X_dev[retained], X_ft[retained]
    X_all_r = X_tab_all[retained]

    # Final-test scaler/split (dev-only fit, scored on final_test_start..end)
    scaler_ft = prep.FoldScaler().fit(X_dev_r, y_dev)
    X_dev_s, _ = scaler_ft.transform_X(X_dev_r)
    y_dev_s = scaler_ft.transform_y(y_dev)
    X_ft_s, _ = scaler_ft.transform_X(X_ft_r)

    # Reconstruction scaler/split (every GRACE-observed month recon_start..recon_fit_end)
    fit_mask = (y_tab_all.index >= pd.Timestamp(recon_start)) & (y_tab_all.index <= pd.Timestamp(recon_fit_end)) & y_tab_all.notna()
    X_fit, y_fit = X_tab_all.loc[fit_mask, retained], y_tab_all.loc[fit_mask]
    scaler_recon = prep.FoldScaler().fit(X_fit, y_fit)
    X_fit_s, _ = scaler_recon.transform_X(X_fit)
    y_fit_s = scaler_recon.transform_y(y_fit)
    X_all_s, oor_all = scaler_recon.transform_X(X_all_r)

    n_inner_val_ft = max(6, int(0.2 * len(X_dev_s))); n_inner_val_ft = min(n_inner_val_ft, len(X_dev_s) - 1) if len(X_dev_s) > 1 else 0
    n_inner_val_recon = max(6, int(0.2 * len(X_fit_s))); n_inner_val_recon = min(n_inner_val_recon, len(X_fit_s) - 1) if len(X_fit_s) > 1 else 0

    configs = {"random_forest": cfg.models.rf_sensitivity_configs, "ann": cfg.models.ann_sensitivity_configs}
    observed = df_basin["twsa"].reindex(X_all_r.index).notna()

    metric_rows, recon_rows = [], []
    for model_name, config_set in configs.items():
        for config_label, params in config_set.items():
            log.info("Basin average sensitivity: fitting %s [%s] -> %s", model_name, config_label, params)
            if model_name == "random_forest":
                m_ft = mdl.fit_rf_with_params(X_dev_s, y_dev_s, params, cfg.models.random_state)
                ft_pred = scaler_ft.inverse_transform_y(m_ft.predict(X_ft_s))
                m_recon = mdl.fit_rf_with_params(X_fit_s, y_fit_s, params, cfg.models.random_state)
                all_pred = scaler_recon.inverse_transform_y(m_recon.predict(X_all_s))
                del m_ft, m_recon
            else:  # ann
                if n_inner_val_ft == 0 or n_inner_val_recon == 0:
                    log.warning(
                        "Basin average sensitivity: skipping ann [%s] -- too little data for an "
                        "early-stopping validation split.", config_label,
                    )
                    continue
                m_ft = mdl.fit_ann_with_params(X_dev_s.values, y_dev_s.values, params, cfg.models, n_inner_val_ft)
                ft_pred = scaler_ft.inverse_transform_y(m_ft.predict(X_ft_s.values))
                m_recon = mdl.fit_ann_with_params(X_fit_s.values, y_fit_s.values, params, cfg.models, n_inner_val_recon)
                all_pred = scaler_recon.inverse_transform_y(m_recon.predict(X_all_s.values))
                del m_ft, m_recon
                clear_keras_memory()

            m = val.compute_metrics(y_ft.values, ft_pred)
            metric_rows.append({
                "model": model_name, "config_label": config_label, "hyperparams_json": json.dumps(params),
                "period": f"{ft_start}..{ft_end}", **m,
            })
            log.info(
                "Basin average sensitivity: %s [%s] final-test (%s..%s) metrics: rmse=%.4f mae=%.4f "
                "pearson_r=%s n=%d",
                model_name, config_label, ft_start, ft_end, m["rmse"], m["mae"],
                round(m["pearson_r"], 4) if np.isfinite(m["pearson_r"]) else None, m["n"],
            )
            for t, pred_val in zip(X_all_r.index, all_pred):
                recon_rows.append({
                    "time": t, "model": model_name, "config_label": config_label,
                    "twsa_reconstructed": float(pred_val), "grace_observed": bool(observed.get(t, False)),
                })

    n_oor = sum(oor_all.values())
    if n_oor:
        log.info("Basin average sensitivity: %d predictor values across the full reconstruction "
                  "period fell outside the fit period's training min/max range (not clipped).", n_oor)

    return {"metrics": pd.DataFrame(metric_rows), "reconstruction": pd.DataFrame(recon_rows), "retained_features": retained}
