"""
temporal.py
===========
Section 3 of the spec: temporal preprocessing and predictor consistency.

v2 note (see config.py for the full explanation): the GLDAS-2.0/2.1
overlap bias correction below is NO LONGER CALLED by pipeline.py, because
the user's predictor_files are already bias-corrected and unit-consistent
across the full 1948-2024 record before they reach this codebase. The
functions are kept in this module, fully documented, in case you ever need
to re-run that correction on a NOT-yet-corrected input -- they are simply
not part of the default v2 pipeline.

What IS used by the default v2 pipeline, from this module:
  - `concatenate_predictor_files`: joins one or more already-corrected
    predictor datasets into one continuous time series, with NO bias-
    correction math (just concatenation, preferring the later file for any
    month present in more than one).
  - `build_final_precipitation_series`: builds the actual precipitation
    series used by the rest of the pipeline, preferring real IMD
    observations wherever they exist and are within the documented IMD
    coverage window, and falling back to the (already-corrected) GLDAS
    precipitation variable everywhere else -- with an explicit, exported,
    non-silent per-month source label.
  - `missing_data_report`, `align_predictors_and_target`: unchanged.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import xarray as xr

from config import Config
from utils import get_logger, PipelineError

log = get_logger()

PREDICTOR_VARS = (
    "precipitation", "temperature", "evapotranspiration", "wind_speed",
    "soil_moisture_total", "specific_humidity", "surface_pressure",
    "shortwave_down", "longwave_down",
)


# ===========================================================================
# v2 default path: concatenation (no correction) + real IMD blending
# ===========================================================================
def concatenate_predictor_files(datasets: List[xr.Dataset]) -> xr.Dataset:
    """
    Join one or more already bias-corrected / unit-consistent predictor
    datasets (as returned by data_io.load_predictor_file, in chronological
    order) into a single continuous time series.

    No correction math is applied here -- the datasets are assumed
    consistent with each other already (per the v2 note in config.py).
    For any calendar month present in more than one dataset, the value
    from the dataset LATER in the list wins (documented in the returned
    dataset's attrs); this mirrors the previous splice behavior of
    preferring the more recent/authoritative product for overlapping
    months, just without re-deriving any bias correction.

    A single-element list is returned unchanged (after a defensive
    sort-by-time), so this function is safe to call regardless of how many
    files the user configured.
    """
    if not datasets:
        raise PipelineError("concatenate_predictor_files received an empty list of datasets.")
    if len(datasets) == 1:
        out = datasets[0].sortby("time")
        out.attrs["concatenation_note"] = "Single predictor file; no concatenation needed."
        return out

    # Later files take priority on overlapping months: achieved by
    # concatenating in order and letting a final groupby('time').last()
    # resolve duplicates, which keeps values from the dataset that appears
    # later in the input list for any timestamp present in more than one.
    combined = xr.concat(datasets, dim="time")
    _, unique_idx = np.unique(combined["time"].values, return_index=True)
    # np.unique sorts and returns the FIRST occurrence; we want the LAST
    # occurrence (i.e. from the later-listed, higher-priority dataset) to
    # win, so re-derive the keep-index explicitly.
    time_vals = combined["time"].values
    keep_pos = {}
    for pos, t in enumerate(time_vals):
        keep_pos[t] = pos  # overwritten by later positions -> last occurrence wins
    ordered_times = sorted(keep_pos.keys())
    keep_idx = [keep_pos[t] for t in ordered_times]
    combined = combined.isel(time=keep_idx).sortby("time")

    n_overlap_months = sum(len(d["time"]) for d in datasets) - combined.sizes["time"]
    combined.attrs["concatenation_note"] = (
        f"Concatenated {len(datasets)} predictor files; {n_overlap_months} overlapping "
        "month(s) resolved in favor of the later-listed file. No bias-correction math applied "
        "(predictor_files are assumed already bias-corrected/unit-consistent -- see config.py)."
    )
    log.info(
        "Concatenated %d predictor file(s) into %d months (%s to %s); %d overlapping month(s) "
        "resolved in favor of the later-listed file.",
        len(datasets), combined.sizes["time"], str(combined.time.values[0])[:10],
        str(combined.time.values[-1])[:10], n_overlap_months,
    )
    return combined


def build_final_precipitation_series(
    cfg: Config, predictor_ds: xr.Dataset, imd_ds: Optional[xr.Dataset], reconstruction_time_index: pd.DatetimeIndex,
) -> Dict[str, object]:
    """
    Build the actual precipitation series used throughout the rest of the
    pipeline, and the per-month source documentation table required by the
    spec (section 3 / section 10).

    Rule, applied per month (identically at every grid cell):
      - If cfg.precipitation_source == "IMD" AND an IMD dataset was loaded
        AND that month is <= cfg.temporal.imd_precip_documented_end AND
        the IMD value for that month/cell is not NaN -> use IMD.
      - Otherwise -> use the (already bias-corrected) GLDAS precipitation
        variable (cfg.varnames.precipitation) from predictor_ds.

    This never silently mislabels a GLDAS-filled month as "IMD" -- the
    source table records the TRUE source used for every single month,
    which is exactly what the spec requires and what the previous
    documentation-only version of this function did not yet do (it only
    built the label table without actually substituting real IMD values).

    Returns {"precipitation": xr.DataArray (time, lat, lon), "source_table": pd.DataFrame}.
    """
    vn = cfg.varnames
    gldas_precip = predictor_ds[vn.precipitation]
    source_choice = cfg.precipitation_source.upper()
    documented_end = pd.Timestamp(cfg.temporal.imd_precip_documented_end)

    if source_choice != "IMD" or imd_ds is None:
        if source_choice == "IMD" and imd_ds is None:
            log.warning(
                "precipitation_source='IMD' but no usable IMD file was loaded; using GLDAS "
                "precipitation for the ENTIRE period. No month will be labeled as IMD-observed."
            )
        final = gldas_precip.rename("precipitation_final")
        rows = [{"time": t, "precipitation_source": "GLDAS (fallback/primary)"} for t in reconstruction_time_index]
        source_table = pd.DataFrame(rows)
        return {"precipitation": final, "source_table": source_table}

    # Align IMD onto predictor_ds's exact time axis (NaN where IMD has no month).
    imd_precip = imd_ds["precipitation_imd"].reindex(time=predictor_ds["time"].values, method=None)

    time_da = predictor_ds["time"]
    within_doc_window = time_da <= documented_end
    imd_has_data = imd_precip.notnull()
    use_imd = within_doc_window & imd_has_data

    final = xr.where(use_imd, imd_precip, gldas_precip)
    final = final.rename("precipitation_final")
    final.attrs["note"] = (
        "Blended precipitation: IMD used wherever use_imd is True (documented per-month in "
        "precipitation_source_table.csv), GLDAS used elsewhere. See temporal.build_final_precipitation_series."
    )

    # Per-month source label: a month counts as "IMD" for the documentation
    # table only if IMD actually had data for AT LEAST ONE cell that month
    # (so the table reflects genuine substitution, not a column that is
    # structurally always False for an off-grid or all-NaN file).
    imd_any_cell = use_imd.any(dim=[d for d in ("lat", "lon") if d in use_imd.dims])
    times = pd.DatetimeIndex(predictor_ds["time"].values)
    rows = []
    for t, is_imd in zip(times, imd_any_cell.values if imd_any_cell.ndim else np.atleast_1d(imd_any_cell.values)):
        rows.append({"time": t, "precipitation_source": "IMD" if bool(is_imd) else "GLDAS (fallback)"})
    source_table = pd.DataFrame(rows)

    # Extend the table to cover the full reconstruction index too (months
    # before/after predictor_ds's own coverage, if any), always GLDAS/NA
    # since there is no predictor data to blend there anyway.
    covered_times = set(source_table["time"])
    extra_rows = [
        {"time": t, "precipitation_source": "no predictor data for this month"}
        for t in reconstruction_time_index if t not in covered_times
    ]
    if extra_rows:
        source_table = pd.concat([source_table, pd.DataFrame(extra_rows)], ignore_index=True).sort_values("time").reset_index(drop=True)

    n_imd = (source_table["precipitation_source"] == "IMD").sum()
    log.info(
        "Precipitation source resolved: %d month(s) using real IMD data, %d month(s) using GLDAS "
        "fallback/primary, out of %d total.", n_imd, len(source_table) - n_imd, len(source_table),
    )
    return {"precipitation": final, "source_table": source_table}


def missing_data_report(ds: xr.Dataset) -> pd.DataFrame:
    rows = []
    for var in ds.data_vars:
        da = ds[var]
        total = int(da.size)
        n_missing = int(np.isnan(da.values).sum())
        rows.append({
            "variable": var,
            "n_total": total,
            "n_missing": n_missing,
            "fraction_missing": n_missing / total if total else np.nan,
        })
    df = pd.DataFrame(rows)
    log.info("Missing-data report:\n%s", df.to_string(index=False))
    return df


def align_predictors_and_target(predictor_ds: xr.Dataset, grace_ds: xr.Dataset) -> xr.Dataset:
    """
    Inner-join predictors and GRACE TWSA on the calendar-month time axis.
    No shifting is applied here -- lag/lookback construction (which is
    where future-information leakage could otherwise creep in) happens
    exclusively in features.py, strictly using only the current and past
    months relative to each target month.
    """
    common_time = sorted(set(pd.to_datetime(predictor_ds.time.values)) & set(pd.to_datetime(grace_ds.time.values)))
    common_time = pd.DatetimeIndex(common_time)
    merged = xr.merge([predictor_ds.sel(time=common_time), grace_ds.sel(time=common_time)], join="exact")
    log.info("Predictor/target alignment: %d common months (%s to %s).",
              len(common_time), common_time.min().date(), common_time.max().date())
    return merged


# ===========================================================================
# OPTIONAL / NOT CALLED BY DEFAULT in v2 -- kept for reference in case a
# future input is NOT already bias-corrected across a GLDAS-2.0/2.1-style
# forcing-product boundary. See the module docstring above.
# ===========================================================================
GLDAS_BIAS_CORRECTION_DOCSTRING = """
Reference product: the more recent product in an overlap is treated as the
reference (bias[m] = mean_recent(m, overlap) - mean_older(m, overlap)), and
the OLDER product's pre-overlap segment has bias[m] added back, matched by
calendar month -- an additive seasonal-cycle mean-bias correction, with an
optional (off by default) variance-ratio scaling as a separate, explicitly
labeled step. Both are fit using ONLY the overlap window, never GRACE TWSA
and never anything from the final-test period -- there is no leakage from
the GRACE evaluation into this step.
"""


@dataclass
class ForcingConsistencyReport:
    variable: str
    month_of_year: int
    n_overlap_months: int
    mean_older_overlap: float
    mean_recent_overlap: float
    additive_bias_applied: float
    std_older_overlap: float
    std_recent_overlap: float
    variance_ratio: float
    variance_correction_applied: bool
    residual_mean_after_correction: float
    residual_std_after_correction: float


def compute_overlap_bias_correction(
    older: xr.Dataset, recent: xr.Dataset, overlap_start: str, overlap_end: str,
    apply_variance_correction: bool = False,
) -> Dict[str, object]:
    """
    NOT CALLED by the default v2 pipeline (see module docstring). Fits
    per-variable, per-calendar-month additive (and optionally variance)
    correction parameters using ONLY the given overlap window between two
    NOT-yet-corrected predictor datasets, then returns:
      - "corrected_older": `older` with the correction applied to its
        ENTIRE time range
      - "report": a DataFrame of per-variable/per-month diagnostics
    """
    ov_start, ov_end = pd.Timestamp(overlap_start), pd.Timestamp(overlap_end)
    older_ov = older.sel(time=slice(ov_start, ov_end))
    recent_ov = recent.sel(time=slice(ov_start, ov_end))

    common_time = sorted(set(pd.to_datetime(older_ov.time.values)) & set(pd.to_datetime(recent_ov.time.values)))
    if len(common_time) < 24:
        raise PipelineError(
            f"Overlap window only yields {len(common_time)} common months; "
            "need at least 24 for a defensible seasonal-cycle bias correction."
        )
    common_time = pd.DatetimeIndex(common_time)
    older_ov = older_ov.sel(time=common_time)
    recent_ov = recent_ov.sel(time=common_time)
    log.info("Overlap window: %d common months (%s to %s).",
             len(common_time), common_time.min().date(), common_time.max().date())

    corrected_older = older.copy(deep=True)
    report_rows = []

    for var in PREDICTOR_VARS:
        if var not in older or var not in recent:
            continue
        moy_older = older_ov[var].groupby("time.month")
        moy_recent = recent_ov[var].groupby("time.month")
        mean_older_by_month = moy_older.mean(dim=("time", "lat", "lon"), skipna=True)
        mean_recent_by_month = moy_recent.mean(dim=("time", "lat", "lon"), skipna=True)
        std_older_by_month = moy_older.std(dim=("time", "lat", "lon"), skipna=True)
        std_recent_by_month = moy_recent.std(dim=("time", "lat", "lon"), skipna=True)

        bias_by_month = mean_recent_by_month - mean_older_by_month
        variance_ratio_by_month = (std_recent_by_month / std_older_by_month.where(std_older_by_month != 0)).fillna(1.0)

        full_month_of_year = corrected_older["time"].dt.month
        bias_lookup = bias_by_month.sel(month=full_month_of_year)
        corrected_var = corrected_older[var] + bias_lookup.drop_vars("month")

        if apply_variance_correction:
            clim_by_month = corrected_older[var].groupby("time.month").mean(dim="time", skipna=True)
            clim_lookup = clim_by_month.sel(month=full_month_of_year).drop_vars("month")
            anomaly = corrected_var - clim_lookup
            ratio_lookup = variance_ratio_by_month.sel(month=full_month_of_year).drop_vars("month")
            corrected_var = clim_lookup + anomaly * ratio_lookup

        corrected_older[var] = corrected_var

        corrected_overlap = corrected_older[var].sel(time=common_time)
        for m in range(1, 13):
            mask_m = corrected_overlap["time"].dt.month == m
            if not bool(mask_m.any()):
                continue
            corrected_vals = corrected_overlap.where(mask_m, drop=True)
            ref_vals = recent_ov[var].where(recent_ov["time"].dt.month == m, drop=True)
            resid = (corrected_vals.mean(skipna=True) - ref_vals.mean(dim=("time", "lat", "lon"), skipna=True))
            resid_std = float(corrected_vals.std(skipna=True).values) - float(ref_vals.std(dim=("time", "lat", "lon"), skipna=True).values)
            report_rows.append(ForcingConsistencyReport(
                variable=var,
                month_of_year=m,
                n_overlap_months=int(mask_m.sum().values),
                mean_older_overlap=float(mean_older_by_month.sel(month=m).values),
                mean_recent_overlap=float(mean_recent_by_month.sel(month=m).values),
                additive_bias_applied=float(bias_by_month.sel(month=m).values),
                std_older_overlap=float(std_older_by_month.sel(month=m).values),
                std_recent_overlap=float(std_recent_by_month.sel(month=m).values),
                variance_ratio=float(variance_ratio_by_month.sel(month=m).values),
                variance_correction_applied=apply_variance_correction,
                residual_mean_after_correction=float(resid.values) if hasattr(resid, "values") else float(resid),
                residual_std_after_correction=float(resid_std),
            ))

    report_df = pd.DataFrame([r.__dict__ for r in report_rows])
    max_abs_resid = report_df["residual_mean_after_correction"].abs().max() if len(report_df) else float("nan")
    log.info(
        "Overlap bias correction complete. Max |residual mean| across all "
        "variables/months after correction: %.4f (variance_correction=%s).",
        max_abs_resid, apply_variance_correction,
    )
    return {"corrected_older": corrected_older, "report": report_df}


def splice_predictor_series(corrected_older: xr.Dataset, recent: xr.Dataset, splice_date: str) -> xr.Dataset:
    """NOT CALLED by the default v2 pipeline (see module docstring). Builds
    a continuous series: bias-corrected `older` before `splice_date`, `recent`
    as-is from `splice_date` onward."""
    splice_ts = pd.Timestamp(splice_date)
    pre = corrected_older.sel(time=slice(None, splice_ts - pd.DateOffset(months=1)))
    post = recent.sel(time=slice(splice_ts, None))
    combined = xr.concat([pre, post], dim="time").sortby("time")
    combined.attrs["splice_date"] = str(splice_ts.date())
    log.info("Spliced predictor series: %d months total (%s to %s), splice at %s.",
              combined.sizes["time"], str(combined.time.values[0])[:10],
              str(combined.time.values[-1])[:10], splice_ts.date())
    return combined
