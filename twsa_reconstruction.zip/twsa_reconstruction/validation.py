"""
validation.py
==============
Sections 7 (hyperparameter tuning orchestration) and 8 (temporal validation
and final testing) of the spec, run for a single grid cell's data. The
per-grid-cell loop itself lives in reconstruction.py / pipeline.py.

Design choices made explicit here (spec leaves some of these as "document
your choice" items):

  - Lag features (24-column tabular set) and lookback sequences are built
    ONCE from the cell's full available time series, not separately per
    fold. This is NOT a leakage risk: each row's lag/window values use
    only that row's own month and months before it, regardless of which
    fold a row later lands in. Only normalization, correlation-based
    feature screening, and hyperparameter selection are fit per fold /
    per development-vs-final-test split, strictly on training data.
  - Hyperparameters: tuned independently inside each development fold
    (see models.py), but the single hyperparameter set CARRIED FORWARD
    to the final-test refit and to the 1948-2024 reconstruction is the
    one selected in the LAST (most data-rich) development fold. This is
    stated explicitly in every exported hyperparameter record rather than
    left implicit.
  - Feature screening for the final-test refit and the reconstruction
    model is re-fit on the FULL development period (2003-2020), never on
    2021-2024.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import features as feat
import models as mdl
import preprocessing as prep
from config import Config
from utils import get_logger, safe_corr, clear_keras_memory, MODEL_GROUPS

log = get_logger()


def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    mask = np.isfinite(y_true) & np.isfinite(y_pred)
    n = int(mask.sum())
    if n == 0:
        return {"rmse": np.nan, "mae": np.nan, "pearson_r": np.nan, "n": 0}
    yt, yp = y_true[mask], y_pred[mask]
    rmse = float(np.sqrt(np.mean((yt - yp) ** 2)))
    mae = float(np.mean(np.abs(yt - yp)))
    r = safe_corr(yt, yp, method="pearson")
    return {"rmse": rmse, "mae": mae, "pearson_r": r if r is not None else np.nan, "n": n}


def adjust_folds_to_data(cfg: Config, available_times: pd.DatetimeIndex) -> List[Dict]:
    """
    Clip the configured rolling-origin folds to whatever months are
    actually usable (non-missing) for this grid cell, and drop any fold
    whose training window ends up with fewer than
    cfg.features.min_training_months usable months. Every adjustment is
    logged so a returning reader can see exactly which dates/counts were
    used.
    """
    folds = []
    for (tr_start, tr_end, va_start, va_end) in cfg.temporal.cv_folds:
        tr_mask = (available_times >= pd.Timestamp(tr_start)) & (available_times <= pd.Timestamp(tr_end))
        va_mask = (available_times >= pd.Timestamp(va_start)) & (available_times <= pd.Timestamp(va_end))
        n_train, n_val = int(tr_mask.sum()), int(va_mask.sum())
        if n_train < cfg.features.min_training_months or n_val == 0:
            log.debug("Fold [%s-%s / %s-%s] skipped: only %d train / %d val usable months.",
                      tr_start, tr_end, va_start, va_end, n_train, n_val)
            continue
        folds.append({
            "train_start": tr_start, "train_end": tr_end,
            "val_start": va_start, "val_end": va_end,
            "n_train_usable": n_train, "n_val_usable": n_val,
        })
    return folds


@dataclass
class CellValidationResult:
    cell_id: Tuple[float, float]
    correlation_records: List[Dict] = field(default_factory=list)
    feature_selection_records: List[Dict] = field(default_factory=list)
    oof_predictions: List[Dict] = field(default_factory=list)
    fold_metrics: List[Dict] = field(default_factory=list)
    hyperparameters: List[Dict] = field(default_factory=list)
    final_test_predictions: List[Dict] = field(default_factory=list)
    final_test_metrics: List[Dict] = field(default_factory=list)
    diagnostics: List[Dict] = field(default_factory=list)
    selected_config: Dict = field(default_factory=dict)  # carried to reconstruction.py


def _tabular_fold_slice(X_all: pd.DataFrame, y_all: pd.Series, start: str, end: str) -> Tuple[pd.DataFrame, pd.Series]:
    """Slice to a date range AND drop rows with no GRACE observation (y is NaN
    outside the GRACE record; make_tabular_dataset deliberately keeps those
    rows so reconstruction.py can predict them, but training/validation here
    needs a real target)."""
    sel = (X_all.index >= pd.Timestamp(start)) & (X_all.index <= pd.Timestamp(end))
    X_sel, y_sel = X_all.loc[sel], y_all.loc[sel]
    valid = y_sel.notna()
    return X_sel.loc[valid], y_sel.loc[valid]


def _sequence_fold_slice(X_seq_all: np.ndarray, y_seq_all: pd.Series, seq_time_index: pd.DatetimeIndex, start: str, end: str) -> Tuple[np.ndarray, pd.Series]:
    """Sequence-array analogue of _tabular_fold_slice: date-range mask, then drop NaN-y rows.
    Note: comparing a DatetimeIndex returns a plain numpy bool array, not a Series,
    so `sel` is indexed directly (no `.values`)."""
    sel = (seq_time_index >= pd.Timestamp(start)) & (seq_time_index <= pd.Timestamp(end))
    X_sel, y_sel = X_seq_all[sel], y_seq_all.loc[sel]
    valid = y_sel.notna()
    return X_sel[valid.values], y_sel.loc[valid]


def run_cell_validation(
    df_cell: pd.DataFrame, cfg: Config, lat: float, lon: float,
    models_to_run: Tuple[str, ...] = MODEL_GROUPS,
    fixed_hyperparameters: Optional[Dict[str, Dict]] = None,
) -> CellValidationResult:
    """
    `models_to_run`: subset of utils.MODEL_GROUPS = ("baseline",
    "random_forest", "ann", "lstm", "bilstm") -- see config.py's
    Config.models_to_run and pipeline.py's --models flag. Any group left
    out is simply never tuned/fit for this cell (no hyperparameters, no
    predictions, no entry in result.hyperparameters/fold_metrics for it),
    which is what lets a whole-basin run be split into several smaller,
    lower-memory invocations, one model family at a time.

    `fixed_hyperparameters`: optional {"random_forest": {...}, "ann": {...}}
    dict of ALREADY-DECIDED hyperparameters -- typically tuned ONCE on the
    cheap, single-series basin average (see pipeline.py's STEP 4 /
    basin_average.py) -- to use DIRECTLY at every fold of THIS cell,
    skipping models.py's per-fold tune_random_forest/tune_ann grid search
    entirely. This is the dominant cost of a whole-basin run: with the
    default grids, per-fold-per-cell tuning does 18 RF fits + 1 refit and
    8 full Keras ANN trainings + 1 refit; fixed mode does exactly 1 fit
    each. A family missing from this dict (or the dict itself being None)
    falls back to this cell's own per-fold tuning for THAT family only,
    so an incomplete basin-average tuning result never silently drops a
    whole model family everywhere.
    """
    result = CellValidationResult(cell_id=(lat, lon))
    mcfg = cfg.models
    log.info("[%.3f, %.3f] Model families requested for this cell: %s", lat, lon, list(models_to_run))

    # --- Build lag/sequence datasets once from the full available series ---
    X_tab_all, y_tab_all = feat.make_tabular_dataset(df_cell, lags=cfg.features.lags_tabular)
    X_seq_all, y_seq_all, channel_names = feat.make_sequence_dataset(
        df_cell, window=cfg.features.lookback_window, include_target_month=cfg.features.sequence_includes_target_month,
    )
    seq_time_index = y_seq_all.index
    log.info(
        "[%.3f, %.3f] Built 24-feature tabular set: %d rows (%s..%s), %d usable with a GRACE target. "
        "Sequence set (window=%d): %d rows, %d usable with a GRACE target.",
        lat, lon, len(X_tab_all), X_tab_all.index.min().date() if len(X_tab_all) else None,
        X_tab_all.index.max().date() if len(X_tab_all) else None, int(y_tab_all.notna().sum()),
        cfg.features.lookback_window, len(X_seq_all), int(y_seq_all.notna().sum()),
    )

    # Fold adjustment must be based on months with an ACTUAL GRACE observation,
    # not just predictor availability (X_tab_all/X_seq_all now span the full
    # 1948-2024 predictor record so reconstruction.py can use them later).
    folds = adjust_folds_to_data(cfg, X_tab_all.index[y_tab_all.notna()])
    if not folds:
        log.warning("[%.3f, %.3f] No usable rolling-origin CV fold for this cell (insufficient "
                     "GRACE-observed months in every configured fold window); skipped.", lat, lon)
        result.diagnostics.append({"message": "No usable CV folds for this cell; skipped."})
        return result
    log.info("[%.3f, %.3f] %d/%d configured CV fold(s) usable: %s", lat, lon, len(folds), len(cfg.temporal.cv_folds),
              [f"{f['val_start']}..{f['val_end']} ({f['n_train_usable']} train / {f['n_val_usable']} val mo)" for f in folds])

    last_fold_hparams: Dict[str, Dict] = {}
    last_fold_retained_features: Optional[List[str]] = None

    for fold_i, fold in enumerate(folds, start=1):
        X_train, y_train = _tabular_fold_slice(X_tab_all, y_tab_all, fold["train_start"], fold["train_end"])
        X_val, y_val = _tabular_fold_slice(X_tab_all, y_tab_all, fold["val_start"], fold["val_end"])
        if len(X_train) < cfg.features.min_training_months or len(X_val) == 0:
            continue

        # --- 5.1 / 5.2 correlation analysis + screening (training only) ---
        corr_mats = feat.correlation_matrices(X_train)
        retained, removed, screen_log = feat.screen_correlated_features(
            X_train, y_train, threshold=cfg.features.correlation_threshold,
        )
        result.correlation_records.append({
            "fold": fold_i, "pearson": corr_mats["pearson"], "spearman": corr_mats["spearman"],
        })
        result.feature_selection_records.append({
            "fold": fold_i, "retained": retained, "removed": removed, "decisions": screen_log,
        })
        last_fold_retained_features = retained
        log.info(
            "[%.3f, %.3f] Fold %d/%d [train %s..%s, val %s..%s]: feature screening (|r|>%.2f) "
            "retained %d/%d features: %s%s",
            lat, lon, fold_i, len(folds), fold["train_start"], fold["train_end"],
            fold["val_start"], fold["val_end"], cfg.features.correlation_threshold,
            len(retained), len(X_train.columns), retained,
            f"; dropped {removed}" if removed else "",
        )

        X_train_r, X_val_r = X_train[retained], X_val[retained]
        X_train_s, y_train_s, X_val_s, y_val_s, scaler, norm_diag = prep.normalize_fold(X_train_r, y_train, X_val_r, y_val)
        result.diagnostics.append({"fold": fold_i, "type": "normalization", **norm_diag})

        fold_preds = {"time": X_val.index}
        fold_model_hparams = {}

        # --- Baseline family: persistence, climatology, linear_regression.
        # Always cheap (no tuning, no TF), so bundled under one "baseline"
        # switch rather than three separate ones. ---
        if "baseline" in models_to_run:
            lr = mdl.LinearRegressionModel().fit(X_train_s, y_train_s)
            fold_preds["linear_regression"] = scaler.inverse_transform_y(lr.predict(X_val_s))

            clim = mdl.ClimatologyBaseline().fit(y_train)
            fold_preds["climatology"] = clim.predict(X_val.index).values

            full_series = df_cell["twsa"]
            prev_month_vals = full_series.reindex(X_val.index - pd.DateOffset(months=1)).values
            fold_preds["persistence"] = prev_month_vals  # NaN where unavailable; handled by compute_metrics

        # --- Random forest family (sklearn only, no TF/Keras memory). ---
        n_inner_val = max(6, int(0.2 * len(X_train_s)))
        n_inner_val = min(n_inner_val, len(X_train_s) - 1) if len(X_train_s) > 1 else 0
        if "random_forest" in models_to_run and n_inner_val > 0:
            fixed_rf = fixed_hyperparameters.get("random_forest") if fixed_hyperparameters else None
            if fixed_rf:
                rf_params = fixed_rf
                rf_model = mdl.fit_rf_with_params(X_train_s, y_train_s, rf_params, mcfg.random_state)
                tuned_label = "FIXED (basin-average-tuned, no per-cell search)"
            else:
                rf_params, rf_model = mdl.tune_random_forest(X_train_s, y_train_s, mcfg.rf_param_grid, n_inner_val, mcfg.random_state)
                tuned_label = "tuned (per-cell grid search)"
            fold_preds["random_forest"] = scaler.inverse_transform_y(rf_model.predict(X_val_s))
            fold_model_hparams["random_forest"] = rf_params
            log.info("[%.3f, %.3f] Fold %d: random_forest %s -> %s", lat, lon, fold_i, tuned_label, rf_params)
            del rf_model

        # --- ANN family (TF/Keras). Independent of random_forest now --
        # runs whether or not "random_forest" was requested this invocation. ---
        if "ann" in models_to_run and n_inner_val > 0:
            fixed_ann = fixed_hyperparameters.get("ann") if fixed_hyperparameters else None
            if fixed_ann:
                ann_params = fixed_ann
                ann_model = mdl.fit_ann_with_params(X_train_s.values, y_train_s.values, ann_params, mcfg, n_inner_val)
                tuned_label = "FIXED (basin-average-tuned, no per-cell search)"
            else:
                ann_params, ann_model = mdl.tune_ann(X_train_s.values, y_train_s.values, mcfg, n_inner_val)
                tuned_label = "tuned (per-cell grid search)"
            fold_preds["ann"] = scaler.inverse_transform_y(ann_model.predict(X_val_s.values))
            fold_model_hparams["ann"] = ann_params
            log.info("[%.3f, %.3f] Fold %d: ann %s -> %s", lat, lon, fold_i, tuned_label, ann_params)
            del ann_model
            clear_keras_memory()

        # Sequence models (LSTM / BiLSTM) -- own normalization, own folds.
        # X_seq_train/X_seq_val are built once regardless of which (if any)
        # of "lstm"/"bilstm" are requested, since both families share them.
        X_seq_train, y_seq_train = _sequence_fold_slice(X_seq_all, y_seq_all, seq_time_index, fold["train_start"], fold["train_end"])
        X_seq_val, y_seq_val = _sequence_fold_slice(X_seq_all, y_seq_all, seq_time_index, fold["val_start"], fold["val_end"])
        seq_models_wanted = [m for m in ("lstm", "bilstm") if m in models_to_run]

        if seq_models_wanted and len(X_seq_train) >= cfg.features.min_training_months and len(X_seq_val) > 0:
            # Sequence models have their own valid-sample index (lost to the
            # lookback window), so the target is re-scaled here rather than
            # reusing the tabular fold's scaler. FoldScaler is reused purely
            # for its min-max target transform/inverse_transform; the dummy
            # single-column frame below is never used for feature scaling.
            seq_scaler_tgt = prep.FoldScaler().fit(
                pd.DataFrame({"twsa": y_seq_train.values}), y_seq_train,
            )
            y_seq_train_s = seq_scaler_tgt.transform_y(y_seq_train)
            y_seq_val_s = seq_scaler_tgt.transform_y(y_seq_val)
            X_seq_train_s, X_seq_val_s, _, _ = prep.normalize_sequence_fold(X_seq_train, X_seq_val)

            n_inner_val_seq = max(6, int(0.2 * len(X_seq_train_s)))
            n_inner_val_seq = min(n_inner_val_seq, len(X_seq_train_s) - 1) if len(X_seq_train_s) > 1 else 0
            if n_inner_val_seq > 0:
                # LSTM and BiLSTM are each gated and cleaned up independently --
                # running only "lstm" (or only "bilstm") this invocation builds
                # and discards nothing for the other family.
                if "lstm" in seq_models_wanted:
                    lstm_params, lstm_model = mdl.tune_rnn(X_seq_train_s, y_seq_train_s.values, mcfg, n_inner_val_seq, bidirectional=False)
                    lstm_pred = seq_scaler_tgt.inverse_transform_y(lstm_model.predict(X_seq_val_s))
                    fold_model_hparams["lstm"] = lstm_params
                    log.info("[%.3f, %.3f] Fold %d: lstm tuned -> %s", lat, lon, fold_i, lstm_params)
                    del lstm_model
                    clear_keras_memory()
                    for t, yt, lp in zip(y_seq_val.index, y_seq_val.values, lstm_pred):
                        result.oof_predictions.append({"fold": fold_i, "time": t, "model": "lstm", "y_true": yt, "y_pred": lp})

                if "bilstm" in seq_models_wanted:
                    bilstm_params, bilstm_model = mdl.tune_rnn(X_seq_train_s, y_seq_train_s.values, mcfg, n_inner_val_seq, bidirectional=True)
                    bilstm_pred = seq_scaler_tgt.inverse_transform_y(bilstm_model.predict(X_seq_val_s))
                    fold_model_hparams["bilstm"] = bilstm_params
                    log.info("[%.3f, %.3f] Fold %d: bilstm tuned -> %s", lat, lon, fold_i, bilstm_params)
                    del bilstm_model
                    clear_keras_memory()
                    for t, yt, bp in zip(y_seq_val.index, y_seq_val.values, bilstm_pred):
                        result.oof_predictions.append({"fold": fold_i, "time": t, "model": "bilstm", "y_true": yt, "y_pred": bp})

        for model_name, preds in fold_preds.items():
            if model_name == "time":
                continue
            preds = np.asarray(preds)
            for t, yt, yp in zip(fold_preds["time"], y_val.values, preds):
                result.oof_predictions.append({"fold": fold_i, "time": t, "model": model_name, "y_true": yt, "y_pred": yp})

        for model_name in list(fold_preds.keys()):
            if model_name == "time":
                continue
            preds = np.asarray(fold_preds[model_name])
            m = compute_metrics(y_val.values, preds)
            result.fold_metrics.append({"fold": fold_i, "model": model_name, **m,
                                         "val_start": fold["val_start"], "val_end": fold["val_end"],
                                         "n_val_usable": fold["n_val_usable"]})
        if len(X_seq_val) > 0:
            for model_name in [m for m in ("lstm", "bilstm") if m in fold_model_hparams]:
                sub = [r for r in result.oof_predictions if r["fold"] == fold_i and r["model"] == model_name]
                if sub:
                    yt = np.array([r["y_true"] for r in sub])
                    yp = np.array([r["y_pred"] for r in sub])
                    m = compute_metrics(yt, yp)
                    result.fold_metrics.append({"fold": fold_i, "model": model_name, **m,
                                                 "val_start": fold["val_start"], "val_end": fold["val_end"],
                                                 "n_val_usable": fold["n_val_usable"]})

        fold_metric_summary = {m["model"]: {"rmse": round(m["rmse"], 4), "pearson_r": round(m["pearson_r"], 4) if np.isfinite(m["pearson_r"]) else None, "n": m["n"]}
                               for m in result.fold_metrics if m["fold"] == fold_i}
        log.info("[%.3f, %.3f] Fold %d metrics (rmse, pearson_r, n): %s", lat, lon, fold_i, fold_metric_summary)

        result.hyperparameters.append({"fold": fold_i, **fold_model_hparams})
        last_fold_hparams = fold_model_hparams

    result.selected_config = {
        "hyperparameters": last_fold_hparams,
        "retained_features": last_fold_retained_features,
    }
    log.info(
        "[%.3f, %.3f] Rolling-origin CV complete (%d fold(s)). Hyperparameters carried forward to "
        "the final test and the 1948-2024 reconstruction (selected in the LAST/most data-rich "
        "development fold): %s. Retained features from that same fold: %s",
        lat, lon, len(folds), last_fold_hparams, last_fold_retained_features,
    )

    # --- Section 8: final test on 2021-2024, using ONLY development-period
    #     (2003-2020) data to (re-)fit feature screening and the models,
    #     with hyperparameters fixed at whatever the last development fold
    #     selected. 2021-2024 is touched only to compute predictions/metrics. ---
    dev_start, dev_end = cfg.temporal.grace_development_start, cfg.temporal.grace_development_end
    ft_start, ft_end = cfg.temporal.final_test_start, cfg.temporal.final_test_end
    X_dev, y_dev = _tabular_fold_slice(X_tab_all, y_tab_all, dev_start, dev_end)
    X_ft, y_ft = _tabular_fold_slice(X_tab_all, y_tab_all, ft_start, ft_end)

    if len(X_dev) >= cfg.features.min_training_months and len(X_ft) > 0 and (last_fold_hparams or "baseline" in models_to_run):
        retained_ft, removed_ft, screen_log_ft = feat.screen_correlated_features(
            X_dev, y_dev, threshold=cfg.features.correlation_threshold,
        )
        result.feature_selection_records.append({
            "fold": "final_test", "retained": retained_ft, "removed": removed_ft, "decisions": screen_log_ft,
        })
        log.info(
            "[%.3f, %.3f] Final test [%s..%s], refit on development period [%s..%s] (%d train rows): "
            "feature screening (|r|>%.2f) retained %d/%d features: %s%s",
            lat, lon, ft_start, ft_end, dev_start, dev_end, len(X_dev), cfg.features.correlation_threshold,
            len(retained_ft), len(X_dev.columns), retained_ft,
            f"; dropped {removed_ft}" if removed_ft else "",
        )
        X_dev_r, X_ft_r = X_dev[retained_ft], X_ft[retained_ft]
        X_dev_s, y_dev_s, X_ft_s, y_ft_s, scaler_ft, norm_diag_ft = prep.normalize_fold(X_dev_r, y_dev, X_ft_r, y_ft)
        result.diagnostics.append({"fold": "final_test", "type": "normalization", **norm_diag_ft})

        ft_preds = {}
        n_inner_val_ft = max(6, int(0.2 * len(X_dev_s)))
        n_inner_val_ft = min(n_inner_val_ft, len(X_dev_s) - 1)

        if "baseline" in models_to_run:
            ft_preds["linear_regression"] = scaler_ft.inverse_transform_y(
                mdl.LinearRegressionModel().fit(X_dev_s, y_dev_s).predict(X_ft_s)
            )
            clim_ft = mdl.ClimatologyBaseline().fit(y_dev)
            ft_preds["climatology"] = clim_ft.predict(X_ft.index).values
            prev_vals_ft = df_cell["twsa"].reindex(X_ft.index - pd.DateOffset(months=1)).values
            ft_preds["persistence"] = prev_vals_ft

        if "random_forest" in last_fold_hparams:
            rf_ft = mdl.fit_rf_with_params(X_dev_s, y_dev_s, last_fold_hparams["random_forest"], mcfg.random_state)
            ft_preds["random_forest"] = scaler_ft.inverse_transform_y(rf_ft.predict(X_ft_s))
            del rf_ft
        if "ann" in last_fold_hparams:
            ann_ft = mdl.fit_ann_with_params(X_dev_s.values, y_dev_s.values, last_fold_hparams["ann"], mcfg, n_inner_val_ft)
            ft_preds["ann"] = scaler_ft.inverse_transform_y(ann_ft.predict(X_ft_s.values))
            del ann_ft
            clear_keras_memory()

        for model_name, preds in ft_preds.items():
            preds = np.asarray(preds)
            for t, yt, yp in zip(X_ft.index, y_ft.values, preds):
                result.final_test_predictions.append({"model": model_name, "time": t, "y_true": yt, "y_pred": yp})
            m = compute_metrics(y_ft.values, preds)
            result.final_test_metrics.append({"model": model_name, **m, "period": f"{ft_start}..{ft_end}"})

        # Sequence models on the final-test split -- lstm/bilstm are fit and
        # cleaned up independently so a run requesting only one of them
        # doesn't build the other.
        X_seq_dev, y_seq_dev = _sequence_fold_slice(X_seq_all, y_seq_all, seq_time_index, dev_start, dev_end)
        X_seq_ft, y_seq_ft = _sequence_fold_slice(X_seq_all, y_seq_all, seq_time_index, ft_start, ft_end)
        seq_ft_models = [m for m in ("lstm", "bilstm") if m in last_fold_hparams]
        if seq_ft_models and len(X_seq_dev) >= cfg.features.min_training_months and len(X_seq_ft) > 0:
            seq_scaler_tgt_ft = prep.FoldScaler().fit(pd.DataFrame({"twsa": y_seq_dev.values}), y_seq_dev)
            y_seq_dev_s = seq_scaler_tgt_ft.transform_y(y_seq_dev)
            X_seq_dev_s, X_seq_ft_s, _, _ = prep.normalize_sequence_fold(X_seq_dev, X_seq_ft)
            n_inner_val_seq_ft = max(6, int(0.2 * len(X_seq_dev_s)))
            n_inner_val_seq_ft = min(n_inner_val_seq_ft, len(X_seq_dev_s) - 1)

            for model_name in seq_ft_models:
                m_ft = mdl.fit_rnn_with_params(
                    X_seq_dev_s, y_seq_dev_s.values, last_fold_hparams[model_name], mcfg,
                    n_inner_val_seq_ft, bidirectional=(model_name == "bilstm"),
                )
                pred_ft = seq_scaler_tgt_ft.inverse_transform_y(m_ft.predict(X_seq_ft_s))
                del m_ft
                clear_keras_memory()
                for t, yt, yp in zip(y_seq_ft.index, y_seq_ft.values, pred_ft):
                    result.final_test_predictions.append({"model": model_name, "time": t, "y_true": yt, "y_pred": yp})
                m = compute_metrics(y_seq_ft.values, pred_ft)
                result.final_test_metrics.append({"model": model_name, **m, "period": f"{ft_start}..{ft_end}"})

        ft_metric_summary = {
            m["model"]: {"rmse": round(m["rmse"], 4), "pearson_r": round(m["pearson_r"], 4) if np.isfinite(m["pearson_r"]) else None, "n": m["n"]}
            for m in result.final_test_metrics
        }
        log.info("[%.3f, %.3f] Final test [%s..%s] metrics (rmse, pearson_r, n): %s",
                  lat, lon, ft_start, ft_end, ft_metric_summary)
    else:
        log.warning(
            "[%.3f, %.3f] Final-test (%s..%s) skipped: insufficient development-period training "
            "data (%d rows, need >=%d), no final-test months available (%d rows), or no "
            "hyperparameters were selected in any development fold for this cell.",
            lat, lon, ft_start, ft_end, len(X_dev), cfg.features.min_training_months, len(X_ft),
        )
        result.diagnostics.append({
            "message": "Final-test (2021-2024) skipped: insufficient development-period "
                       "training data, no final-test months available, or no hyperparameters "
                       "were selected in any development fold for this cell.",
        })

    return result
