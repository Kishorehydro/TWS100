"""
preprocessing.py
=================
Sections 3 (imputation) and 6 (normalization / leakage prevention) of the
spec. Every data-dependent transform here is fit on a TRAINING slice only
and then applied, unmodified, to validation/test data -- never refit.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd

from utils import get_logger

log = get_logger()


# ---------------------------------------------------------------------------
# Missing-value imputation (training-fold climatology only)
# ---------------------------------------------------------------------------
def impute_with_training_climatology(df: pd.DataFrame, train_time_index: pd.DatetimeIndex, columns: Optional[list] = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Fill missing values using a monthly climatology (mean by calendar
    month-of-year) computed ONLY from `train_time_index` rows. Applied to
    the full `df` (train + val/test) afterwards, so no validation/test
    information ever enters the climatology estimate. Returns the imputed
    frame and a log of how many values were imputed per column/month.
    """
    columns = columns or list(df.columns)
    train_df = df.loc[df.index.intersection(train_time_index)]
    climatology = train_df[columns].groupby(train_df.index.month).mean()

    imputed = df.copy()
    log_rows = []
    for col in columns:
        missing_mask = imputed[col].isna()
        if not missing_mask.any():
            continue
        months = imputed.index[missing_mask].month
        fill_values = climatology.loc[months, col].values
        imputed.loc[missing_mask, col] = fill_values
        log_rows.append({"column": col, "n_imputed": int(missing_mask.sum())})

    log_df = pd.DataFrame(log_rows)
    if len(log_df):
        log.debug("Imputation (training-fold climatology) applied:\n%s", log_df.to_string(index=False))
    return imputed, log_df


# ---------------------------------------------------------------------------
# Fold-wise min-max normalization
# ---------------------------------------------------------------------------
@dataclass
class FoldScaler:
    """Min-max scaler fit on one fold's training data; reused, never refit, on val/test."""
    feature_min: pd.Series = field(default_factory=pd.Series)
    feature_max: pd.Series = field(default_factory=pd.Series)
    target_min: float = 0.0
    target_max: float = 1.0
    fitted: bool = False

    def fit(self, X_train: pd.DataFrame, y_train: pd.Series) -> "FoldScaler":
        self.feature_min = X_train.min()
        self.feature_max = X_train.max()
        self.target_min = float(y_train.min())
        self.target_max = float(y_train.max())
        self.fitted = True
        return self

    def _scale(self, X: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, int]]:
        denom = (self.feature_max - self.feature_min).replace(0, 1.0)
        below = (X < self.feature_min).sum().to_dict()
        above = (X > self.feature_max).sum().to_dict()
        scaled = (X - self.feature_min) / denom
        out_of_range = {col: int(below.get(col, 0) + above.get(col, 0)) for col in X.columns}
        return scaled, out_of_range

    def transform_X(self, X: pd.DataFrame, clip: bool = False) -> Tuple[pd.DataFrame, Dict[str, int]]:
        scaled, oor = self._scale(X)
        if clip:
            scaled = scaled.clip(lower=0.0, upper=1.0)
        return scaled, oor

    def transform_y(self, y: pd.Series) -> pd.Series:
        denom = (self.target_max - self.target_min) or 1.0
        return (y - self.target_min) / denom

    def inverse_transform_y(self, y_scaled: np.ndarray) -> np.ndarray:
        denom = (self.target_max - self.target_min) or 1.0
        return np.asarray(y_scaled) * denom + self.target_min


def normalize_fold(
    X_train: pd.DataFrame, y_train: pd.Series,
    X_val: pd.DataFrame, y_val: pd.Series,
    clip_out_of_range: bool = False,
) -> Tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series, FoldScaler, Dict]:
    """
    Fit a FoldScaler on (X_train, y_train) only, then transform both train
    and val. Returns scaled frames plus a diagnostics dict recording, per
    feature, how many validation values fell outside the training-derived
    [min, max] range (these are NOT silently clipped unless
    `clip_out_of_range=True` is explicitly requested).
    """
    scaler = FoldScaler().fit(X_train, y_train)
    X_train_s, oor_train = scaler.transform_X(X_train, clip=clip_out_of_range)
    X_val_s, oor_val = scaler.transform_X(X_val, clip=clip_out_of_range)
    y_train_s = scaler.transform_y(y_train)
    y_val_s = scaler.transform_y(y_val)

    diagnostics = {
        "feature_min": scaler.feature_min.to_dict(),
        "feature_max": scaler.feature_max.to_dict(),
        "target_min": scaler.target_min,
        "target_max": scaler.target_max,
        "val_out_of_range_counts": oor_val,
        "clipped": clip_out_of_range,
    }
    n_oor = sum(oor_val.values())
    if n_oor:
        log.debug("Normalization: %d validation values fell outside the training [min, max] range (clip=%s).", n_oor, clip_out_of_range)
    return X_train_s, y_train_s, X_val_s, y_val_s, scaler, diagnostics


# ---------------------------------------------------------------------------
# Sequence (3-D) normalization for LSTM / BiLSTM
# ---------------------------------------------------------------------------
@dataclass
class SequenceScaler:
    channel_min: np.ndarray = None
    channel_max: np.ndarray = None

    def fit(self, X_train: np.ndarray) -> "SequenceScaler":
        # X_train shape: (samples, window, channels)
        flat = X_train.reshape(-1, X_train.shape[-1])
        self.channel_min = np.nanmin(flat, axis=0)
        self.channel_max = np.nanmax(flat, axis=0)
        return self

    def transform(self, X: np.ndarray, clip: bool = False) -> Tuple[np.ndarray, np.ndarray]:
        denom = np.where((self.channel_max - self.channel_min) == 0, 1.0, self.channel_max - self.channel_min)
        below = (X < self.channel_min).sum(axis=(0, 1))
        above = (X > self.channel_max).sum(axis=(0, 1))
        scaled = (X - self.channel_min) / denom
        if clip:
            scaled = np.clip(scaled, 0.0, 1.0)
        oor_counts = (below + above)
        return scaled, oor_counts


def normalize_sequence_fold(
    X_train: np.ndarray, X_val: np.ndarray, clip_out_of_range: bool = False,
) -> Tuple[np.ndarray, np.ndarray, SequenceScaler, np.ndarray]:
    scaler = SequenceScaler().fit(X_train)
    X_train_s, _ = scaler.transform(X_train, clip=clip_out_of_range)
    X_val_s, oor_val = scaler.transform(X_val, clip=clip_out_of_range)
    return X_train_s, X_val_s, scaler, oor_val
