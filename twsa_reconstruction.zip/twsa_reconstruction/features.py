"""
features.py
============
Sections 4 and 5 of the spec: predictor construction, temporal input
structure, and correlation-based feature screening.

All functions here operate on a single grid cell's monthly time series
(a pandas DataFrame indexed by month-start Timestamp, columns = the 8
canonical predictors + 'twsa'). Looping over grid cells happens in
validation.py / reconstruction.py, not here.

Canonical predictor column order (fixed everywhere): precipitation,
temperature, evapotranspiration, wind_speed, soil_moisture,
humidity, shortwave_down, longwave_down.

The 6th predictor is generically named "humidity" rather than
"relative_humidity" because which physical quantity it actually holds
depends on what's available upstream (see build_predictor_target_frame):
true relative humidity (derived from specific humidity + temperature +
surface pressure, or supplied precomputed), OR specific humidity used
directly with no conversion, when surface pressure isn't available to
derive true RH. Whichever it is, it is documented in
predictor_preprocessing_provenance.csv -- never silently mislabeled.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from utils import get_logger, safe_corr

log = get_logger()

CANONICAL_PREDICTORS = (
    "precipitation", "temperature", "evapotranspiration", "wind_speed",
    "soil_moisture", "humidity", "shortwave_down", "longwave_down",
)


# ---------------------------------------------------------------------------
# Relative humidity derivation
# ---------------------------------------------------------------------------
def derive_relative_humidity(qair_kg_per_kg: np.ndarray, tair_K: np.ndarray, psurf_Pa: np.ndarray) -> np.ndarray:
    """
    GLDAS NOAH does not output relative humidity directly -- only specific
    humidity (Qair_f_inst, kg/kg). RH is derived from Qair, air temperature,
    and surface pressure using the standard approach:

      1. Actual vapor pressure from specific humidity (exact, from the
         definition of specific humidity and the ideal-gas mixing ratio):
             e = q * p / (0.622 + 0.378 * q)
      2. Saturation vapor pressure via the Tetens (1930) approximation
         (valid over liquid water, T in Celsius, es in Pa):
             es = 611.2 * exp(17.67 * T_C / (T_C + 243.5))
      3. RH = 100 * e / es, clipped to [0, 100].

    This is a standard meteorological approximation (not an invented
    formula) and introduces some error at sub-freezing temperatures
    (Tetens-over-ice would be more accurate there); that is documented
    as a known limitation rather than silently absorbed.
    """
    q = np.asarray(qair_kg_per_kg, dtype=float)
    T_K = np.asarray(tair_K, dtype=float)
    p = np.asarray(psurf_Pa, dtype=float)

    e = (q * p) / (0.622 + 0.378 * q)
    T_C = T_K - 273.15
    es = 611.2 * np.exp(17.67 * T_C / (T_C + 243.5))
    rh = 100.0 * e / es
    rh = np.clip(rh, 0.0, 100.0)
    return rh


def build_predictor_target_frame(raw_vars: Dict[str, np.ndarray], time_index: pd.DatetimeIndex, twsa: Optional[np.ndarray] = None) -> pd.DataFrame:
    """
    Assemble the canonical 8-predictor (+ optional target) DataFrame for one
    grid cell from the raw extracted 1-D time series (already masked and
    concatenated upstream; see pipeline.py / the v2 note in config.py --
    regridding and GLDAS-2.0/2.1 bias correction are assumed already done
    before the data reaches this function).

    `raw_vars` must contain keys: precipitation, temperature,
    evapotranspiration, wind_speed, soil_moisture_total, shortwave_down,
    longwave_down, and EXACTLY ONE of:
      - "humidity_precomputed" -- read directly as the humidity predictor,
        NO conversion attempted. This covers two cases upstream decides
        between: a true precomputed relative humidity variable, OR (as for
        the Godavari merged GLDAS file, which has specific humidity but no
        surface pressure to derive true RH from) specific humidity used
        as-is. Which one it actually is gets documented upstream in
        predictor_preprocessing_provenance.csv, not here.
      - "specific_humidity" + "surface_pressure" -- true relative humidity
        is derived here via derive_relative_humidity, as before.
    """
    if raw_vars.get("humidity_precomputed") is not None:
        humidity = raw_vars["humidity_precomputed"]
    else:
        humidity = derive_relative_humidity(
            raw_vars["specific_humidity"], raw_vars["temperature"], raw_vars["surface_pressure"]
        )
    data = {
        "precipitation": raw_vars["precipitation"],
        "temperature": raw_vars["temperature"],
        "evapotranspiration": raw_vars["evapotranspiration"],
        "wind_speed": raw_vars["wind_speed"],
        "soil_moisture": raw_vars["soil_moisture_total"],
        "humidity": humidity,
        "shortwave_down": raw_vars["shortwave_down"],
        "longwave_down": raw_vars["longwave_down"],
    }
    df = pd.DataFrame(data, index=time_index)
    if twsa is not None:
        df["twsa"] = twsa
    return df


# ---------------------------------------------------------------------------
# 4.1 Tabular lag features (RF / ANN / linear regression) -- 24 predictors
# ---------------------------------------------------------------------------
def make_tabular_dataset(df: pd.DataFrame, lags: Tuple[int, ...] = (0, 1, 2)) -> Tuple[pd.DataFrame, pd.Series]:
    """
    For each predictor X and each lag L in `lags`, build column
    f"{X}_lag{L}" = X shifted by L months (L=0 is the target month itself,
    L=1 is one month before, L=2 is two months before). Only past and
    present information relative to the target TWSA month is ever used.
    Rows without a full lag history (the first max(lags) months) are
    dropped, as are rows with any missing predictor value in the window.

    Returns (X, y) with a shared, aligned time index. Rows are kept as
    long as the full 24-feature predictor window is available, REGARDLESS
    of whether the target is observed -- `y` may contain NaN for months
    outside the GRACE record (needed by reconstruction.py to predict the
    1948-2002 extrapolative period). Callers that need a trainable
    (X, y) pair must drop NaN-y rows themselves (see
    validation.py::_tabular_fold_slice), which keeps that leakage-relevant
    decision explicit at the call site rather than hidden in here.
    """
    if "twsa" not in df.columns:
        raise ValueError("make_tabular_dataset requires a 'twsa' column as the target.")

    feature_cols = {}
    for var in CANONICAL_PREDICTORS:
        for lag in lags:
            feature_cols[f"{var}_lag{lag}"] = df[var].shift(lag)
    X = pd.DataFrame(feature_cols, index=df.index)
    y = df["twsa"]

    valid = X.notna().all(axis=1)
    X = X.loc[valid]
    y = y.loc[valid]
    return X, y


# ---------------------------------------------------------------------------
# 4.2 Lookback sequences (LSTM / BiLSTM)
# ---------------------------------------------------------------------------
def make_sequence_dataset(
    df: pd.DataFrame, window: int = 3, include_target_month: bool = True,
) -> Tuple[np.ndarray, pd.Series, List[str]]:
    """
    Build (samples, window, n_predictors) sequences for LSTM/BiLSTM.

    If `include_target_month` is True, the sequence for target month t is
    [t-window+1, ..., t-1, t] -- i.e. it includes the target month's OWN
    predictor values (legitimate: predictors are observed/modeled forcing
    data available for month t independent of the GRACE TWSA observation
    for that month; only the target itself is unknown). If False, the
    sequence ends at t-1, i.e. [t-window, ..., t-1], using no
    same-month predictor information at all. Either way, no predictor
    value from AFTER the target month is ever included.

    A row is kept whenever the full predictor window is available,
    REGARDLESS of whether the target is observed -- `y` may contain NaN
    for months outside the GRACE record (needed by reconstruction.py to
    predict the 1948-2002 extrapolative period). Callers that need a
    trainable pair must drop NaN-y rows themselves, exactly as for
    make_tabular_dataset.

    Returns X (ndarray), y (Series, aligned to the same valid timestamps,
    may contain NaN), and the ordered list of channel names
    (= CANONICAL_PREDICTORS).
    """
    if "twsa" not in df.columns:
        raise ValueError("make_sequence_dataset requires a 'twsa' column as the target.")

    n = len(df)
    values = df[list(CANONICAL_PREDICTORS)].values
    y_all = df["twsa"].values
    index = df.index

    samples, targets, valid_times = [], [], []
    start_offset = window - 1 if include_target_month else window
    for i in range(start_offset, n):
        if include_target_month:
            window_slice = values[i - window + 1 : i + 1]
        else:
            window_slice = values[i - window : i]
        if np.isnan(window_slice).any():
            continue
        samples.append(window_slice)
        targets.append(y_all[i])
        valid_times.append(index[i])

    X = np.stack(samples, axis=0) if samples else np.empty((0, window, len(CANONICAL_PREDICTORS)))
    y = pd.Series(targets, index=pd.DatetimeIndex(valid_times), name="twsa")
    return X, y, list(CANONICAL_PREDICTORS)


# ---------------------------------------------------------------------------
# 5.1 Correlation analysis (training data only, computed per fold/per cell
#     by the caller -- this module just computes it for whatever frame it
#     is given)
# ---------------------------------------------------------------------------
def correlation_matrices(X_train: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    pearson = X_train.corr(method="pearson")
    spearman = X_train.corr(method="spearman")
    return {"pearson": pearson, "spearman": spearman}


def target_correlations(X_train: pd.DataFrame, y_train: pd.Series, method: str = "pearson") -> pd.Series:
    return X_train.apply(lambda col: safe_corr(col.values, y_train.values, method=method) or 0.0)


# ---------------------------------------------------------------------------
# 5.2 Correlation-based feature screening (RF / ANN / linear regression)
# ---------------------------------------------------------------------------
def _lag_of(colname: str) -> int:
    # column names are "<var>_lag<N>"
    return int(colname.rsplit("lag", 1)[-1])


def screen_correlated_features(
    X_train: pd.DataFrame, y_train: pd.Series, threshold: float = 0.90, method: str = "pearson",
) -> Tuple[List[str], List[str], pd.DataFrame]:
    """
    Documented, reproducible screening rule, fit on TRAINING data only:

      1. Compute the full pairwise correlation matrix of the 24 candidate
         features and each feature's correlation with the training target.
      2. While any pair of currently-retained features has
         |corr| > threshold: take the pair with the single highest |corr|;
         drop whichever of the two has the LOWER |corr| with the training
         target (the documented target-association criterion, spec 5.2).
      3. Tie-break (equal |target corr| to within 1e-9): keep the feature
         with the SMALLER lag (more recent information), i.e. prefer
         lag0 over lag1 over lag2. This is the predefined scientific
         rationale used throughout the workflow for every tie.

    Returns (retained_columns, removed_columns, decision_log).
    """
    corr = X_train.corr(method=method).abs()
    tcorr = target_correlations(X_train, y_train, method=method).abs()

    remaining = list(X_train.columns)
    decisions = []

    while True:
        sub_df = corr.loc[remaining, remaining]
        if sub_df.empty:
            break
        sub_vals = sub_df.to_numpy(copy=True)
        np.fill_diagonal(sub_vals, 0.0)
        max_val = sub_vals.max()
        if max_val <= threshold:
            break
        idx = np.unravel_index(np.argmax(sub_vals), sub_vals.shape)
        feat_a, feat_b = remaining[idx[0]], remaining[idx[1]]

        tc_a, tc_b = tcorr[feat_a], tcorr[feat_b]
        if abs(tc_a - tc_b) < 1e-9:
            # tie -> keep smaller lag
            drop = feat_a if _lag_of(feat_a) > _lag_of(feat_b) else feat_b
        else:
            drop = feat_a if tc_a < tc_b else feat_b
        keep = feat_b if drop == feat_a else feat_a

        decisions.append({
            "dropped": drop, "conflicted_with": keep, "pairwise_corr": float(max_val),
            "target_corr_dropped": float(tcorr[drop]), "target_corr_kept": float(tcorr[keep]),
            "rule": "lower_target_correlation" if abs(tc_a - tc_b) >= 1e-9 else "tie_break_smaller_lag",
        })
        remaining.remove(drop)

    removed = [c for c in X_train.columns if c not in remaining]
    log_df = pd.DataFrame(decisions)
    log.debug("Correlation screening: retained %d/%d features (threshold=%.2f).",
               len(remaining), len(X_train.columns), threshold)
    return remaining, removed, log_df


def sequence_variable_screening_mask(
    flat_X_train: pd.DataFrame, y_train: pd.Series, threshold: float, variable_names: Tuple[str, ...] = CANONICAL_PREDICTORS,
) -> List[str]:
    """
    Optional, OFF by default (config.features.apply_correlation_screening_to_sequence_models).
    Fits the identical screening rule used for the tabular models on the
    current-month (lag0) slice of the same variables, purely to decide
    whether a whole VARIABLE CHANNEL should be dropped from the LSTM/BiLSTM
    input for an apples-to-apples comparison run. The default pipeline
    does NOT drop correlated channels from sequence models, per spec 5.2
    ("do not automatically remove ... solely because they exceed the
    threshold"); this function exists only to support the optional
    with/without comparison the spec also asks for.
    """
    lag0_cols = [f"{v}_lag0" for v in variable_names]
    present = [c for c in lag0_cols if c in flat_X_train.columns]
    retained, removed, _ = screen_correlated_features(flat_X_train[present], y_train, threshold=threshold)
    retained_vars = [c.replace("_lag0", "") for c in retained]
    return retained_vars
