"""
export.py
=========
Section 13 of the spec: writes every required output to its own
subdirectory under `cfg.paths.output_dir`, with descriptive filenames,
consistent coordinate conventions, and machine-readable formats
(CSV / NetCDF). Every writer here is pure I/O -- it takes already-computed
results (from validation.py, reconstruction.py, drought.py,
interpretation.py, temporal.py) and serializes them; no modeling logic
lives in this module.

All per-cell writers accept `cell_id = (lat, lon)` alongside each record so
every row in every CSV can be traced back to a grid cell without needing a
separate lookup table.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import xarray as xr

from config import Config
from utils import get_logger, ensure_dir

log = get_logger()


# ---------------------------------------------------------------------------
# Merge-on-write helper
# ---------------------------------------------------------------------------
# Every CSV writer below merges its new rows into whatever the same file
# already holds, instead of overwriting it outright. This is what lets
# pipeline.py's --models flag be used for several SEPARATE, smaller-memory
# runs (one for "baseline,random_forest", a later one for "ann", a later
# one for "lstm", etc. -- see pipeline.py's module docstring) while still
# ending up with ONE combined set of output files, as if it had all been
# one run. `group_cols` identifies which existing rows this run's new rows
# REPLACE: every existing row whose (group_cols) combination also appears
# in the new data is dropped, then the new rows are appended. This is a
# group-level replace, not a single-row upsert, so it also works for
# tables with several rows per key (e.g. one row per feature within a
# fold) as long as group_cols picks out the right group.
def _merge_write_csv(df: pd.DataFrame, path: Path, group_cols: List[str]) -> pd.DataFrame:
    path = Path(path)
    if not len(df):
        # Nothing new from this run -- leave any existing file from a
        # previous --models run completely untouched.
        if path.exists():
            try:
                return pd.read_csv(path)
            except Exception:
                return df
        return df
    if path.exists():
        try:
            existing = pd.read_csv(path)
        except Exception as exc:  # pragma: no cover - corrupt/partial file from an interrupted run
            log.warning("Could not read existing %s (%s); it will be overwritten by this run's data only.", path, exc)
            existing = pd.DataFrame()
        if len(existing) and all(c in existing.columns for c in group_cols) and all(c in df.columns for c in group_cols):
            new_keys = df[group_cols].drop_duplicates().assign(_this_run=1)
            existing_tagged = existing.merge(new_keys, on=group_cols, how="left")
            existing_kept = existing_tagged[existing_tagged["_this_run"].isna()].drop(columns=["_this_run"])
            combined = pd.concat([existing_kept, df], ignore_index=True, sort=False)
        else:
            combined = pd.concat([existing, df], ignore_index=True, sort=False) if len(existing) else df
    else:
        combined = df
    combined.to_csv(path, index=False)
    return combined


# ---------------------------------------------------------------------------
# 13.2 / 13.3 validation + final-test metrics and predictions
# ---------------------------------------------------------------------------
def export_fold_metrics(cell_results: List[Tuple[Tuple[float, float], object]], outdir: Path) -> None:
    rows = []
    for (lat, lon), result in cell_results:
        for rec in result.fold_metrics:
            rows.append({"lat": lat, "lon": lon, **rec})
    df = pd.DataFrame(rows)
    path = Path(outdir) / "foldwise_validation_metrics.csv"
    merged = _merge_write_csv(df, path, group_cols=["lat", "lon", "fold", "model"])
    log.info("Wrote fold-wise validation metrics: %s (%d new row(s) this run, %d total).", path, len(df), len(merged))

    # Pooled metrics are recomputed from the FULL merged file (not just this
    # run's rows), so a run covering only some model families still ends up
    # with correct pooled stats across every family accumulated so far.
    if len(merged):
        pooled = merged.groupby("model").apply(
            lambda g: pd.Series({
                "rmse_pooled": float(np.sqrt((g["rmse"] ** 2 * g["n"]).sum() / g["n"].sum())) if g["n"].sum() else np.nan,
                "mae_mean": g["mae"].mean(), "pearson_r_mean": g["pearson_r"].mean(), "n_total": g["n"].sum(),
            })
        ).reset_index()
        pooled_path = Path(outdir) / "pooled_out_of_fold_metrics_by_model.csv"
        pooled.to_csv(pooled_path, index=False)
        log.info("Wrote pooled out-of-fold metrics (recomputed over all accumulated runs): %s", pooled_path)


def export_oof_predictions(cell_results: List[Tuple[Tuple[float, float], object]], outdir: Path) -> None:
    rows = []
    for (lat, lon), result in cell_results:
        for rec in result.oof_predictions:
            rows.append({"lat": lat, "lon": lon, **rec})
    df = pd.DataFrame(rows)
    path = Path(outdir) / "pooled_out_of_fold_predictions.csv"
    merged = _merge_write_csv(df, path, group_cols=["lat", "lon", "fold", "model"])
    log.info("Wrote pooled out-of-fold predictions: %s (%d new row(s) this run, %d total).", path, len(df), len(merged))


def export_final_test(cell_results: List[Tuple[Tuple[float, float], object]], outdir: Path) -> None:
    pred_rows, metric_rows = [], []
    for (lat, lon), result in cell_results:
        for rec in result.final_test_predictions:
            pred_rows.append({"lat": lat, "lon": lon, **rec})
        for rec in result.final_test_metrics:
            metric_rows.append({"lat": lat, "lon": lon, **rec})
    pred_df, metric_df = pd.DataFrame(pred_rows), pd.DataFrame(metric_rows)
    merged_preds = _merge_write_csv(pred_df, Path(outdir) / "final_test_predictions.csv", group_cols=["lat", "lon", "model"])
    merged_metrics = _merge_write_csv(metric_df, Path(outdir) / "final_test_metrics.csv", group_cols=["lat", "lon", "model"])
    log.info("Wrote final-test predictions and metrics (%d / %d new row(s) this run, %d / %d total).",
              len(pred_df), len(metric_df), len(merged_preds), len(merged_metrics))


# ---------------------------------------------------------------------------
# 13.5 hyperparameters
# ---------------------------------------------------------------------------
def export_hyperparameters(cell_results: List[Tuple[Tuple[float, float], object]], outdir: Path) -> None:
    rows = []
    for (lat, lon), result in cell_results:
        for rec in result.hyperparameters:
            fold = rec.get("fold")
            for model_name, params in rec.items():
                if model_name == "fold":
                    continue
                rows.append({"lat": lat, "lon": lon, "fold": fold, "model": model_name, "params_json": json.dumps(params)})
        sel = result.selected_config.get("hyperparameters", {})
        for model_name, params in sel.items():
            rows.append({"lat": lat, "lon": lon, "fold": "selected_for_final_test_and_reconstruction",
                         "model": model_name, "params_json": json.dumps(params)})
    df = pd.DataFrame(rows)
    path = Path(outdir) / "selected_hyperparameters.csv"
    merged = _merge_write_csv(df, path, group_cols=["lat", "lon", "fold", "model"])
    log.info("Wrote hyperparameter records: %s (%d new row(s) this run, %d total).", path, len(df), len(merged))


# ---------------------------------------------------------------------------
# 13.6 feature-selection records
# ---------------------------------------------------------------------------
def export_feature_selection(cell_results: List[Tuple[Tuple[float, float], object]], outdir: Path) -> None:
    rows, decision_rows = [], []
    for (lat, lon), result in cell_results:
        for rec in result.feature_selection_records:
            rows.append({
                "lat": lat, "lon": lon, "fold": rec["fold"],
                "retained_json": json.dumps(rec["retained"]), "removed_json": json.dumps(rec["removed"]),
                "n_retained": len(rec["retained"]), "n_removed": len(rec["removed"]),
            })
            decisions = rec.get("decisions")
            if isinstance(decisions, pd.DataFrame) and len(decisions):
                d = decisions.copy()
                d.insert(0, "lat", lat); d.insert(1, "lon", lon); d.insert(2, "fold", rec["fold"])
                decision_rows.append(d)
    # Feature screening is model-independent (pure correlation analysis), so
    # it is identical across --models runs for the same cell/fold -- the
    # merge below is mostly a no-op overwrite-with-identical-values, kept
    # for consistency with every other per-cell/fold writer.
    _merge_write_csv(pd.DataFrame(rows), Path(outdir) / "feature_selection_summary.csv", group_cols=["lat", "lon", "fold"])
    if decision_rows:
        _merge_write_csv(pd.concat(decision_rows, ignore_index=True), Path(outdir) / "feature_selection_decision_log.csv",
                          group_cols=["lat", "lon", "fold"])
    log.info("Wrote feature-selection records (%d cell-folds this run).", len(rows))


# ---------------------------------------------------------------------------
# 13.7 correlation matrices
# ---------------------------------------------------------------------------
def export_correlation_matrices(cell_results: List[Tuple[Tuple[float, float], object]], outdir: Path) -> None:
    """
    Written in long format: lat, lon, fold, feature_i, feature_j, pearson,
    spearman. This scales with n_cells x n_folds x 24^2 features, so for a
    large study area consider setting cfg.max_grid_cells for an exploratory
    run, or post-filter this file to the cells of interest.
    """
    rows = []
    for (lat, lon), result in cell_results:
        for rec in result.correlation_records:
            pear, spear = rec["pearson"], rec["spearman"]
            for fi in pear.columns:
                for fj in pear.columns:
                    rows.append({
                        "lat": lat, "lon": lon, "fold": rec["fold"],
                        "feature_i": fi, "feature_j": fj,
                        "pearson": float(pear.loc[fi, fj]), "spearman": float(spear.loc[fi, fj]),
                    })
    df = pd.DataFrame(rows)
    path = Path(outdir) / "correlation_matrices_long_format.csv"
    # Also model-independent (see export_feature_selection) -- merged for
    # consistency, not because different --models runs actually disagree.
    merged = _merge_write_csv(df, path, group_cols=["lat", "lon", "fold"])
    log.info("Wrote correlation matrices: %s (%d new row(s) this run, %d total).", path, len(df), len(merged))


# ---------------------------------------------------------------------------
# 13.8 SHAP results
# ---------------------------------------------------------------------------
def export_shap_results(shap_records: List[Dict], outdir: Path) -> None:
    """
    `shap_records`: list of dicts, each with keys lat, lon, model, method,
    n_samples_explained, variable_importance (pd.Series), and optionally
    timestep_importance (pd.Series) for LSTM/BiLSTM.
    """
    var_rows, step_rows = [], []
    for rec in shap_records:
        for feature, val in rec["variable_importance"].items():
            var_rows.append({
                "lat": rec["lat"], "lon": rec["lon"], "model": rec["model"], "method": rec["method"],
                "n_samples_explained": rec["n_samples_explained"], "feature": feature, "mean_abs_shap": float(val),
            })
        if "timestep_importance" in rec:
            for step, val in rec["timestep_importance"].items():
                step_rows.append({
                    "lat": rec["lat"], "lon": rec["lon"], "model": rec["model"], "method": rec["method"],
                    "timestep": step, "mean_abs_shap": float(val),
                })
    merged_var = _merge_write_csv(pd.DataFrame(var_rows), Path(outdir) / "shap_variable_importance.csv", group_cols=["lat", "lon", "model"])
    merged_step = pd.DataFrame()
    if step_rows:
        merged_step = _merge_write_csv(pd.DataFrame(step_rows), Path(outdir) / "shap_timestep_importance.csv", group_cols=["lat", "lon", "model"])
    log.info("Wrote SHAP results (%d/%d new variable-level rows, %d/%d new timestep-level rows, this run/total).",
              len(var_rows), len(merged_var), len(step_rows), len(merged_step))


# ---------------------------------------------------------------------------
# 13.9 normalization diagnostics
# ---------------------------------------------------------------------------
def export_normalization_diagnostics(cell_results: List[Tuple[Tuple[float, float], object]], outdir: Path) -> None:
    rows = []
    for (lat, lon), result in cell_results:
        for rec in result.diagnostics:
            if rec.get("type") != "normalization":
                continue
            for feature in rec.get("feature_min", {}):
                rows.append({
                    "lat": lat, "lon": lon, "fold": rec["fold"], "feature": feature,
                    "train_min": rec["feature_min"][feature], "train_max": rec["feature_max"][feature],
                    "n_val_out_of_range": rec.get("val_out_of_range_counts", {}).get(feature, 0),
                    "clipped": rec.get("clipped", False),
                })
    df = pd.DataFrame(rows)
    merged = _merge_write_csv(df, Path(outdir) / "normalization_diagnostics.csv", group_cols=["lat", "lon", "fold"])
    log.info("Wrote normalization diagnostics (%d new row(s) this run, %d total).", len(df), len(merged))


# ---------------------------------------------------------------------------
# 13.4 drought-validation results
# ---------------------------------------------------------------------------
def export_drought_results(
    cell_drought_records: List[Dict], outdir: Path,
) -> None:
    """`cell_drought_records`: list of dicts with lat, lon, events (list of DroughtEvent),
    per_event_metrics (DataFrame), overall_metrics (DataFrame)."""
    event_rows, per_event_metric_rows, overall_rows = [], [], []
    for rec in cell_drought_records:
        lat, lon = rec["lat"], rec["lon"]
        for ev in rec["events"]:
            event_rows.append({"lat": lat, "lon": lon, "event_id": ev.event_id, "start": ev.start,
                                "end": ev.end, "n_months": ev.n_months, "min_z": ev.min_z})
        pe = rec["per_event_metrics"].copy()
        if len(pe):
            pe.insert(0, "lat", lat); pe.insert(1, "lon", lon)
            per_event_metric_rows.append(pe)
        ov = rec["overall_metrics"].copy()
        if len(ov):
            ov.insert(0, "lat", lat); ov.insert(1, "lon", lon)
            overall_rows.append(ov)

    # Event definitions are model-independent (derived from the GRACE
    # target series alone); per-event/overall metrics are per-model and
    # merged accordingly so a later --models run adds to, rather than
    # replaces, an earlier run's drought metrics for other families.
    _merge_write_csv(pd.DataFrame(event_rows), Path(outdir) / "drought_event_definitions.csv", group_cols=["lat", "lon", "event_id"])
    if per_event_metric_rows:
        _merge_write_csv(pd.concat(per_event_metric_rows, ignore_index=True), Path(outdir) / "drought_per_event_metrics.csv",
                          group_cols=["lat", "lon", "event_id", "model"])
    if overall_rows:
        _merge_write_csv(pd.concat(overall_rows, ignore_index=True), Path(outdir) / "drought_overall_metrics.csv",
                          group_cols=["lat", "lon", "model"])
    log.info("Wrote drought-validation results (%d events across all cells this run).", len(event_rows))


# ---------------------------------------------------------------------------
# 13.10 predictor-preprocessing provenance  /  13.11 precipitation-source table
# ---------------------------------------------------------------------------
def export_predictor_provenance(provenance_df: pd.DataFrame, outdir: Path) -> None:
    """
    v2: the pipeline no longer performs GLDAS-2.0/2.1 overlap bias
    correction itself (see config.py's v2 note) -- this records what WAS
    assumed about the predictor_files supplied to it (already bias-
    corrected, unit-consistent, and -- unless flagged otherwise -- already
    on the GRACE grid), in place of the old bias-correction diagnostics
    table, so the provenance of the predictor data is still documented.
    """
    path = Path(outdir) / "predictor_preprocessing_provenance.csv"
    provenance_df.to_csv(path, index=False)
    log.info("Wrote predictor preprocessing provenance: %s", path)


def export_precipitation_source_table(source_df: pd.DataFrame, outdir: Path) -> None:
    path = Path(outdir) / "precipitation_source_table.csv"
    source_df.to_csv(path, index=False)
    log.info("Wrote precipitation source documentation table: %s", path)


def export_precipitation_comparison(comparison_df: pd.DataFrame, outdir: Path) -> None:
    path = Path(outdir) / "precipitation_source_comparison_metrics.csv"
    comparison_df.to_csv(path, index=False)
    log.info("Wrote precipitation-source comparison metrics: %s", path)


# ---------------------------------------------------------------------------
# Basin-average hyperparameter-sensitivity comparison (manuscript figure;
# see basin_average.py::run_hparam_sensitivity). Basin-average-only -- no
# per-grid-cell equivalent of this writer exists, by design.
# ---------------------------------------------------------------------------
def export_hparam_sensitivity_metrics(metrics_df: pd.DataFrame, outdir: Path) -> None:
    path = Path(outdir) / "basin_average_hparam_sensitivity_metrics.csv"
    if not len(metrics_df):
        log.warning("No basin-average hyperparameter-sensitivity metrics to write (%s).", path)
        return
    metrics_df.to_csv(path, index=False)
    log.info("Wrote basin-average hyperparameter-sensitivity metrics: %s (%d rows).", path, len(metrics_df))


def export_hparam_sensitivity_reconstruction(recon_df: pd.DataFrame, outdir: Path) -> None:
    path = Path(outdir) / "basin_average_hparam_sensitivity_reconstruction.csv"
    if not len(recon_df):
        log.warning("No basin-average hyperparameter-sensitivity reconstruction to write (%s).", path)
        return
    recon_df.to_csv(path, index=False)
    log.info("Wrote basin-average hyperparameter-sensitivity reconstruction: %s (%d rows, %d model/config combos).",
              path, len(recon_df), recon_df[["model", "config_label"]].drop_duplicates().shape[0])


# ---------------------------------------------------------------------------
# 13.12 model diagnostics
# ---------------------------------------------------------------------------
def export_model_diagnostics(cell_results: List[Tuple[Tuple[float, float], object]], skipped_cells: List[Dict], outdir: Path) -> None:
    rows = []
    for (lat, lon), result in cell_results:
        for rec in result.diagnostics:
            if rec.get("type") == "normalization":
                continue
            rows.append({"lat": lat, "lon": lon, **rec})
    for rec in skipped_cells:
        rows.append(rec)
    df = pd.DataFrame(rows)
    path = Path(outdir) / "model_diagnostics_and_skipped_cells.csv"
    # Diagnostics are free-text messages, not keyed to one model family, and
    # the same cell can legitimately produce different messages across
    # separate --models runs -- so this one accumulates by simple
    # exact-row dedup rather than the group-replace merge used elsewhere.
    if path.exists():
        try:
            existing = pd.read_csv(path)
            df = pd.concat([existing, df], ignore_index=True, sort=False).drop_duplicates()
        except Exception as exc:  # pragma: no cover
            log.warning("Could not read existing %s (%s); overwriting with this run's data only.", path, exc)
    df.to_csv(path, index=False)
    log.info("Wrote model diagnostics / skipped-cell log (%d rows this run, %d total).", len(rows), len(df))


def _merge_single_model_netcdf(new_ds: xr.Dataset, path: Path) -> xr.Dataset:
    """
    Per-model analogue of the old cross-model merge (kept for the same
    reason): merges this run's single-model reconstruction with whatever
    NetCDF already exists at `path` for THIS model (e.g. a previous
    --models run that already fit this same family for a different set
    of cells, or a rerun with --max-cells covering different cells),
    expanding to the union of time/lat/lon. This run's values win
    wherever it produced a real (non-NaN) number; everywhere else, the
    existing file's value is kept.
    """
    if not path.exists():
        return new_ds
    try:
        existing = xr.load_dataset(path)
    except Exception as exc:  # pragma: no cover - corrupt/partial file from an interrupted run
        log.warning("Could not read existing %s (%s); it will be overwritten by this run's data only.", path, exc)
        return new_ds

    all_times = pd.DatetimeIndex(sorted(
        set(pd.DatetimeIndex(existing["time"].values)) | set(pd.DatetimeIndex(new_ds["time"].values))
    ))
    all_lat = np.array(sorted(set(existing["lat"].values.tolist()) | set(new_ds["lat"].values.tolist())))
    all_lon = np.array(sorted(set(existing["lon"].values.tolist()) | set(new_ds["lon"].values.tolist())))

    existing_twsa = existing["twsa_reconstructed"].reindex(time=all_times, lat=all_lat, lon=all_lon, fill_value=np.nan)
    new_twsa = new_ds["twsa_reconstructed"].reindex(time=all_times, lat=all_lat, lon=all_lon, fill_value=np.nan)
    merged_twsa = new_twsa.where(np.isfinite(new_twsa), existing_twsa)

    existing_obs = existing["grace_observed"].reindex(time=all_times, lat=all_lat, lon=all_lon, fill_value=False).astype(bool)
    new_obs = new_ds["grace_observed"].reindex(time=all_times, lat=all_lat, lon=all_lon, fill_value=False).astype(bool)
    merged_obs = existing_obs | new_obs

    merged = xr.Dataset(
        {"twsa_reconstructed": merged_twsa, "grace_observed": merged_obs},
        coords={"time": all_times, "lat": all_lat, "lon": all_lon},
    )
    merged.attrs.update(existing.attrs)
    merged.attrs.update(new_ds.attrs)
    merged.attrs["note_on_merging"] = (
        "This file was assembled across more than one pipeline run for the SAME model family "
        "(see pipeline.py's --models / --max-cells flags): each run's non-NaN values win, "
        "without erasing cells/months fit by an earlier run of this same model."
    )
    existing.close()
    return merged


# ---------------------------------------------------------------------------
# 13.1 reconstructed TWSA NetCDF -- ONE FILE PER MODEL
# ---------------------------------------------------------------------------
def export_reconstruction_netcdf(
    cell_reconstructions: List, grace_lat: np.ndarray, grace_lon: np.ndarray, cfg: Config, outdir: Path,
) -> Dict[str, Path]:
    """
    Assemble per-cell CellReconstruction objects into SEPARATE NetCDF
    files, one per model family (linear_regression, random_forest, ann,
    lstm, bilstm, ensemble -- whichever of these actually got fit for at
    least one cell this run), each with dims (time, lat, lon) and a
    boolean (time, lat, lon) `grace_observed` flag. Returns
    {model_name: path_written}.

    One file per model (rather than one combined file with a 'model'
    dimension) is deliberate: it lets each model's reconstruction be
    opened, shared, or compared independently, and keeps the GLDAS-only
    vs. GLDAS+IMD precipitation scenarios (see cfg.precipitation_source
    and pipeline.py's --precip-source flag, which routes each scenario to
    its own output folder) trivially diff-able file-by-file.
    """
    all_times = sorted(set().union(*[set(cr.reconstructed.index) for cr in cell_reconstructions if len(cr.reconstructed)]))
    all_times = pd.DatetimeIndex(all_times)
    model_names = sorted(set().union(*[set(cr.reconstructed.columns) for cr in cell_reconstructions if len(cr.reconstructed)]))

    lat_idx = {v: i for i, v in enumerate(grace_lat)}
    lon_idx = {v: i for i, v in enumerate(grace_lon)}

    arr = np.full((len(model_names), len(all_times), len(grace_lat), len(grace_lon)), np.nan, dtype=np.float32)
    observed_flag = np.zeros((len(all_times), len(grace_lat), len(grace_lon)), dtype=bool)

    time_pos = {t: i for i, t in enumerate(all_times)}
    for cr in cell_reconstructions:
        if not len(cr.reconstructed):
            continue
        lat, lon = cr.cell_id
        if lat not in lat_idx or lon not in lon_idx:
            continue
        i_lat, i_lon = lat_idx[lat], lon_idx[lon]
        for m_i, model_name in enumerate(model_names):
            if model_name not in cr.reconstructed.columns:
                continue
            series = cr.reconstructed[model_name]
            for t, val in series.items():
                if t in time_pos and np.isfinite(val):
                    arr[m_i, time_pos[t], i_lat, i_lon] = val
        for t, flag in cr.is_grace_observed.items():
            if t in time_pos and flag:
                observed_flag[time_pos[t], i_lat, i_lon] = True

    ensure_dir(outdir)
    written_paths: Dict[str, Path] = {}
    for m_i, model_name in enumerate(model_names):
        ds_m = xr.Dataset(
            {
                "twsa_reconstructed": (("time", "lat", "lon"), arr[m_i]),
                "grace_observed": (("time", "lat", "lon"), observed_flag),
            },
            coords={"time": all_times, "lat": grace_lat, "lon": grace_lon},
        )
        ds_m["twsa_reconstructed"].attrs.update(
            units="cm", long_name=f"Reconstructed terrestrial water storage anomaly ({model_name})",
            note="Months where grace_observed=False are extrapolative model-based estimates, "
                 "not directly validated against GRACE. See 03_final_test_results and "
                 "02_validation_metrics for validation coverage.",
        )
        ds_m["grace_observed"].attrs["long_name"] = "True where an actual GRACE/GRACE-FO JPL observation exists for this month/cell"
        ds_m.attrs.update(
            title=f"Reconstructed TWSA, 1948-2024 (Godavari study area) -- model: {model_name}",
            model=model_name,
            predictor_source="GLDAS-derived predictor file(s), pre-bias-corrected/unit-fixed/regridded "
                              "by the user outside this pipeline (see config.py predictor_files)",
            target_source="GRACE/GRACE-FO JPL RL06.3Mv04 CRI mascons, gain-factor corrected",
            precipitation_source_policy=cfg.precipitation_source,
            reconstruction_fit_period=f"{cfg.temporal.grace_development_start}..{cfg.temporal.final_test_end}",
        )
        path = Path(outdir) / f"reconstructed_twsa_{model_name}_1948_2024.nc"
        merged_ds = _merge_single_model_netcdf(ds_m, path)
        # Write to a temp path first and replace -- avoids truncating the
        # existing file we may have just read from (xr.load_dataset above
        # loads fully into memory, so this is safe, but to_netcdf directly
        # over the same path it was opened from can still fail on some
        # platforms/backends).
        tmp_path = path.with_suffix(".nc.tmp")
        merged_ds.to_netcdf(tmp_path)
        merged_ds.close()
        tmp_path.replace(path)
        written_paths[model_name] = path
        log.info("Wrote reconstructed TWSA NetCDF for model '%s': %s", model_name, path)

    log.info("Wrote %d separate per-model reconstruction NetCDF file(s) (precipitation_source=%s): %s",
              len(written_paths), cfg.precipitation_source, list(written_paths.keys()))
    return written_paths
