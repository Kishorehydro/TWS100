"""
spatial.py
==========
Section 2 of the spec: spatial preprocessing and grid alignment.

  - Regrid every predictor dataset onto the GRACE 0.5-degree target grid
    BEFORE any lagged feature or lookback sequence is built.
  - Apply the study-area polygon mask with a documented boundary convention.
  - Verify spatial alignment after regridding.

Regridding method
------------------
GLDAS NOAH ships on a 0.25-degree grid; GRACE JPL mascons are gridded at
0.5 degrees. 0.25-degree cell edges fall exactly on the 0.5-degree cell
edges (both grids tile the sphere starting from integer-degree lines), so
each 0.5-degree target cell contains an integer number of 0.25-degree
source cells. We therefore use an **area-weighted block average**
(equivalent to conservative remapping on this nested grid): every GRACE
cell's value is the unweighted mean of the source cells whose centers fall
inside it. This is appropriate for all 8 predictors here because none of
them are categorical, and all are either flux densities (precipitation,
ET, radiation), per-unit-area storages (soil moisture), or locally-defined
state variables (temperature, wind, humidity terms) -- a spatial average
is the physically correct aggregation for every one of these. If a future
predictor were categorical (e.g. a land-cover class), majority-vote
resampling would be used instead; there is no such variable in this
workflow.

One required longitude fix: GLDAS uses a -180..180 convention, GRACE uses
0..360. Longitudes are normalized to 0..360 before regridding.
"""

from __future__ import annotations

from typing import Tuple

import numpy as np
import pandas as pd
import xarray as xr

from utils import get_logger, PipelineError

log = get_logger()


def _normalize_lon_0_360(ds: xr.Dataset, lon_dim: str = "lon") -> xr.Dataset:
    lon = ds[lon_dim].values
    new_lon = np.mod(lon, 360.0)
    ds = ds.assign_coords({lon_dim: new_lon})
    ds = ds.sortby(lon_dim)
    return ds


def _target_edges(centers: np.ndarray) -> np.ndarray:
    """Cell edges for a uniformly spaced coordinate, inferred from centers."""
    step = float(np.median(np.diff(np.sort(centers))))
    sorted_centers = np.sort(centers)
    edges = np.concatenate([
        sorted_centers - step / 2.0,
        [sorted_centers[-1] + step / 2.0],
    ])
    return edges


def regrid_to_grace_grid(ds: xr.Dataset, target_lat: xr.DataArray, target_lon: xr.DataArray) -> xr.Dataset:
    """
    Area-weighted block-average regridding of `ds` (lat/lon in degrees)
    onto the (target_lat, target_lon) GRACE grid. Works for any clean
    N:1 nesting of source cells inside target cells; falls back safely
    (NaN) for target cells with no source data (e.g. ocean cells in a
    land-only product -- irrelevant once the study-area mask is applied).
    """
    ds = _normalize_lon_0_360(ds, "lon")

    lat_edges = _target_edges(target_lat.values)
    lon_edges = _target_edges(target_lon.values)

    lat_labels = target_lat.values
    lon_labels = target_lon.values

    lat_bin = pd.cut(ds["lat"].values, bins=lat_edges, labels=False, include_lowest=True)
    lon_bin = pd.cut(ds["lon"].values, bins=lon_edges, labels=False, include_lowest=True)

    ds = ds.assign_coords(lat_bin=("lat", lat_bin), lon_bin=("lon", lon_bin))

    # Source rows/cols that fall outside every target edge come back as NaN
    # bins from pd.cut; drop them before grouping.
    valid_lat_mask = ~pd.isna(lat_bin)
    valid_lon_mask = ~pd.isna(lon_bin)
    ds = ds.isel(lat=np.where(valid_lat_mask)[0], lon=np.where(valid_lon_mask)[0])
    lat_bin = lat_bin[valid_lat_mask]
    lon_bin = lon_bin[valid_lon_mask]
    ds = ds.assign_coords(lat_bin=("lat", lat_bin.astype(int)), lon_bin=("lon", lon_bin.astype(int)))

    grouped = ds.groupby("lat_bin").mean(dim="lat", skipna=True)
    grouped = grouped.groupby("lon_bin").mean(dim="lon", skipna=True)

    n_lat, n_lon = len(lat_labels), len(lon_labels)
    out = grouped.reindex(lat_bin=np.arange(n_lat), lon_bin=np.arange(n_lon))
    out = out.rename({"lat_bin": "lat", "lon_bin": "lon"})
    out = out.assign_coords(lat=("lat", lat_labels), lon=("lon", lon_labels))
    return out


def regrid_predictor_dataset(predictor_ds: xr.Dataset, grace_ds: xr.Dataset, label: str) -> xr.Dataset:
    log.info("Regridding %s onto GRACE grid (%d x %d -> %d x %d)...",
              label, predictor_ds.sizes["lat"], predictor_ds.sizes["lon"],
              grace_ds.sizes["lat"], grace_ds.sizes["lon"])
    out = regrid_to_grace_grid(predictor_ds, grace_ds["lat"], grace_ds["lon"])
    out.attrs.update(predictor_ds.attrs)
    out.attrs["regridded_from"] = f"{predictor_ds.sizes['lat']}x{predictor_ds.sizes['lon']} 0.25deg"
    out.attrs["regridded_to"] = f"{grace_ds.sizes['lat']}x{grace_ds.sizes['lon']} 0.5deg (GRACE grid)"
    out.attrs["regrid_method"] = "area-weighted block average (nested 0.25deg -> 0.5deg)"
    verify_spatial_alignment(out, grace_ds, label)
    return out


def verify_spatial_alignment(ds: xr.Dataset, grace_ds: xr.Dataset, label: str, atol: float = 1e-6) -> None:
    lat_ok = np.allclose(ds["lat"].values, grace_ds["lat"].values, atol=atol)
    lon_ok = np.allclose(ds["lon"].values, grace_ds["lon"].values, atol=atol)
    if not (lat_ok and lon_ok):
        raise PipelineError(f"[{label}] spatial coordinates do not match the GRACE grid after regridding.")
    log.info("[%s] spatial alignment verified against GRACE grid.", label)


# ---------------------------------------------------------------------------
# Polygon masking
# ---------------------------------------------------------------------------
def build_cell_mask(lat: np.ndarray, lon: np.ndarray, gdf, convention: str = "centroid_within") -> Tuple[np.ndarray, pd.DataFrame]:
    """
    Build a boolean (len(lat), len(lon)) mask of grid cells belonging to the
    study area, plus a DataFrame of per-cell fractional polygon-overlap
    (diagnostic only; the binary mask itself always uses the documented
    `convention`).

    Documented masking convention (`centroid_within`, the only one
    implemented and used throughout this workflow): a grid cell is part of
    the study area if and only if the cell's CENTER point (its (lat, lon)
    coordinate as given by the GRACE grid) falls inside the polygon. This
    is applied identically to the modeling domain and to every exported
    result -- a cell is either fully in or fully out, there is no partial
    weighting of model inputs/outputs by overlap fraction. The fractional
    overlap column returned alongside is for transparency on boundary
    cells only and is NOT used to weight anything.
    """
    import geopandas as gpd
    from shapely.geometry import box, Point
    from shapely.ops import unary_union

    if convention != "centroid_within":
        raise PipelineError(f"Unsupported masking convention: {convention}")

    polygon = unary_union(gdf.geometry.values)

    lon_grid, lat_grid = np.meshgrid(lon, lat)  # shape (n_lat, n_lon)
    flat_lon = lon_grid.ravel()
    flat_lat = lat_grid.ravel()

    # Shift target lon into whatever domain the polygon's bounds use
    # (shapefile is typically -180..180; GRACE grid is 0..360).
    poly_minx, _, poly_maxx, _ = polygon.bounds
    query_lon = flat_lon.copy()
    if poly_maxx <= 180.5:
        query_lon = np.where(query_lon > 180, query_lon - 360, query_lon)

    points = gpd.GeoSeries(gpd.points_from_xy(query_lon, flat_lat), crs=gdf.crs)
    within = points.within(polygon).values.reshape(lat_grid.shape)

    lat_res = float(np.median(np.abs(np.diff(np.sort(lat)))))
    lon_res = float(np.median(np.abs(np.diff(np.sort(lon)))))
    query_lon_grid = query_lon.reshape(lat_grid.shape)
    overlap_rows = []
    boundary_candidates = np.argwhere(within)
    for i, j in boundary_candidates:
        cell_lon = query_lon_grid[i, j]
        cell_poly = box(
            cell_lon - lon_res / 2.0,
            lat[i] - lat_res / 2.0,
            cell_lon + lon_res / 2.0,
            lat[i] + lat_res / 2.0,
        )
        inter = cell_poly.intersection(polygon)
        frac = inter.area / cell_poly.area if cell_poly.area > 0 else 0.0
        overlap_rows.append({"lat": lat[i], "lon": lon[j], "overlap_fraction": frac})

    overlap_df = pd.DataFrame(overlap_rows)
    n_cells = int(within.sum())
    log.info("Study-area mask built (%s convention): %d grid cells selected.", convention, n_cells)
    if n_cells == 0:
        raise PipelineError(
            "Study-area polygon mask selected zero grid cells. Check that the "
            "shapefile CRS/extent genuinely overlaps the GRACE/GLDAS domain."
        )
    return within, overlap_df


def apply_mask_to_dataset(ds: xr.Dataset, mask: np.ndarray) -> xr.Dataset:
    mask_da = xr.DataArray(mask, dims=("lat", "lon"), coords={"lat": ds["lat"], "lon": ds["lon"]})
    masked = ds.where(mask_da)
    masked.attrs["study_area_mask_applied"] = "True"
    masked.attrs["n_masked_cells"] = int(mask.sum())
    return masked
