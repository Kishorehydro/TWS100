"""
utils.py
========
Logging setup, reproducible-seed helpers, and small shared utilities used
across every module. Centralized here so every module logs consistently
and every random process is seeded from the same place.
"""

from __future__ import annotations

import logging
import os
import random
import sys
from pathlib import Path
from typing import Optional

import numpy as np


_LOGGER_INITIALIZED = False


def setup_logging(log_dir: str = "./logs", level: str = "INFO", run_name: str = "twsa_pipeline") -> logging.Logger:
    """
    Configure a root logger that writes to both stdout and a timestamped
    file under `log_dir`. Safe to call multiple times (re-configures only
    once per process).
    """
    global _LOGGER_INITIALIZED
    logger = logging.getLogger("twsa")
    if _LOGGER_INITIALIZED:
        return logger

    Path(log_dir).mkdir(parents=True, exist_ok=True)
    log_path = Path(log_dir) / f"{run_name}.log"

    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    fmt = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(fmt)
    logger.addHandler(stream_handler)

    file_handler = logging.FileHandler(log_path, mode="a")
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    logger.propagate = False
    _LOGGER_INITIALIZED = True
    logger.info("Logging initialized. Log file: %s", log_path.resolve())
    return logger


def get_logger() -> logging.Logger:
    return logging.getLogger("twsa")


def set_global_seed(seed: int = 42) -> None:
    """Seed Python, NumPy, and (if installed) TensorFlow for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    try:
        import tensorflow as tf  # noqa: WPS433 (conditional import by design)
        tf.random.set_seed(seed)
    except ImportError:
        pass


class PipelineError(RuntimeError):
    """Raised for configuration/validation failures that should stop the run."""


# Known model-family groups the pipeline can be told to run (see
# config.py::Config.models_to_run and pipeline.py's --models CLI flag).
# "baseline" bundles the three cheap, untuned models (persistence,
# climatology, linear_regression) since there is no reason to ever split
# those further -- they add negligible memory/time individually.
MODEL_GROUPS = ("baseline", "random_forest", "ann", "lstm", "bilstm")
BASELINE_MODEL_NAMES = ("persistence", "climatology", "linear_regression")


def clear_keras_memory() -> None:
    """
    Release TensorFlow/Keras graph + GPU/CPU memory accumulated by
    building many small ANN/LSTM/BiLSTM models in a loop (one call to
    tune_ann/tune_rnn per fold per grid cell adds up fast across a whole
    basin -- this is the single biggest source of the memory growth this
    helper exists to stop). Call it as soon as a Keras model's
    predictions have been extracted to plain numpy/pandas and the model
    object itself is no longer needed. Safe to call even when TensorFlow
    isn't installed or no Keras model has been built yet in this process.
    """
    import gc
    try:
        from tensorflow.keras import backend as K
        K.clear_session()
    except Exception:  # pragma: no cover - TF optional / already clean
        pass
    gc.collect()


def months_in_range(start: str, end: str):
    """Return a pandas monthly DatetimeIndex, timestamped at month start, inclusive."""
    import pandas as pd
    return pd.date_range(start=start, end=end, freq="MS")


def days_in_month(timestamp) -> int:
    """Number of days in the calendar month containing `timestamp`."""
    import pandas as pd
    ts = pd.Timestamp(timestamp)
    return ts.days_in_month


def ensure_dir(path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def safe_corr(a: np.ndarray, b: np.ndarray, method: str = "pearson") -> Optional[float]:
    """
    Correlation that returns None (instead of raising/NaN-propagating
    silently) when there are fewer than 3 valid paired samples or zero
    variance in either series.
    """
    import pandas as pd
    mask = np.isfinite(a) & np.isfinite(b)
    if mask.sum() < 3:
        return None
    a_, b_ = a[mask], b[mask]
    if np.nanstd(a_) == 0 or np.nanstd(b_) == 0:
        return None
    s = pd.Series(a_).corr(pd.Series(b_), method=method)
    return float(s) if np.isfinite(s) else None
