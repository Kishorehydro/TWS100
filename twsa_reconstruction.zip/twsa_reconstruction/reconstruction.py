"""
reconstruction.py
==================
Section 12 of the spec: reconstruction for 1948-2024.

For each grid cell, after validation.py has (a) selected hyperparameters
and screened features using development-period data only, and (b)
reported final-test (2021-2024) metrics with a model that never saw
2021-2024 during fitting, this module:

  1. Re-fits each tuned model family on ALL available GRACE-observed
     months (2003-2024) -- using the SAME fixed hyperparameters and the
     SAME feature-screening procedure (re-fit on 2003-2024, exactly as
     before, never re-tuned) -- to use every observed month of signal
     for the historical reconstruction.
  2. Generates predictions for every month in 1948-2024 where the
     required predictor data exist, labeling each month as
     "observed_period" (inside 2003-2024, where a real GRACE value also
     exists for comparison) or "extrapolative" (1948-2002, where no
     GRACE observation exists to validate against).
  3. Builds a simple unweighted-mean ensemble across whichever model
     families were successfully fit, when more than one is available,
     and documents that this is the combination method used (there is no
     evidence basis yet for performance-weighting the ensemble beyond
     the already-separately-reported section 8/9 metrics).
  4. Does NOT touch, recompute, or overwrite the final-test metrics
     already produced by validation.py -- those are preserved exactly as
     reported from the pre-refit model, per the spec's explicit
     instruction.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import features as feat
import models as mdl
import preprocessing as prep
from config import Config
from utils import get_logger, clear_keras_memory, MODEL_GROUPS

log = get_logger()


@dataclass
class CellReconstruction:
    cell_id: tuple
    reconstructed: pd.DataFrame = field(default_factory=pd.DataFrame)  # index=time, columns=model names + 'ensemble'
    is_grace_observed: pd.Series = field(default_factory=pd.Series)    # True where a real GRACE value exists
    retained_features_reconstruction: Optional[List[str]] = None
    notes: List[str] = field(default_factory=list)


def reconstruct_cell(
    df_cell: pd.DataFrame, selected_config: Dict, cfg: Config, lat: float, lon: float,
    models_to_run: Tuple[str, ...] = MODEL_GROUPS,
) -> CellReconstruction:
    """
    `models_to_run`: same meaning as in validation.run_cell_validation --
    controls only whether the cheap linear_regression baseline is included
    in the reconstruction (the only "baseline" family that ever is; a
    1948-2002 extrapolation has no meaning for persistence/climatology,
    which both need a real preceding/same-month GRACE observation). The
    tuned families (random_forest/ann/lstm/bilstm) are gated purely by
    whether validation.py actually produced hyperparameters for them --
    there is nothing further to restrict here, since a family left out of
    `models_to_run` upstream simply never appears in `hparams`.
    """
    out = CellReconstruction(cell_id=(lat, lon))
    hparams = selected_config.get("hyperparameters", {})
    want_baseline = "baseline" in models_to_run
    if not hparams and not want_baseline:
        log.warning("[%.3f, %.3f] Reconstruction skipped: no hyperparameters were selected during "
                     "validation for this cell (no usable CV fold), and 'baseline' was not requested.", lat, lon)
        out.notes.append("No hyperparameters were selected during validation for this cell; reconstruction skipped.")
        return out
    log.info("[%.3f, %.3f] Starting 1948-2024 reconstruction refit. Model families carried forward "
              "from validation: %s%s", lat, lon, list(hparams.keys()), " + linear_regression (baseline)" if want_baseline else "")

    recon_start = cfg.temporal.grace_development_start  # 2003-01: start of usable GRACE record for THIS workflow
    recon_fit_end = cfg.temporal.final_test_end          # 2024-12: use every observed GRACE month for the refit

    X_tab_all, y_tab_all = feat.make_tabular_dataset(df_cell, lags=cfg.features.lags_tabular)
    X_seq_all, y_seq_all, channel_names = feat.make_sequence_dataset(
        df_cell, window=cfg.features.lookback_window, include_target_month=cfg.features.sequence_includes_target_month,
    )

    # Fit on every GRACE-observed month in [recon_start, recon_fit_end]. Some
    # months inside this window still have no GRACE value (JPL's own
    # `months_missing` list, e.g. 2011-01, 2012-05, ...), so an explicit
    # y.notna() filter is required here -- X_tab_all/X_seq_all span the full
    # 1948-2024 predictor record and keep NaN-y rows on purpose (see
    # features.py), only fitting needs them dropped.
    fit_mask = (y_tab_all.index >= pd.Timestamp(recon_start)) & (y_tab_all.index <= pd.Timestamp(recon_fit_end)) & y_tab_all.notna()
    X_fit, y_fit = X_tab_all.loc[fit_mask], y_tab_all.loc[fit_mask]
    if len(X_fit) < cfg.features.min_training_months:
        log.warning("[%.3f, %.3f] Reconstruction skipped: only %d usable GRACE-observed months "
                     "available (need >= %d).", lat, lon, len(X_fit), cfg.features.min_training_months)
        out.notes.append(f"Only {len(X_fit)} usable GRACE-observed months available; below min_training_months, reconstruction skipped.")
        return out

    retained, removed, _ = feat.screen_correlated_features(X_fit, y_fit, threshold=cfg.features.correlation_threshold)
    out.retained_features_reconstruction = retained
    log.info(
        "[%.3f, %.3f] Reconstruction refit on %d GRACE-observed months [%s..%s]: feature screening "
        "(|r|>%.2f) retained %d/%d features: %s%s",
        lat, lon, len(X_fit), recon_start, recon_fit_end, cfg.features.correlation_threshold,
        len(retained), len(X_fit.columns), retained, f"; dropped {removed}" if removed else "",
    )

    X_fit_r = X_fit[retained]
    X_all_r = X_tab_all[retained]  # predictors for the ENTIRE 1948-2024 span, same columns
    scaler = prep.FoldScaler().fit(X_fit_r, y_fit)
    X_fit_s, _ = scaler.transform_X(X_fit_r)
    y_fit_s = scaler.transform_y(y_fit)
    X_all_s, oor_all = scaler.transform_X(X_all_r)  # note: values before ~2003 WILL legitimately fall
    # outside the GRACE-fitting-period predictor range in places; recorded, not clipped.

    predictions = {}
    n_inner_val = max(6, int(0.2 * len(X_fit_s)))
    n_inner_val = min(n_inner_val, len(X_fit_s) - 1) if len(X_fit_s) > 1 else 0

    if want_baseline:
        predictions["linear_regression"] = pd.Series(
            scaler.inverse_transform_y(mdl.LinearRegressionModel().fit(X_fit_s, y_fit_s).predict(X_all_s)),
            index=X_all_s.index,
        )

    if "random_forest" in hparams:
        rf = mdl.fit_rf_with_params(X_fit_s, y_fit_s, hparams["random_forest"], cfg.models.random_state)
        predictions["random_forest"] = pd.Series(scaler.inverse_transform_y(rf.predict(X_all_s)), index=X_all_s.index)
        del rf

    if "ann" in hparams and n_inner_val > 0:
        ann = mdl.fit_ann_with_params(X_fit_s.values, y_fit_s.values, hparams["ann"], cfg.models, n_inner_val)
        predictions["ann"] = pd.Series(scaler.inverse_transform_y(ann.predict(X_all_s.values)), index=X_all_s.index)
        del ann
        clear_keras_memory()

    # Sequence models over the full 1948-2024 span (same NaN-y guard as above)
    seq_fit_mask = (y_seq_all.index >= pd.Timestamp(recon_start)) & (y_seq_all.index <= pd.Timestamp(recon_fit_end)) & y_seq_all.notna()
    X_seq_fit, y_seq_fit = X_seq_all[seq_fit_mask.values], y_seq_all.loc[seq_fit_mask]
    seq_recon_models = [m for m in ("lstm", "bilstm") if m in hparams]
    if seq_recon_models and len(X_seq_fit) >= cfg.features.min_training_months:
        seq_scaler_tgt = prep.FoldScaler().fit(pd.DataFrame({"twsa": y_seq_fit.values}), y_seq_fit)
        y_seq_fit_s = seq_scaler_tgt.transform_y(y_seq_fit)
        seq_scaler = prep.SequenceScaler().fit(X_seq_fit)
        X_seq_fit_s, _ = seq_scaler.transform(X_seq_fit)
        X_seq_all_s, _ = seq_scaler.transform(X_seq_all)

        n_inner_val_seq = max(6, int(0.2 * len(X_seq_fit_s)))
        n_inner_val_seq = min(n_inner_val_seq, len(X_seq_fit_s) - 1) if len(X_seq_fit_s) > 1 else 0
        if n_inner_val_seq > 0:
            # lstm/bilstm fit and discarded one at a time -- a reconstruction
            # run requesting only one of them never builds the other.
            for model_name in seq_recon_models:
                m_recon = mdl.fit_rnn_with_params(
                    X_seq_fit_s, y_seq_fit_s.values, hparams[model_name], cfg.models,
                    n_inner_val_seq, bidirectional=(model_name == "bilstm"),
                )
                predictions[model_name] = pd.Series(
                    seq_scaler_tgt.inverse_transform_y(m_recon.predict(X_seq_all_s)), index=y_seq_all.index,
                )
                del m_recon
                clear_keras_memory()

    full_index = X_tab_all.index.union(y_seq_all.index).sort_values()
    recon_df = pd.DataFrame(index=full_index)
    for name, series in predictions.items():
        recon_df[name] = series.reindex(full_index)

    if len(predictions) > 1:
        recon_df["ensemble"] = recon_df[list(predictions.keys())].mean(axis=1, skipna=True)
        recon_df.attrs["ensemble_method"] = "unweighted mean across available model reconstructions"

    observed = df_cell["twsa"].reindex(full_index)
    out.reconstructed = recon_df
    out.is_grace_observed = observed.notna()
    out.notes.append(
        f"Reconstruction fit on GRACE-observed months {recon_start}..{recon_fit_end} "
        f"({len(X_fit)} usable tabular months). Months outside that window ({full_index.min().date()}"
        f"..{full_index.max().date()}, excluding the fit window) are EXTRAPOLATIVE model-based "
        "estimates and have not been directly validated against GRACE."
    )
    n_oor = sum(oor_all.values())
    if n_oor:
        out.notes.append(
            f"{n_oor} predictor values across the full reconstruction period fell outside the "
            "GRACE-fitting-period's training min/max range (not clipped; flagged in normalization diagnostics)."
        )

    n_extrapolative = int((~out.is_grace_observed).sum())
    log.info(
        "[%.3f, %.3f] Reconstruction done: %d model famil%s fit (%s)%s. Output spans %s..%s "
        "(%d months): %d GRACE-observed, %d extrapolative.%s",
        lat, lon, len(predictions), "y" if len(predictions) == 1 else "ies", list(predictions.keys()),
        " + unweighted-mean ensemble" if "ensemble" in recon_df.columns else "",
        full_index.min().date(), full_index.max().date(), len(full_index),
        int(out.is_grace_observed.sum()), n_extrapolative,
        f" {n_oor} predictor values fell outside the fit period's training range." if n_oor else "",
    )
    return out
