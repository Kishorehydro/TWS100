"""
interpretation.py
=================
Section 11 of the spec: model interpretation using SHAP.

  - RF: shap.TreeExplainer (exact, tree-structure-based).
  - ANN / LSTM / BiLSTM: shap.GradientExplainer (a model-agnostic
    approximation for differentiable models, chosen over DeepExplainer
    for broader TensorFlow-2/eager-mode compatibility; falls back to
    shap.KernelExplainer -- a slower, sampling-based model-agnostic
    approximation -- if GradientExplainer raises for a given TF/Keras
    build). Both are genuine approximations, not exact attributions;
    that is a real limitation of explaining neural networks and is
    recorded in every exported SHAP result's metadata, not hidden.
  - Linear regression is not included here: the spec's SHAP requirement
    (section 11) names RF, ANN, LSTM, and BiLSTM specifically, and a
    linear model's exact per-feature contribution is already its
    coefficient times the (training-mean-centered) feature value -- SHAP
    adds no information beyond that for an additive linear model.

SHAP is always computed on TRAINING / development data (or an explicitly
documented representative sample of it), never on final-test data, per
the spec's explicit instruction not to use final-test SHAP results to
tune or select a model. SHAP values are attributions of THIS model's
output to THIS model's inputs -- they are not evidence of a causal
physical mechanism, and are never described as such anywhere this module
is used.
"""

from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from utils import get_logger

log = get_logger()

MAX_BACKGROUND_SAMPLES = 100
MAX_EVAL_SAMPLES = 200


def _subsample(X, max_n: int, seed: int = 42):
    n = len(X)
    if n <= max_n:
        return X, np.arange(n)
    rng = np.random.RandomState(seed)
    idx = rng.choice(n, size=max_n, replace=False)
    idx.sort()
    if isinstance(X, pd.DataFrame):
        return X.iloc[idx], idx
    return X[idx], idx


def shap_for_random_forest(rf_model, X_dev: pd.DataFrame, feature_names: List[str]) -> Dict:
    import shap

    X_eval, idx = _subsample(X_dev, MAX_EVAL_SAMPLES)
    explainer = shap.TreeExplainer(rf_model.model)
    shap_values = explainer.shap_values(X_eval.values)
    df = pd.DataFrame(shap_values, columns=feature_names, index=X_eval.index)
    variable_importance = df.abs().mean().sort_values(ascending=False)
    return {
        "method": "TreeExplainer (exact)",
        "shap_values": df,
        "variable_importance": variable_importance,
        "n_samples_explained": len(X_eval),
    }


def shap_for_ann(ann_wrapper, X_dev: np.ndarray, feature_names: List[str], background_size: int = MAX_BACKGROUND_SAMPLES) -> Dict:
    import shap

    X_bg, _ = _subsample(X_dev, background_size)
    X_eval, idx = _subsample(X_dev, MAX_EVAL_SAMPLES)

    method = "GradientExplainer (approximate)"
    try:
        explainer = shap.GradientExplainer(ann_wrapper.model, X_bg)
        shap_values = explainer.shap_values(X_eval)
        if isinstance(shap_values, list):
            shap_values = shap_values[0]
        shap_values = np.asarray(shap_values).reshape(len(X_eval), -1)
    except Exception as exc:  # pragma: no cover - environment-dependent fallback
        log.warning("GradientExplainer failed for ANN (%s); falling back to KernelExplainer (slower, sampling-based).", exc)
        method = "KernelExplainer (approximate, sampling-based fallback)"
        explainer = shap.KernelExplainer(lambda x: ann_wrapper.model.predict(x, verbose=0).reshape(-1), X_bg)
        shap_values = explainer.shap_values(X_eval, nsamples=100)
        shap_values = np.asarray(shap_values).reshape(len(X_eval), -1)

    df = pd.DataFrame(shap_values, columns=feature_names)
    variable_importance = df.abs().mean().sort_values(ascending=False)
    return {
        "method": method,
        "shap_values": df,
        "variable_importance": variable_importance,
        "n_samples_explained": len(X_eval),
        "n_background_samples": len(X_bg),
    }


def shap_for_sequence_model(rnn_wrapper, X_dev_seq: np.ndarray, channel_names: List[str], background_size: int = MAX_BACKGROUND_SAMPLES) -> Dict:
    """
    SHAP for LSTM/BiLSTM. Returns BOTH variable-level importance (averaged
    over samples and lookback time steps) and time-step-level importance
    (averaged over samples and channels), per the spec's explicit
    requirement to report feature attribution aggregated across both axes.
    """
    import shap

    X_bg, _ = _subsample(X_dev_seq, background_size)
    X_eval, idx = _subsample(X_dev_seq, MAX_EVAL_SAMPLES)

    method = "GradientExplainer (approximate)"
    try:
        explainer = shap.GradientExplainer(rnn_wrapper.model, X_bg)
        shap_values = explainer.shap_values(X_eval)
        if isinstance(shap_values, list):
            shap_values = shap_values[0]
        shap_values = np.asarray(shap_values)
        if shap_values.ndim == 4 and shap_values.shape[-1] == 1:
            # GradientExplainer appends a trailing singleton dim for a
            # single-output (regression) model; collapse it so shap_values
            # is (samples, window, channels) as expected below.
            shap_values = shap_values[..., 0]
    except Exception as exc:  # pragma: no cover
        log.warning("GradientExplainer failed for sequence model (%s); falling back to a flattened KernelExplainer (slower, sampling-based).", exc)
        method = "KernelExplainer on flattened input (approximate, sampling-based fallback)"
        window, n_ch = X_eval.shape[1], X_eval.shape[2]

        def _predict_flat(flat_x):
            return rnn_wrapper.model.predict(flat_x.reshape(-1, window, n_ch), verbose=0).reshape(-1)

        explainer = shap.KernelExplainer(_predict_flat, X_bg.reshape(len(X_bg), -1))
        sv_flat = explainer.shap_values(X_eval.reshape(len(X_eval), -1), nsamples=100)
        shap_values = np.asarray(sv_flat).reshape(len(X_eval), window, n_ch)

    variable_importance = pd.Series(
        np.abs(shap_values).mean(axis=(0, 1)), index=channel_names,
    ).sort_values(ascending=False)
    n_window = shap_values.shape[1]
    timestep_labels = [f"t-{n_window - 1 - i}" for i in range(n_window)]
    timestep_importance = pd.Series(
        np.abs(shap_values).mean(axis=(0, 2)), index=timestep_labels,
    )
    return {
        "method": method,
        "variable_importance": variable_importance,
        "timestep_importance": timestep_importance,
        "n_samples_explained": len(X_eval),
        "n_background_samples": len(X_bg),
    }
