"""
config.py
=========
Single source of truth for every user-adjustable setting in the workflow:
input paths, variable/coordinate names, time ranges, model hyperparameter
search spaces, output directories, and reproducibility settings.

Edit the values in `DEFAULT_CONFIG` (or point `TWSA_CONFIG_FILE` at a YAML
file with the same keys) rather than hard-coding paths anywhere else in the
codebase.

=============================================================================
v2 NOTE -- what changed and why (read this before editing paths below)
=============================================================================
This version assumes the GLDAS-derived predictor data is handed to the
pipeline already finished, specifically:

  1. Already bias-corrected across the GLDAS-2.0 (Princeton forcing,
     pre-2000) / GLDAS-2.1 (GDAS forcing, 2000+) boundary -- done by the
     user outside this codebase. The pipeline no longer fits or applies
     any overlap bias correction.
  2. Already in consistent, intended physical units across the whole
     1948-2024 record -- done by the user outside this codebase. The
     pipeline does not re-derive or rescale any GLDAS unit.
  3. Already regridded onto the same 0.5-degree grid as the GRACE/JPL
     target -- done by the user outside this codebase. The pipeline does
     NOT regrid predictor_files; it only verifies the grid matches and
     raises a clear error if it does not (see spatial.verify_spatial_alignment
     and pipeline.py STEP 2).

`spatial.py` still contains the regridding functions and `temporal.py`
still contains the GLDAS-2.0/2.1 bias-correction functions -- they are not
deleted, only no longer called by default from pipeline.py -- in case you
ever need to process a predictor file that is NOT already corrected/
regridded. See each module's docstring.

What you need to fill in below:
  - `PathsConfig.predictor_files`: one or more NetCDF file paths, in
    chronological order, each containing the 8 (or 9, if the humidity
    predictor isn't precomputed -- see `VariableNamesConfig.humidity_precomputed_var`)
    GLDAS-derived predictor variables, already corrected/unit-fixed/
    regridded as above. If you still have two files (a historical one and
    a recent one, as before), just list both in order -- they are
    concatenated, NOT bias-corrected, with any overlapping months taken
    from the LATER file in the list.
  - `PathsConfig.imd_precip_nc`: path to your real IMD gridded
    precipitation NetCDF. Used in place of GLDAS precipitation
    (Rainf_f_tavg) for every month it actually covers; GLDAS precipitation
    is used as the documented fallback for any month outside IMD's
    coverage (see temporal.py::build_final_precipitation_series). IMD is
    regridded onto the GRACE grid the same way GLDAS used to be, unless
    `imd_already_on_grace_grid=True`.
  - `VariableNamesConfig.imd_*`: the variable/coordinate names inside your
    IMD file -- these are guesses at common IMD gridded-rainfall
    conventions and will very likely need adjusting to your actual file.
  - Double check `VariableNamesConfig`'s GLDAS variable names still match
    your corrected file (if your own preprocessing renamed them, update
    the names here -- the pipeline reads variables by these names, not by
    position).

Notes on the two GRACE-adjacent facts baked into this config, both verified
directly against the user's own files (not assumed from documentation):

1. The JPL file is the CRI-filtered mascon product
   (`GRCTellus.JPL.200204_202508.GLO.RL06.3M.MSCNv04CRI.nc`). It ships a
   `scale_factor` grid whose own `description` attribute states it is
   "to be used with mascon solution that has the CRI filter applied".
   The CRI filter corrects land/ocean coastal leakage; `scale_factor`
   corrects a *different* effect (signal damping from the inversion's
   Tikhonov regularization). Because this workflow reconstructs TWSA at
   the grid-cell level (not a single basin-average series), the gain
   factor is applied: `lwe_thickness * scale_factor`. See data_io.py. This
   is on the TARGET side and is unaffected by the predictor-side changes
   above.

2. (Historical GLDAS-2.0/2.1 note, kept for reference.) The two original
   raw GLDAS NOAH files were not the same product (Princeton_V2.2 forcing
   vs GDAS-AGRMET-GPCPv13rA1 forcing), overlapping 2000-01 to 2014-12. This
   is exactly the mismatch the user has now corrected upstream themselves
   (see the v2 note above) -- kept here only as provenance/context.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional


# ---------------------------------------------------------------------------
# 1. Paths
# ---------------------------------------------------------------------------
@dataclass
class PathsConfig:
    # GRACE / GRACE-FO JPL mascon target
    grace_jpl_nc: str = (
        r"E:\Papers\GUI_Paper\JOH_RS\JHRS_R1\Matlab_GUI\Data\GRACE\JPL\\"
        r"GRCTellus.JPL.200204_202508.GLO.RL06.3M.MSCNv04CRI.nc"
    )

    # ---- EDIT ME: your already bias-corrected / unit-fixed / regridded ----
    # GLDAS-derived predictor file(s), listed in CHRONOLOGICAL order. One
    # file is fine (a single merged 1948-2024 file); two or more is also
    # fine (e.g. the original historical + recent split) -- they are
    # concatenated by data_io.py/temporal.py with NO bias-correction math,
    # since you've already done that. For any month that exists in more
    # than one file, the value from the file listed LATER wins.
    predictor_files: List[str] = field(default_factory=lambda: [
        r"E:\Papers\GUI_Paper\JOH_RS\JHRS_R1\Matlab_GUI\Data\GLDAS\GLDAS_NOAH_regridded_to_GRACE_grid.nc",
    ])

    # ---- EDIT ME: your real IMD gridded precipitation file ----
    # Used wherever it has coverage (see temporal.build_final_precipitation_series);
    # GLDAS precipitation remains the documented fallback outside that
    # coverage. Leave as None to use GLDAS precipitation for the entire
    # period (no IMD substitution at all).
    imd_precip_nc: Optional[str] = (
        r"E:\Papers\GUI_Paper\JOH_RS\JHRS_R1\Matlab_GUI\Data\Precipitation\IMD\\"
        r"IMD_Monthly_1901_2024_regridded_to_GRACE_grid.nc"
    )

    # Study-area polygon
    study_area_shp: str = (
        r"E:\Papers\GUI_Paper\JOH_RS\JHRS_R1\Matlab_GUI\Data\River_Shps\\"
        r"Godavari_River_Basin.shp"
    )

    # Outputs
    output_dir: str = "./outputs"
    log_dir: str = "./logs"

    def subdirs(self) -> dict:
        root = Path(self.output_dir)
        d = {
            "root": root,
            "reconstruction": root / "01_reconstructed_twsa",
            "basin_average": root / "13_basin_average",
            "validation": root / "02_validation_metrics",
            "final_test": root / "03_final_test_results",
            "drought": root / "04_drought_validation",
            "hyperparams": root / "05_hyperparameters",
            "feature_selection": root / "06_feature_selection",
            "correlation": root / "07_correlation_matrices",
            "shap": root / "08_shap",
            "normalization": root / "09_normalization_diagnostics",
            "forcing_consistency": root / "10_forcing_consistency",
            "precip_comparison": root / "11_precipitation_comparison",
            "diagnostics": root / "12_model_diagnostics",
        }
        for p in d.values():
            p.mkdir(parents=True, exist_ok=True)
        return d


# ---------------------------------------------------------------------------
# 2. Variable / coordinate name mapping
# ---------------------------------------------------------------------------
@dataclass
class VariableNamesConfig:
    # --- GRACE JPL mascon file (unaffected by the v2 changes) ---
    grace_lat: str = "lat"
    grace_lon: str = "lon"
    grace_time: str = "time"
    grace_twsa_var: str = "lwe_thickness"          # units: cm
    grace_uncertainty_var: str = "uncertainty"      # units: cm
    grace_scale_factor_var: str = "scale_factor"    # dimensionless gain factor
    grace_land_mask_var: str = "land_mask"
    grace_fill_value: float = -99999.0
    grace_native_units: str = "cm"

    # --- predictor_files (your already-corrected GLDAS-derived data) ---
    # If your own preprocessing renamed any of these, update the name
    # here (the pipeline reads by name, not by column position).
    predictor_lat: str = "lat"
    predictor_lon: str = "lon"
    predictor_time: str = "time"
    # Sentinel value masked to NaN on load. Set to None if your corrected
    # file already uses NaN (or no sentinel at all) and no masking is needed.
    # Verified for GLDAS_NOAH_regridded_to_GRACE_grid.nc: every variable's
    # _FillValue is already NaN (not an integer sentinel), so this is set
    # to None -- masking against -9999.0 would be harmless but pointless.
    predictor_missing_value: Optional[float] = None

    precipitation: str = "Rainf_f_tavg"
    temperature: str = "Tair_f_inst"
    evapotranspiration: str = "Evap_tavg"
    wind_speed: str = "Wind_f_inst"
    soil_moisture_layers: tuple = (
        "SoilMoi0_10cm_inst",
        "SoilMoi10_40cm_inst",
        "SoilMoi40_100cm_inst",
        "SoilMoi100_200cm_inst",
    )
    shortwave_down: str = "SWdown_f_tavg"
    longwave_down: str = "LWdown_f_tavg"

    # Humidity predictor (the 6th of the 8 canonical predictors, named
    # generically "humidity" rather than "relative_humidity" -- see
    # features.py's module docstring for why). GLDAS NOAH has no native RH
    # variable. Two modes:
    #   - Leave `humidity_precomputed_var = None` (default): true relative
    #     humidity is DERIVED from `specific_humidity` + `temperature` +
    #     `surface_pressure` via features.py::derive_relative_humidity.
    #     Your predictor_files must then contain BOTH `specific_humidity`
    #     and `surface_pressure`.
    #   - Set `humidity_precomputed_var` to a variable name: the pipeline
    #     reads it DIRECTLY from predictor_files and uses it AS-IS, no
    #     conversion, as the humidity predictor. No surface_pressure is
    #     required in this mode. Use this either because your own
    #     preprocessing already computed true RH, OR -- as here, for the
    #     Godavari merged GLDAS file, which has Qair_f_inst (specific
    #     humidity) but no Psurf_f_inst -- because you've chosen to use
    #     specific humidity directly in place of true relative humidity
    #     (confirmed with the user: specific humidity alone is an
    #     acceptable humidity predictor here; this is documented, not
    #     silently substituted, in predictor_preprocessing_provenance.csv).
    humidity_precomputed_var: Optional[str] = "Qair_f_inst"
    specific_humidity: str = "Qair_f_inst"   # kg kg-1 (only read as a separate fallback input if humidity_precomputed_var is None)
    surface_pressure: str = "Psurf_f_inst"   # Pa (only needed if humidity_precomputed_var is None)

    # --- IMD gridded precipitation file ---
    # EDIT ME: these are common-convention guesses, not verified against
    # your actual IMD file -- check and correct them.
    imd_lat: str = "lat"
    imd_lon: str = "lon"
    imd_time: str = "time"
    imd_precip_var: str = "RAINFALL"         # e.g. "rf", "RAINFALL", "precipitation" -- check your file
    imd_missing_value: Optional[float] = None  # set a sentinel if your file uses one instead of NaN/_FillValue

    @property
    def predictor_names(self) -> tuple:
        """Canonical order of the 8 predictors used throughout the pipeline."""
        return (
            "precipitation",
            "temperature",
            "evapotranspiration",
            "wind_speed",
            "soil_moisture",
            "humidity",
            "shortwave_down",
            "longwave_down",
        )


# ---------------------------------------------------------------------------
# 3. Temporal configuration
# ---------------------------------------------------------------------------
@dataclass
class TemporalConfig:
    # Monthly timestamp convention: every monthly value is stamped on the
    # first day of the month it represents (pandas Period -> Timestamp
    # at month start). Documented once here and used everywhere so that
    # "2003-01" always means the same instant across all datasets.
    timestamp_convention: str = "month_start"

    reconstruction_start: str = "1948-01"
    reconstruction_end: str = "2024-12"

    grace_development_start: str = "2003-01"   # avoid the sparse 2002 partial year
    grace_development_end: str = "2020-12"
    final_test_start: str = "2021-01"
    final_test_end: str = "2024-12"

    # Rolling-origin folds for the development period (adjusted at runtime
    # if actual GRACE coverage/missing months require it -- see validation.py)
    cv_folds: tuple = (
        ("2003-01", "2010-12", "2011-01", "2012-12"),
        ("2003-01", "2012-12", "2013-01", "2014-12"),
        ("2003-01", "2014-12", "2015-01", "2016-12"),
        ("2003-01", "2016-12", "2017-01", "2020-12"),
    )

    # Precipitation source bookkeeping (spec section 3 + section 10): even
    # if your IMD file happens to extend further, no month after this date
    # is ever labeled "IMD" -- raise this once you've checked your file's
    # real, intended coverage. The actual per-month decision also requires
    # the IMD file to have non-NaN data for that month; see
    # temporal.build_final_precipitation_series.
    imd_precip_documented_end: str = "2023-12"


# ---------------------------------------------------------------------------
# 4. Feature-construction configuration
# ---------------------------------------------------------------------------
@dataclass
class FeatureConfig:
    lags_tabular: tuple = (0, 1, 2)        # X_t, X_t-1, X_t-2 -> 24 candidate features
    lookback_window: int = 3               # months, for LSTM/BiLSTM: (samples, 3, 8)
    sequence_includes_target_month: bool = True  # sequence spans t-2..t (ends at target month)

    correlation_threshold: float = 0.90
    correlation_method: str = "pearson"    # also computes spearman for reporting
    apply_correlation_screening_to_sequence_models: bool = False  # see spec section 5

    min_training_months: int = 36          # minimum samples to attempt training a cell


# ---------------------------------------------------------------------------
# 5. Model / hyperparameter configuration
# ---------------------------------------------------------------------------
@dataclass
class ModelConfig:
    random_state: int = 42

    rf_param_grid: dict = field(default_factory=lambda: {
        "n_estimators": [200, 400],
        "max_depth": [None, 10, 20],
        "min_samples_leaf": [1, 3, 5],
    })

    ann_param_grid: dict = field(default_factory=lambda: {
        "hidden_units": [(32,), (64, 32)],
        "dropout": [0.0, 0.2],
        "learning_rate": [1e-3, 5e-4],
    })
    ann_epochs: int = 200
    ann_batch_size: int = 16
    ann_patience: int = 15

    rnn_param_grid: dict = field(default_factory=lambda: {
        "units": [16, 32],
        "dropout": [0.0, 0.2],
        "learning_rate": [1e-3, 5e-4],
    })
    rnn_epochs: int = 200
    rnn_batch_size: int = 16
    rnn_patience: int = 15

    # Fraction of the *training* portion of each fold reserved as an
    # early-stopping validation subset (time-ordered, taken from the end).
    early_stopping_val_fraction: float = 0.15

    n_jobs: int = 1  # parallel grid cells for RF/linear/baselines only

    # --- Basin-average hyperparameter-SENSITIVITY configs (manuscript figure) ---
    # Three FIXED (never tuned) hyperparameter configurations per tunable
    # family, spanning low/medium/high model complexity, used ONLY by
    # basin_average.py's sensitivity comparison -- to show how
    # reconstruction accuracy changes with hyperparameter choice, for the
    # basin-average series only. This is a SEPARATE, smaller set of
    # configs from rf_param_grid/ann_param_grid above (those remain the
    # nested-CV tuning search space for every per-grid-cell "best
    # hyperparameter" reconstruction, unchanged). Edit these three labels/
    # values directly if the manuscript needs different tiers.
    rf_sensitivity_configs: dict = field(default_factory=lambda: {
        "low_complexity":    {"n_estimators": 50,  "max_depth": 5,    "min_samples_leaf": 5},
        "medium_complexity": {"n_estimators": 200, "max_depth": 10,   "min_samples_leaf": 3},
        "high_complexity":   {"n_estimators": 400, "max_depth": None, "min_samples_leaf": 1},
    })
    ann_sensitivity_configs: dict = field(default_factory=lambda: {
        "low_complexity":    {"hidden_units": (16,),    "dropout": 0.2, "learning_rate": 5e-4},
        "medium_complexity": {"hidden_units": (32,),     "dropout": 0.1, "learning_rate": 1e-3},
        "high_complexity":   {"hidden_units": (64, 32),  "dropout": 0.0, "learning_rate": 1e-3},
    })


# ---------------------------------------------------------------------------
# 6. Drought evaluation configuration
# ---------------------------------------------------------------------------
@dataclass
class DroughtConfig:
    # Drought index computed from the GRACE TWSA series itself at each grid
    # cell: standardized anomaly of 3-month-smoothed TWSA (a TWS-based
    # drought index, documented explicitly -- NOT an SPI computed from
    # precipitation, since the spec asks for an index appropriate to the
    # *available observations*, which here are the TWSA target itself).
    smoothing_window_months: int = 3
    drought_threshold_std: float = -1.0   # <= -1 std of smoothed TWSA anomaly
    min_event_length_months: int = 2


# ---------------------------------------------------------------------------
# 7. Master config
# ---------------------------------------------------------------------------
@dataclass
class Config:
    paths: PathsConfig = field(default_factory=PathsConfig)
    varnames: VariableNamesConfig = field(default_factory=VariableNamesConfig)
    temporal: TemporalConfig = field(default_factory=TemporalConfig)
    features: FeatureConfig = field(default_factory=FeatureConfig)
    models: ModelConfig = field(default_factory=ModelConfig)
    drought: DroughtConfig = field(default_factory=DroughtConfig)

    precipitation_source: str = "IMD"   # "GLDAS" or "IMD"; see temporal.py. Set "GLDAS" to ignore imd_precip_nc entirely.

    # --- v2 flags: both default to the user's stated situation. Flip to
    # False only if you discover a specific input ISN'T actually what its
    # default assumes (e.g. an IMD file that still needs regridding is the
    # normal case, hence False by default for that one). ---
    predictors_already_on_grace_grid: bool = True   # predictor_files: skip regridding, just verify alignment
    # Verified directly against IMD_Monthly_1901_2024_regridded_to_GRACE_grid.nc:
    # its global attrs record "regridded_to_grid_from: GRCTellus.JPL...nc" via
    # xESMF conservative regridding, and its lat/lon arrays match the JPL file's
    # exactly (360x720, same -89.75..89.75 / 0.25..359.75 convention). So this
    # is True here -- regridding it again would be a safe but pointless no-op.
    imd_already_on_grace_grid: bool = True          # IMD file: regrid onto the GRACE grid before use

    random_seed: int = 42
    max_grid_cells: Optional[int] = None  # cap for quick test runs; None = all cells
    log_level: str = "INFO"

    # Which model families to fit this run: any subset of
    # utils.MODEL_GROUPS = ("baseline", "random_forest", "ann", "lstm",
    # "bilstm"). "baseline" = persistence + climatology + linear_regression
    # (always cheap, bundled together). Overridden per-run by pipeline.py's
    # --models flag.
    #
    # v3 note: lstm/bilstm are OFF by default (removed from this default
    # tuple at the user's explicit request, to cut runtime) -- the
    # sequence-model code (models.py::tune_rnn/fit_rnn_with_params,
    # features.py::make_sequence_dataset, the LSTM/BiLSTM branches in
    # validation.py/reconstruction.py/pipeline.py's SHAP step) is NOT
    # deleted, only unreached by default, exactly like the GLDAS bias-
    # correction functions in temporal.py -- pass --models
    # baseline,random_forest,ann,lstm,bilstm (or edit this tuple) to bring
    # them back.
    #
    # Why --models/this tuple exists at all: fitting ANN/LSTM/BiLSTM for
    # every grid cell in the Godavari basin in one process keeps
    # TensorFlow/Keras graphs and per-fold hyperparameter-grid models (8
    # combos x up to 4 folds x every cell, for EACH family) alive long
    # enough to grow memory use across the run even with
    # clear_keras_memory() calls in between. Splitting the run into
    # separate invocations -- e.g. one run with --models
    # baseline,random_forest (cheap, sklearn-only), then a separate run
    # with --models ann -- keeps each process's peak memory down to ONE
    # model family at a time. export.py merges each run's outputs into
    # the existing CSVs/NetCDF (keyed by lat/lon/fold/model) rather than
    # overwriting them, so results accumulate across runs.
    models_to_run: tuple = ("baseline", "random_forest", "ann")

    # Basin-average reconstruction (one area-weighted pseudo-cell across
    # the whole masked study area) + the 3-config hyperparameter-
    # sensitivity comparison above -- see basin_average.py. On by default;
    # set False (or pass --skip-basin-average) to run only the per-grid-
    # cell pipeline.
    run_basin_average: bool = True

    # v3: how grid-cell random_forest/ann hyperparameters are decided.
    # "basin_average_tuned" (default, FAST): tune ONCE on the cheap,
    # single-series basin average (requires run_basin_average=True), then
    # reuse that SAME fixed hyperparameter set at every fold of every
    # grid cell -- skips the per-fold grid search entirely (see
    # validation.py's fixed_hyperparameters param), which is the dominant
    # cost of a whole-basin run (18 RF fits + 8 full Keras ANN trainings
    # per fold per cell, by default, collapse to 1 each). "per_cell_tuned"
    # restores the original (slow) behavior: every grid cell independently
    # re-tunes its own hyperparameters every fold. "manual": skip tuning
    # entirely and use `manual_fixed_hyperparameters` below at every cell.
    grid_cell_hyperparameter_source: str = "basin_average_tuned"
    # Only used when grid_cell_hyperparameter_source == "manual" (or as a
    # fallback if "basin_average_tuned" was requested but run_basin_average
    # is False / basin tuning produced nothing for a family): e.g.
    # {"random_forest": {"n_estimators": 200, "max_depth": 10,
    # "min_samples_leaf": 3}, "ann": {"hidden_units": (32,), "dropout":
    # 0.1, "learning_rate": 1e-3}}.
    manual_fixed_hyperparameters: Optional[dict] = None


def load_config() -> Config:
    """
    Load configuration. Honors the TWSA_CONFIG_FILE environment variable
    (a YAML file overriding any subset of these fields) if set; otherwise
    returns the defaults above.
    """
    cfg = Config()
    override_path = os.environ.get("TWSA_CONFIG_FILE")
    if override_path and Path(override_path).exists():
        import yaml  # local import: optional dependency, only needed here
        with open(override_path, "r") as fh:
            overrides = yaml.safe_load(fh) or {}

        def _apply(section_obj, section_overrides):
            for k, v in section_overrides.items():
                if hasattr(section_obj, k):
                    setattr(section_obj, k, v)

        for section_name, section_overrides in overrides.items():
            if hasattr(cfg, section_name) and isinstance(section_overrides, dict):
                _apply(getattr(cfg, section_name), section_overrides)
            elif hasattr(cfg, section_name):
                setattr(cfg, section_name, section_overrides)
    return cfg


DEFAULT_CONFIG = Config()
