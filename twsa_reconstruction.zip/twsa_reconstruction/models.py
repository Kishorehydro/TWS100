"""
models.py
=========
Section 7 of the spec: model development and hyperparameter tuning.

Implements RF, ANN, LSTM, BiLSTM, linear regression, and the persistence /
monthly-climatology baselines behind one common interface, plus a small
time-ordered hyperparameter search shared by every model family.

Hyperparameter search protocol (same for every model)
-------------------------------------------------------
1. Take the last `n_inner_val_months` of the fold's TRAINING period as an
   internal, time-ordered validation split (never shuffled, never the
   fold's real validation or the final-test period).
2. Train each candidate hyperparameter combination on the remaining
   (earlier) training months; score RMSE on the internal validation
   months. For ANN/LSTM/BiLSTM, early stopping during this step also
   monitors the SAME internal validation split.
3. Pick the combination with the lowest internal-validation RMSE.
4. Refit a final model with that combination on the FULL training period
   (step 1's two pieces combined) -- for the neural models, early
   stopping during this refit still monitors the same tail slice (it is
   never allowed to see the fold's real validation/test data).
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor

from config import ModelConfig
from utils import get_logger, set_global_seed, clear_keras_memory

log = get_logger()


def _rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.sqrt(np.mean((np.asarray(y_true) - np.asarray(y_pred)) ** 2)))


# ---------------------------------------------------------------------------
# Baselines
# ---------------------------------------------------------------------------
class PersistenceBaseline:
    """
    Predicts TWSA(t) = observed TWSA(t-1). Only evaluable where the
    previous month's OBSERVED TWSA exists (i.e. within the GRACE record),
    so its evaluation coverage is reported separately from the ML models
    and it is never used to reconstruct the pre-GRACE (1948-2002) period.
    """
    def __init__(self):
        self.fitted = True

    def predict_from_previous(self, y_prev: pd.Series) -> pd.Series:
        return y_prev


class ClimatologyBaseline:
    """Predicts TWSA(t) = mean TWSA for calendar month-of-year(t), fit on training data only."""
    def __init__(self):
        self.monthly_mean_: Optional[pd.Series] = None

    def fit(self, y_train: pd.Series) -> "ClimatologyBaseline":
        self.monthly_mean_ = y_train.groupby(y_train.index.month).mean()
        return self

    def predict(self, time_index: pd.DatetimeIndex) -> pd.Series:
        months = time_index.month
        preds = self.monthly_mean_.reindex(months).values
        return pd.Series(preds, index=time_index)


class LinearRegressionModel:
    def __init__(self):
        self.model = LinearRegression()

    def fit(self, X: pd.DataFrame, y: pd.Series) -> "LinearRegressionModel":
        self.model.fit(X.values, y.values)
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        return self.model.predict(X.values)


# ---------------------------------------------------------------------------
# Random Forest
# ---------------------------------------------------------------------------
class RandomForestModel:
    def __init__(self, random_state: int = 42, **rf_kwargs):
        self.random_state = random_state
        self.rf_kwargs = rf_kwargs
        self.model: Optional[RandomForestRegressor] = None

    def fit(self, X: pd.DataFrame, y: pd.Series) -> "RandomForestModel":
        self.model = RandomForestRegressor(random_state=self.random_state, n_jobs=1, **self.rf_kwargs)
        self.model.fit(X.values, y.values)
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        return self.model.predict(X.values)

    def feature_importances(self) -> np.ndarray:
        return self.model.feature_importances_


def tune_random_forest(X_train, y_train, param_grid: Dict, n_inner_val_months: int, random_state: int) -> Tuple[Dict, RandomForestModel]:
    best_params, best_score = None, np.inf
    inner_train_X, inner_val_X = X_train.iloc[:-n_inner_val_months], X_train.iloc[-n_inner_val_months:]
    inner_train_y, inner_val_y = y_train.iloc[:-n_inner_val_months], y_train.iloc[-n_inner_val_months:]

    keys = list(param_grid.keys())
    for combo in itertools.product(*param_grid.values()):
        params = dict(zip(keys, combo))
        m = RandomForestModel(random_state=random_state, **params).fit(inner_train_X, inner_train_y)
        score = _rmse(inner_val_y.values, m.predict(inner_val_X))
        if score < best_score:
            best_score, best_params = score, params

    final_model = RandomForestModel(random_state=random_state, **best_params).fit(X_train, y_train)
    return best_params, final_model


# ---------------------------------------------------------------------------
# Neural network models (Keras / TensorFlow)
# ---------------------------------------------------------------------------
def _build_ann(n_features: int, hidden_units: Tuple[int, ...], dropout: float, learning_rate: float, seed: int):
    import tensorflow as tf
    from tensorflow.keras import layers, models, optimizers

    tf.random.set_seed(seed)
    inp = layers.Input(shape=(n_features,))
    x = inp
    for units in hidden_units:
        x = layers.Dense(units, activation="relu")(x)
        if dropout > 0:
            x = layers.Dropout(dropout)(x)
    out = layers.Dense(1, activation="linear")(x)
    model = models.Model(inp, out)
    model.compile(optimizer=optimizers.Adam(learning_rate=learning_rate), loss="mse")
    return model


def _build_rnn(window: int, n_features: int, units: int, dropout: float, learning_rate: float, bidirectional: bool, seed: int):
    import tensorflow as tf
    from tensorflow.keras import layers, models, optimizers

    tf.random.set_seed(seed)
    inp = layers.Input(shape=(window, n_features))
    rnn_layer = layers.LSTM(units, dropout=dropout)
    if bidirectional:
        rnn_layer = layers.Bidirectional(rnn_layer)
    x = rnn_layer(inp)
    out = layers.Dense(1, activation="linear")(x)
    model = models.Model(inp, out)
    model.compile(optimizer=optimizers.Adam(learning_rate=learning_rate), loss="mse")
    return model


@dataclass
class KerasModelWrapper:
    model: object
    history: object = None

    def predict(self, X) -> np.ndarray:
        return self.model.predict(X, verbose=0).reshape(-1)


def _fit_keras(model, X_train, y_train, X_inner_val, y_inner_val, epochs, batch_size, patience):
    from tensorflow.keras.callbacks import EarlyStopping

    es = EarlyStopping(monitor="val_loss", patience=patience, restore_best_weights=True)
    history = model.fit(
        X_train, y_train, validation_data=(X_inner_val, y_inner_val),
        epochs=epochs, batch_size=batch_size, verbose=0, callbacks=[es],
    )
    return model, history


def tune_ann(X_train: np.ndarray, y_train: np.ndarray, cfg: ModelConfig, n_inner_val: int) -> Tuple[Dict, KerasModelWrapper]:
    set_global_seed(cfg.random_state)
    inner_train_X, inner_val_X = X_train[:-n_inner_val], X_train[-n_inner_val:]
    inner_train_y, inner_val_y = y_train[:-n_inner_val], y_train[-n_inner_val:]

    # Each candidate's model is scored and then IMMEDIATELY discarded
    # (clear_keras_memory()) rather than held onto -- only best_params
    # (a plain dict) survives the loop. Only the final refit below keeps
    # a live model, since that is the one the caller actually needs. This
    # matters because this loop runs once per fold per grid cell: holding
    # every candidate model in memory across a whole-basin run is exactly
    # the kind of TF/Keras memory growth this pipeline is now built to avoid.
    best_params, best_score = None, np.inf
    keys = list(cfg.ann_param_grid.keys())
    for combo in itertools.product(*cfg.ann_param_grid.values()):
        params = dict(zip(keys, combo))
        model = _build_ann(X_train.shape[1], params["hidden_units"], params["dropout"], params["learning_rate"], cfg.random_state)
        model, _ = _fit_keras(model, inner_train_X, inner_train_y, inner_val_X, inner_val_y, cfg.ann_epochs, cfg.ann_batch_size, cfg.ann_patience)
        score = _rmse(inner_val_y, model.predict(inner_val_X, verbose=0).reshape(-1))
        if score < best_score:
            best_score, best_params = score, params
        del model
        clear_keras_memory()

    # Final refit on the full training period, early stopping still on the
    # same inner-validation tail (never the fold's real val/test data).
    final_model = _build_ann(X_train.shape[1], best_params["hidden_units"], best_params["dropout"], best_params["learning_rate"], cfg.random_state)
    final_model, history = _fit_keras(final_model, inner_train_X, inner_train_y, inner_val_X, inner_val_y, cfg.ann_epochs, cfg.ann_batch_size, cfg.ann_patience)
    return best_params, KerasModelWrapper(final_model, history)


def tune_rnn(
    X_train: np.ndarray, y_train: np.ndarray, cfg: ModelConfig, n_inner_val: int, bidirectional: bool,
) -> Tuple[Dict, KerasModelWrapper]:
    set_global_seed(cfg.random_state)
    inner_train_X, inner_val_X = X_train[:-n_inner_val], X_train[-n_inner_val:]
    inner_train_y, inner_val_y = y_train[:-n_inner_val], y_train[-n_inner_val:]
    window, n_features = X_train.shape[1], X_train.shape[2]

    # Same discard-each-candidate-immediately pattern as tune_ann (see its
    # comment) -- this loop runs once per fold per cell for LSTM, and again
    # for BiLSTM, so it is the other main source of TF/Keras memory growth.
    best_params, best_score = None, np.inf
    keys = list(cfg.rnn_param_grid.keys())
    for combo in itertools.product(*cfg.rnn_param_grid.values()):
        params = dict(zip(keys, combo))
        model = _build_rnn(window, n_features, params["units"], params["dropout"], params["learning_rate"], bidirectional, cfg.random_state)
        model, _ = _fit_keras(model, inner_train_X, inner_train_y, inner_val_X, inner_val_y, cfg.rnn_epochs, cfg.rnn_batch_size, cfg.rnn_patience)
        score = _rmse(inner_val_y, model.predict(inner_val_X, verbose=0).reshape(-1))
        if score < best_score:
            best_score, best_params = score, params
        del model
        clear_keras_memory()

    final_model = _build_rnn(window, n_features, best_params["units"], best_params["dropout"], best_params["learning_rate"], bidirectional, cfg.random_state)
    final_model, history = _fit_keras(final_model, inner_train_X, inner_train_y, inner_val_X, inner_val_y, cfg.rnn_epochs, cfg.rnn_batch_size, cfg.rnn_patience)
    return best_params, KerasModelWrapper(final_model, history)


MODEL_REGISTRY: List[str] = ["linear_regression", "random_forest", "ann", "lstm", "bilstm", "persistence", "climatology"]


# ---------------------------------------------------------------------------
# Refit-with-fixed-hyperparameters helpers (used for the final-test refit
# on the full development period, and again for the reconstruction refit
# on the full GRACE-observed period -- see validation.py section 8 and
# reconstruction.py section 12). Hyperparameters themselves are never
# re-tuned in either case; only the early-stopping split is re-derived.
# ---------------------------------------------------------------------------
def fit_rf_with_params(X: pd.DataFrame, y: pd.Series, params: Dict, random_state: int) -> RandomForestModel:
    return RandomForestModel(random_state=random_state, **params).fit(X, y)


def fit_ann_with_params(X: np.ndarray, y: np.ndarray, params: Dict, cfg: ModelConfig, n_inner_val: int) -> KerasModelWrapper:
    set_global_seed(cfg.random_state)
    inner_train_X, inner_val_X = X[:-n_inner_val], X[-n_inner_val:]
    inner_train_y, inner_val_y = y[:-n_inner_val], y[-n_inner_val:]
    model = _build_ann(X.shape[1], params["hidden_units"], params["dropout"], params["learning_rate"], cfg.random_state)
    model, history = _fit_keras(model, inner_train_X, inner_train_y, inner_val_X, inner_val_y, cfg.ann_epochs, cfg.ann_batch_size, cfg.ann_patience)
    return KerasModelWrapper(model, history)


def fit_rnn_with_params(X: np.ndarray, y: np.ndarray, params: Dict, cfg: ModelConfig, n_inner_val: int, bidirectional: bool) -> KerasModelWrapper:
    set_global_seed(cfg.random_state)
    inner_train_X, inner_val_X = X[:-n_inner_val], X[-n_inner_val:]
    inner_train_y, inner_val_y = y[:-n_inner_val], y[-n_inner_val:]
    window, n_features = X.shape[1], X.shape[2]
    model = _build_rnn(window, n_features, params["units"], params["dropout"], params["learning_rate"], bidirectional, cfg.random_state)
    model, history = _fit_keras(model, inner_train_X, inner_train_y, inner_val_X, inner_val_y, cfg.rnn_epochs, cfg.rnn_batch_size, cfg.rnn_patience)
    return KerasModelWrapper(model, history)
