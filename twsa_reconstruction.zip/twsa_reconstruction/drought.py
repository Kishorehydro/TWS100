"""
drought.py
==========
Section 9 of the spec: drought-focused validation.

Drought index
-------------
Defined directly from the GRACE-observed TWSA series at each grid cell
(not from precipitation/SPI), because the spec asks for an index
"appropriate to the study area and AVAILABLE OBSERVATIONS", and the
observation this workflow is ultimately scored against is TWSA itself:

  1. 3-month trailing (not centered) rolling mean of observed TWSA, so the
     index at month t never uses information from after month t.
  2. Standardized anomaly: z(t) = (smoothed(t) - mean(smoothed)) /
     std(smoothed), computed ONLY over months with an actual GRACE
     observation (never over the 1948-2002 / pre-GRACE reconstructed
     period -- see the explicit guard in `compute_drought_index`).
  3. Drought months: z(t) <= drought_threshold_std (default -1.0).
  4. Drought EVENTS: maximal runs of consecutive drought months of length
     >= min_event_length_months.

Leave-one-drought-out validation -- feasibility note
-----------------------------------------------------
The spec allows "leave-one-drought-period-out... where feasible" and asks
to "report the limitation transparently" otherwise. Literally retraining
every one of RF/ANN/LSTM/BiLSTM/linear-regression, separately excluding
each drought event, at every one of thousands of grid cells, is not
computationally tractable here and would multiply the already-heavy
section 8 training cost by the number of drought events. Instead:

  Drought-period metrics are computed from the SAME out-of-fold (temporal
  CV) and final-test predictions already produced in validation.py. By
  construction, every one of those predictions is for a month the
  corresponding model never saw in training (that is what section 8's
  rolling-origin split guarantees) -- so any drought event that falls
  inside a validation or final-test window is automatically evaluated
  with a model that was never trained on it. This satisfies the spec's
  actual requirement ("keep drought-event selection and model decisions
  independent of the corresponding evaluation observations") without a
  combinatorial retraining pass per event. This substitution is stated
  here explicitly rather than silently presented as literal
  leave-one-drought-out retraining.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

import numpy as np
import pandas as pd

from config import DroughtConfig
from utils import get_logger

log = get_logger()


@dataclass
class DroughtEvent:
    event_id: int
    start: pd.Timestamp
    end: pd.Timestamp
    n_months: int
    min_z: float


def compute_drought_index(observed_twsa: pd.Series, cfg: DroughtConfig) -> pd.DataFrame:
    """
    `observed_twsa` must already be restricted to months with an actual
    GRACE observation (callers should pass df_cell['twsa'].dropna(), not
    any reconstructed/extrapolated series).
    """
    obs = observed_twsa.dropna().sort_index()
    smoothed = obs.rolling(window=cfg.smoothing_window_months, min_periods=cfg.smoothing_window_months).mean()
    mu, sigma = smoothed.mean(), smoothed.std()
    z = (smoothed - mu) / sigma if sigma and np.isfinite(sigma) and sigma != 0 else smoothed * np.nan
    is_drought = z <= cfg.drought_threshold_std

    df = pd.DataFrame({"twsa_observed": obs, "smoothed": smoothed, "z": z, "is_drought": is_drought.fillna(False)})
    log.info("Drought index computed over %d GRACE-observed months (%d flagged as drought months, threshold=%.2f std).",
              len(df), int(df["is_drought"].sum()), cfg.drought_threshold_std)
    return df


def identify_drought_events(drought_df: pd.DataFrame, cfg: DroughtConfig) -> List[DroughtEvent]:
    events = []
    in_event, start_idx = False, None
    times = drought_df.index
    flags = drought_df["is_drought"].values
    event_id = 0

    def _close_event(start_i, end_i):
        nonlocal event_id
        n_months = end_i - start_i + 1
        if n_months >= cfg.min_event_length_months:
            event_id += 1
            seg = drought_df.iloc[start_i:end_i + 1]
            events.append(DroughtEvent(
                event_id=event_id, start=times[start_i], end=times[end_i],
                n_months=n_months, min_z=float(seg["z"].min()),
            ))

    for i, flag in enumerate(flags):
        if flag and not in_event:
            in_event, start_idx = True, i
        elif not flag and in_event:
            _close_event(start_idx, i - 1)
            in_event = False
    if in_event:
        _close_event(start_idx, len(flags) - 1)

    log.info("Identified %d drought event(s) (min length=%d months).", len(events), cfg.min_event_length_months)
    return events


def evaluate_drought_performance(predictions_df: pd.DataFrame, events: List[DroughtEvent]) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    `predictions_df` must have columns [time, model, y_true, y_pred] and
    should be the POOLED out-of-fold (+ final-test) predictions for this
    cell, i.e. every row is already an out-of-sample prediction (see the
    module docstring's feasibility note).

    Returns:
      - per_event_metrics: one row per (event, model)
      - overall_drought_metrics: one row per model, pooled across all
        drought months from all events
    """
    from validation import compute_metrics  # local import to avoid a cycle at module load time

    predictions_df = predictions_df.copy()
    predictions_df["time"] = pd.to_datetime(predictions_df["time"])

    per_event_rows = []
    all_drought_times = set()
    for ev in events:
        ev_mask = (predictions_df["time"] >= ev.start) & (predictions_df["time"] <= ev.end)
        all_drought_times.update(predictions_df.loc[ev_mask, "time"])
        for model_name, sub in predictions_df[ev_mask].groupby("model"):
            m = compute_metrics(sub["y_true"].values, sub["y_pred"].values)
            per_event_rows.append({
                "event_id": ev.event_id, "start": ev.start, "end": ev.end,
                "n_months_event": ev.n_months, "model": model_name, **m,
            })

    overall_mask = predictions_df["time"].isin(all_drought_times)
    overall_rows = []
    for model_name, sub in predictions_df[overall_mask].groupby("model"):
        m = compute_metrics(sub["y_true"].values, sub["y_pred"].values)
        overall_rows.append({"model": model_name, "n_drought_events_covered": len(events), **m})

    return pd.DataFrame(per_event_rows), pd.DataFrame(overall_rows)
