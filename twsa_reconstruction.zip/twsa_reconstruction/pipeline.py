"""
pipeline.py
===========
Main CLI entrypoint. Wires every module together in the order the spec
lays out: load & validate -> regrid & mask -> temporal consistency ->
per-grid-cell feature/model/validation/drought/SHAP/reconstruction loop ->
export every required output.

Usage
-----
    python pipeline.py                      # full run with config.py defaults
    python pipeline.py --max-cells 5        # quick smoke test on 5 grid cells
    python pipeline.py --models baseline,random_forest   # low-memory pass: only these two families
    python pipeline.py --models ann                      # separate run, just ANN
    python pipeline.py --models lstm                      # separate run, just LSTM
    python pipeline.py --models bilstm                    # separate run, just BiLSTM
    python pipeline.py --precip-source GLDAS              # scenario A: GLDAS Rainf_f_tavg only, no IMD
    python pipeline.py --precip-source IMD                # scenario B: IMD precip wherever available, GLDAS fallback
    python pipeline.py --skip-basin-average               # skip STEP 4b (basin-average + sensitivity) entirely
    TWSA_CONFIG_FILE=my_config.yaml python pipeline.py

v3 note: lstm/bilstm removed from the default model set
---------------------------------------------------------
config.py's Config.models_to_run default is now ("baseline",
"random_forest", "ann") -- lstm/bilstm are OFF by default, for every
grid cell AND the basin average (STEP 4b), to cut runtime. The code is
not deleted (pass --models baseline,random_forest,ann,lstm,bilstm, or
edit models_to_run in config.py, to bring them back); see config.py's
comment on models_to_run for the full rationale.

STEP 4: basin-average reconstruction + hyperparameter sensitivity
   (now runs BEFORE the per-grid-cell loop -- see v4 note below)
----------------------------------------------------------------------
Before the per-grid-cell loop, one pseudo-cell is built: an area-
weighted average (see basin_average.py) of every masked grid cell's
predictors and GRACE TWSA into ONE basin-wide monthly series. Two things
are then run on it, for baseline/random_forest/ann only:
  1. The SAME pipeline as any grid cell (rolling-origin CV -> single
     "best" selected hyperparameter -> final test -> 1948-2024
     reconstruction) -- written under outputs/.../13_basin_average/
     using the sentinel coordinate pair (0.0, 0.0), unmistakable against
     the real Godavari grid. This is also where the grid-level
     hyperparameters for STEP 5 come from by default -- see v4 note.
  2. A FIXED-hyperparameter sensitivity comparison across 3 preset
     complexity tiers for random_forest and ann (config.py's
     ModelConfig.rf_sensitivity_configs / ann_sensitivity_configs, no
     tuning) -- for a manuscript figure showing how final-test accuracy
     and the reconstruction change with hyperparameter choice. Basin-
     average-only. Running this once with --precip-source GLDAS and once
     with --precip-source IMD (see above) gives the basin-average
     comparison for both precipitation scenarios.

v4 note: grid cells use FIXED, basin-average-tuned hyperparameters
----------------------------------------------------------------------
Per-fold-per-cell grid search (config.py's rf_param_grid/ann_param_grid)
is the dominant cost of a whole-basin run: by default 18 RF fits + 1
refit, and 8 full Keras ANN trainings + 1 refit, PER FOLD PER CELL.
config.py's Config.grid_cell_hyperparameter_source now defaults to
"basin_average_tuned": STEP 4 (above) tunes ONCE on the cheap, single-
series basin average, and that SAME hyperparameter set is then used
DIRECTLY at every fold of every grid cell in STEP 5 below (see
_resolve_grid_fixed_hyperparameters() and validation.py's
fixed_hyperparameters param), skipping the inner grid search entirely --
collapsing it to 1 RF fit + 1 ANN training per fold per cell. Set
grid_cell_hyperparameter_source="per_cell_tuned" in config.py to restore
the original (slow) per-cell tuning, or "manual" + manual_fixed_
hyperparameters to supply your own fixed values without running the
basin average's tuning at all.

Progress reporting
-------------------
Because a whole-basin run can take a long time, every grid cell logs a
"PROGRESS: cell X/Y done (Z%). ... Elapsed: ... Avg: ...s/cell. Est.
remaining: ..." line as soon as it finishes (see the STEP 5 loop's
`finally` block), and the same line is written to
outputs/.../progress.txt -- so progress can be checked by tailing the
log or just opening that one small file, without scanning megabytes of
log output.

--precip-source and the two precipitation scenarios
-----------------------------------------------------
Every run's output_dir/log_dir is routed into a scenario-labeled
subfolder (outputs/precip_GLDAS/... or outputs/precip_IMD/...) named
after whatever cfg.precipitation_source resolves to for that run (the
CLI flag if given, else config.py's own default). This is deliberate:
running the SAME predictor/target data through the pipeline once with
--precip-source GLDAS and once with --precip-source IMD produces two
COMPLETE, independent output sets (reconstruction NetCDFs, fold metrics,
final-test metrics, hyperparameters, feature selection, SHAP, everything
under STEP 5 below) that can be compared side by side without either run
overwriting the other's files.
  - --precip-source GLDAS: precipitation_final = GLDAS's own
    Rainf_f_tavg for the entire record; the IMD file is never read for
    substitution (see temporal.build_final_precipitation_series).
  - --precip-source IMD: precipitation_final = real IMD observations
    wherever they exist and are within the documented coverage window,
    GLDAS Rainf_f_tavg as the fallback everywhere else (unchanged
    default behavior).

Why --models exists
--------------------
Fitting RF, ANN, LSTM, and BiLSTM for every grid cell in the Godavari
basin in ONE process run keeps building and discarding TensorFlow/Keras
models (a hyperparameter grid's worth per fold per cell, for both the
ANN and the two sequence models) long enough that memory use grows over
the course of a whole-basin run even with the explicit cleanup this
pipeline now does after every model fit (see utils.clear_keras_memory
and models.py). Running each model family as a SEPARATE invocation of
this script keeps any one process's peak memory down to just one family
(plus the always-cheap baselines). export.py merges each run's outputs
into the existing CSVs/NetCDF under cfg.paths.output_dir (keyed by
lat/lon/fold/model) instead of overwriting them, so running
baseline+RF, then ANN, then LSTM, then BiLSTM as four separate commands
accumulates into the SAME final set of output files as one combined run
would have produced -- just with a much smaller memory footprint per run.

Every run, regardless of --models, still only ever touches grid cells
whose centroid falls inside the Godavari river basin polygon
(cfg.paths.study_area_shp) -- see STEP 2 below; --models changes WHICH
MODELS are fit, never WHICH CELLS are modeled.

See README.md for a worked example and for what each output file is.
"""

from __future__ import annotations

import argparse
import sys
import time
import traceback
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import data_io
import spatial
import temporal
import features as feat
import drought as drt
import interpretation as interp
import export as exp
import validation as val
import reconstruction as recon
import basin_average as basin_avg
from config import Config, load_config
from utils import setup_logging, set_global_seed, get_logger, PipelineError, MODEL_GROUPS, clear_keras_memory

log = get_logger()


def parse_args():
    p = argparse.ArgumentParser(description="GRACE TWSA reconstruction pipeline")
    p.add_argument("--max-cells", type=int, default=None, help="Cap the number of grid cells processed (quick test runs).")
    p.add_argument("--skip-shap", action="store_true", help="Skip SHAP computation (it is the slowest optional step).")
    p.add_argument("--skip-drought", action="store_true", help="Skip drought-focused validation.")
    p.add_argument(
        "--skip-basin-average", action="store_true",
        help=(
            "Skip the weighted basin-average reconstruction and the RF/ANN hyperparameter-"
            "sensitivity comparison (STEP 4b; see basin_average.py and config.py's "
            "run_basin_average flag). On by default."
        ),
    )
    p.add_argument(
        "--models", type=str, default=None,
        help=(
            "Comma-separated subset of {baseline, random_forest, ann, lstm, bilstm} to fit this "
            "run (default: all five, i.e. cfg.models_to_run). Run each family in its own "
            "invocation to keep memory use down for a whole-basin run -- see the module "
            "docstring above. Example: --models baseline,random_forest"
        ),
    )
    p.add_argument(
        "--precip-source", type=str, default=None, choices=["GLDAS", "IMD"],
        help=(
            "Which precipitation scenario to run: 'GLDAS' uses only GLDAS's own Rainf_f_tavg "
            "(IMD is never read for substitution); 'IMD' uses real IMD observations wherever "
            "available, GLDAS as the documented fallback (default: whatever config.py's "
            "Config.precipitation_source is set to). Each choice routes this run's outputs into "
            "its own subfolder (outputs/precip_GLDAS/ or outputs/precip_IMD/) so the two "
            "scenarios never overwrite each other -- see the module docstring above."
        ),
    )
    return p.parse_args()


def _parse_models_arg(models_arg: str) -> Tuple[str, ...]:
    requested = tuple(m.strip() for m in models_arg.split(",") if m.strip())
    unknown = [m for m in requested if m not in MODEL_GROUPS]
    if unknown:
        raise PipelineError(
            f"--models: unknown model group(s) {unknown}; choose from {list(MODEL_GROUPS)}."
        )
    if not requested:
        raise PipelineError("--models: no model groups given.")
    return requested


def extract_cell_raw_vars(predictor_ds, cfg: Config, lat: float, lon: float) -> Dict[str, np.ndarray]:
    """
    `predictor_ds` (concatenated predictor_files, with `precipitation_final`
    already blended in -- see temporal.build_final_precipitation_series)
    still carries the ORIGINAL predictor variable names (Rainf_f_tavg,
    Tair_f_inst, ...), as set in data_io.load_predictor_file, plus the
    derived `soil_moisture_total` and `precipitation_final`. Map those
    through cfg.varnames to the canonical keys
    features.build_predictor_target_frame expects.
    """
    vn = cfg.varnames
    cell = predictor_ds.sel(lat=lat, lon=lon)
    out = {
        "precipitation": cell["precipitation_final"].values,
        "temperature": cell[vn.temperature].values,
        "evapotranspiration": cell[vn.evapotranspiration].values,
        "wind_speed": cell[vn.wind_speed].values,
        "soil_moisture_total": cell["soil_moisture_total"].values,
        "shortwave_down": cell[vn.shortwave_down].values,
        "longwave_down": cell[vn.longwave_down].values,
    }
    if vn.humidity_precomputed_var and vn.humidity_precomputed_var in predictor_ds.variables:
        out["humidity_precomputed"] = cell[vn.humidity_precomputed_var].values
    else:
        out["specific_humidity"] = cell[vn.specific_humidity].values
        out["surface_pressure"] = cell[vn.surface_pressure].values
    return out


def build_cell_dataframe(predictor_ds, grace_ds, cfg: Config, lat: float, lon: float) -> pd.DataFrame:
    raw_vars = extract_cell_raw_vars(predictor_ds, cfg, lat, lon)
    time_index = pd.DatetimeIndex(predictor_ds["time"].values)
    df = feat.build_predictor_target_frame(raw_vars, time_index)

    twsa_cell = grace_ds["twsa"].sel(lat=lat, lon=lon)
    twsa_series = pd.Series(twsa_cell.values, index=pd.DatetimeIndex(grace_ds["time"].values))
    df["twsa"] = twsa_series.reindex(df.index)  # NaN outside the GRACE record, by design
    return df


def _resolve_grid_fixed_hyperparameters(cfg: Config, basin_result: Optional["val.CellValidationResult"]) -> Optional[Dict[str, Dict]]:
    """
    v3 speed fix: decide the ONE hyperparameter dict every grid cell will
    use directly at every fold, instead of each cell re-running its own
    per-fold grid search. See config.py's grid_cell_hyperparameter_source.

    Returns None to mean "no fixed hyperparameters -- fall back to each
    cell's own per-fold tuning" (the original, slow behavior).
    """
    source = cfg.grid_cell_hyperparameter_source

    if source == "per_cell_tuned":
        log.info("grid_cell_hyperparameter_source='per_cell_tuned': every grid cell will "
                  "re-tune its own hyperparameters every fold (slow; this is the pre-v3 default).")
        return None

    if source == "manual":
        manual = cfg.manual_fixed_hyperparameters
        if manual:
            log.info("grid_cell_hyperparameter_source='manual': every grid cell will use the "
                      "fixed hyperparameters from config.py's manual_fixed_hyperparameters: %s", manual)
            return manual
        log.warning("grid_cell_hyperparameter_source='manual' but config.py's "
                    "manual_fixed_hyperparameters is empty/None -- falling back to each cell's "
                    "own per-fold tuning.")
        return None

    if source == "basin_average_tuned":
        if basin_result is not None and basin_result.selected_config.get("hyperparameters"):
            fixed = basin_result.selected_config["hyperparameters"]
            log.info(
                "grid_cell_hyperparameter_source='basin_average_tuned': every grid cell will use "
                "these basin-average-tuned hyperparameters DIRECTLY at every fold (no per-cell grid "
                "search) -- this is the dominant per-cell cost and removing it is the main runtime "
                "win: %s", fixed,
            )
            return fixed
        if cfg.manual_fixed_hyperparameters:
            log.warning(
                "grid_cell_hyperparameter_source='basin_average_tuned' but the basin average "
                "produced no usable hyperparameters (run_basin_average=False, or basin tuning "
                "failed/was skipped) -- falling back to config.py's manual_fixed_hyperparameters: %s",
                cfg.manual_fixed_hyperparameters,
            )
            return cfg.manual_fixed_hyperparameters
        log.warning(
            "grid_cell_hyperparameter_source='basin_average_tuned' but the basin average produced "
            "no usable hyperparameters (run_basin_average=False, or basin tuning failed/was "
            "skipped), and no manual_fixed_hyperparameters fallback is set -- falling back to each "
            "grid cell's own (slow) per-fold tuning instead of silently using nothing.",
        )
        return None

    log.warning("Unknown grid_cell_hyperparameter_source=%r -- falling back to each grid cell's "
                "own per-fold tuning.", source)
    return None


def _format_duration(seconds: float) -> str:
    seconds = max(0, int(seconds))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}h{m:02d}m{s:02d}s"
    if m:
        return f"{m}m{s:02d}s"
    return f"{s}s"


def run_pipeline(
    cfg: Config, max_cells: int = None, skip_shap: bool = False, skip_drought: bool = False,
    models_to_run: Tuple[str, ...] = None, run_basin_average: bool = None,
) -> None:
    models_to_run = tuple(models_to_run) if models_to_run else tuple(cfg.models_to_run)
    run_basin_average = cfg.run_basin_average if run_basin_average is None else run_basin_average
    setup_logging(cfg.paths.log_dir, cfg.log_level)
    set_global_seed(cfg.random_seed)
    outdirs = cfg.paths.subdirs()
    log.info("Model families this run: %s", list(models_to_run))
    log.info(
        "Precipitation scenario this run: precipitation_source=%s. Outputs -> %s, logs -> %s",
        cfg.precipitation_source, cfg.paths.output_dir, cfg.paths.log_dir,
    )

    log.info("=" * 80)
    log.info("STEP 1: Loading and validating inputs")
    log.info("=" * 80)
    grace_ds = data_io.load_grace_jpl(cfg)
    predictor_datasets = data_io.load_all_predictor_files(cfg)
    imd_ds = data_io.load_imd_precipitation(cfg)
    study_area = data_io.load_study_area(cfg)
    grid_diag_df = data_io.report_input_differences(
        grace_ds, {f"file{i}": ds for i, ds in enumerate(predictor_datasets)}, cfg,
    )
    grid_diag_df.to_csv(outdirs["forcing_consistency"] / "input_grid_diagnostics.csv", index=False)

    log.info("=" * 80)
    log.info("STEP 2: Spatial alignment and polygon masking")
    log.info("=" * 80)
    # v2: predictor_files are assumed already regridded onto the GRACE grid
    # (cfg.predictors_already_on_grace_grid) -- we only VERIFY that here,
    # we do not regrid. If that assumption is ever wrong for one of your
    # files, this raises a clear PipelineError rather than silently
    # training on misaligned grid cells.
    if cfg.predictors_already_on_grace_grid:
        for i, ds in enumerate(predictor_datasets):
            spatial.verify_spatial_alignment(ds, grace_ds, f"predictor_file_{i}")
    else:
        predictor_datasets = [
            spatial.regrid_predictor_dataset(ds, grace_ds, f"predictor_file_{i}")
            for i, ds in enumerate(predictor_datasets)
        ]

    # IMD precipitation: regridded onto the GRACE grid unless already there.
    if imd_ds is not None:
        if cfg.imd_already_on_grace_grid:
            spatial.verify_spatial_alignment(imd_ds, grace_ds, "IMD_precipitation")
        else:
            imd_ds = spatial.regrid_to_grace_grid(imd_ds, grace_ds["lat"], grace_ds["lon"])
            spatial.verify_spatial_alignment(imd_ds, grace_ds, "IMD_precipitation")

    mask, overlap_df = spatial.build_cell_mask(grace_ds["lat"].values, grace_ds["lon"].values, study_area)
    overlap_df.to_csv(outdirs["root"] / "study_area_cell_overlap_diagnostics.csv", index=False)
    grace_masked = spatial.apply_mask_to_dataset(grace_ds, mask)
    predictor_datasets_masked = [spatial.apply_mask_to_dataset(ds, mask) for ds in predictor_datasets]
    imd_masked = spatial.apply_mask_to_dataset(imd_ds, mask) if imd_ds is not None else None

    log.info("=" * 80)
    log.info("STEP 3: Temporal consistency -- concatenation and precipitation-source blending")
    log.info("=" * 80)
    # v2: NO bias correction here -- predictor_datasets are assumed already
    # bias-corrected/unit-consistent (see config.py). Just concatenate.
    predictor_ds = temporal.concatenate_predictor_files(predictor_datasets_masked)
    humidity_sources = sorted({ds.attrs.get("humidity_source_var", "unknown") for ds in predictor_datasets})
    provenance_df = pd.DataFrame([{
        "predictor_files": " | ".join(cfg.paths.predictor_files),
        "note": predictor_ds.attrs.get("concatenation_note", ""),
        "bias_correction_applied_by_pipeline": False,
        "regridding_applied_by_pipeline": not cfg.predictors_already_on_grace_grid,
        "humidity_predictor_source": " | ".join(humidity_sources),
        "humidity_predictor_is_true_relative_humidity": bool(cfg.varnames.humidity_precomputed_var is None),
        "assumption": "predictor_files are already bias-corrected across any GLDAS-2.0/2.1-style "
                       "forcing boundary, already in consistent units, and (unless the flag above "
                       "is True) already on the GRACE grid -- all done upstream by the user. The "
                       "'humidity' predictor is documented above rather than assumed to be true "
                       "relative humidity -- see humidity_predictor_source.",
    }])
    exp.export_predictor_provenance(provenance_df, outdirs["forcing_consistency"])

    missing_report = temporal.missing_data_report(predictor_ds)
    missing_report.to_csv(outdirs["diagnostics"] / "predictor_missing_data_report.csv", index=False)

    full_recon_index = pd.date_range(cfg.temporal.reconstruction_start, cfg.temporal.reconstruction_end, freq="MS")
    precip_result = temporal.build_final_precipitation_series(cfg, predictor_ds, imd_masked, full_recon_index)
    predictor_ds = predictor_ds.assign(precipitation_final=precip_result["precipitation"])
    exp.export_precipitation_source_table(precip_result["source_table"], outdirs["precip_comparison"])

    basin_result = None
    basin_recon = None
    basin_sensitivity = None
    if run_basin_average:
        log.info("=" * 80)
        log.info("STEP 4: Basin-average reconstruction (weighted whole-study-area series) "
                  "+ RF/ANN hyperparameter-sensitivity comparison -- runs BEFORE the per-grid-cell "
                  "loop so its tuned hyperparameters can be reused there (v3 speed fix)")
        log.info("=" * 80)
        basin_models_to_run = tuple(m for m in models_to_run if m not in ("lstm", "bilstm"))
        weights_df = basin_avg.compute_cell_weights(grace_masked["lat"].values, grace_masked["lon"].values, mask, overlap_df)
        df_basin = basin_avg.build_basin_average_dataframe(predictor_ds, grace_masked, weights_df, cfg)

        basin_result = val.run_cell_validation(df_basin, cfg, basin_avg.BASIN_LAT, basin_avg.BASIN_LON, models_to_run=basin_models_to_run)
        basin_recon = recon.reconstruct_cell(df_basin, basin_result.selected_config, cfg, basin_avg.BASIN_LAT, basin_avg.BASIN_LON, models_to_run=basin_models_to_run)

        basin_tagged = [((basin_avg.BASIN_LAT, basin_avg.BASIN_LON), basin_result)]
        exp.export_fold_metrics(basin_tagged, outdirs["basin_average"])
        exp.export_oof_predictions(basin_tagged, outdirs["basin_average"])
        exp.export_final_test(basin_tagged, outdirs["basin_average"])
        exp.export_hyperparameters(basin_tagged, outdirs["basin_average"])
        exp.export_feature_selection(basin_tagged, outdirs["basin_average"])
        exp.export_correlation_matrices(basin_tagged, outdirs["basin_average"])
        exp.export_normalization_diagnostics(basin_tagged, outdirs["basin_average"])
        if len(basin_recon.reconstructed):
            exp.export_reconstruction_netcdf(
                [basin_recon], np.array([basin_avg.BASIN_LAT]), np.array([basin_avg.BASIN_LON]), cfg, outdirs["basin_average"],
            )
        else:
            log.warning("Basin-average 'best hyperparameter' reconstruction produced no output; "
                        "skipping its NetCDF export (see basin-average diagnostics/notes above).")

        basin_sensitivity = basin_avg.run_hparam_sensitivity(df_basin, cfg)
        exp.export_hparam_sensitivity_metrics(basin_sensitivity["metrics"], outdirs["basin_average"])
        exp.export_hparam_sensitivity_reconstruction(basin_sensitivity["reconstruction"], outdirs["basin_average"])
        log.info("STEP 4 complete. Basin-average outputs written under: %s", outdirs["basin_average"])

    # v3 speed fix: decide ONCE, here, what hyperparameters every grid cell
    # below will use. Default ("basin_average_tuned") reuses the basin-
    # average's own tuned hyperparameters directly at every fold of every
    # grid cell, skipping each cell's own per-fold grid search entirely --
    # see config.py's grid_cell_hyperparameter_source and validation.py's
    # fixed_hyperparameters param.
    fixed_hparams_for_grid = _resolve_grid_fixed_hyperparameters(cfg, basin_result)

    log.info("=" * 80)
    log.info("STEP 5: Per-grid-cell modeling")
    log.info("=" * 80)
    lats = grace_masked["lat"].values
    lons = grace_masked["lon"].values
    lat_lon_pairs = [(float(lats[i]), float(lons[j])) for i, j in np.argwhere(mask)]
    log.info(
        "Study-area restriction in effect: only grid-cell centroids falling inside '%s' "
        "(%s) are modeled -- %d of %d total GRACE grid cells qualify. This restriction is "
        "independent of --models and applies on every run.",
        Path(cfg.paths.study_area_shp).stem, cfg.paths.study_area_shp, len(lat_lon_pairs), mask.size,
    )
    if max_cells is not None:
        lat_lon_pairs = lat_lon_pairs[:max_cells]
        log.info("max_cells set: processing only the first %d cell(s).", len(lat_lon_pairs))

    validation_results: List[Tuple[Tuple[float, float], val.CellValidationResult]] = []
    reconstruction_results: List[recon.CellReconstruction] = []
    shap_records: List[Dict] = []
    drought_records: List[Dict] = []
    skipped_cells: List[Dict] = []

    n_total_cells = len(lat_lon_pairs)
    loop_start_time = time.time()
    progress_path = outdirs["root"] / "progress.txt"

    for cell_i, (lat, lon) in enumerate(lat_lon_pairs, start=1):
        cell_start_time = time.time()
        log.info("--- Cell %d/%d: lat=%.3f lon=%.3f ---", cell_i, n_total_cells, lat, lon)
        try:
            df_cell = build_cell_dataframe(predictor_ds, grace_masked, cfg, lat, lon)
            predictor_cols = [c for c in df_cell.columns if c != "twsa"]
            non_null_counts = {c: int(df_cell[c].notna().sum()) for c in predictor_cols}
            n_obs = df_cell["twsa"].notna().sum()
            log.info(
                "[%.3f, %.3f] Data extracted: %d months [%s..%s]. GRACE-observed TWSA months: %d/%d. "
                "Predictor non-null counts: %s",
                lat, lon, len(df_cell), df_cell.index.min().date(), df_cell.index.max().date(),
                int(n_obs), len(df_cell), non_null_counts,
            )
            if n_obs < cfg.features.min_training_months:
                log.warning("[%.3f, %.3f] Skipped: only %d GRACE-observed months (need >= %d).",
                             lat, lon, n_obs, cfg.features.min_training_months)
                skipped_cells.append({"lat": lat, "lon": lon, "message": f"Only {n_obs} GRACE-observed months; skipped."})
                continue

            cell_result = val.run_cell_validation(
                df_cell, cfg, lat, lon, models_to_run=models_to_run, fixed_hyperparameters=fixed_hparams_for_grid,
            )
            validation_results.append(((lat, lon), cell_result))

            cell_recon = recon.reconstruct_cell(df_cell, cell_result.selected_config, cfg, lat, lon, models_to_run=models_to_run)
            reconstruction_results.append(cell_recon)

            if not skip_drought:
                observed = df_cell["twsa"].dropna()
                if len(observed) >= cfg.drought.smoothing_window_months + cfg.drought.min_event_length_months:
                    drought_df = drt.compute_drought_index(observed, cfg.drought)
                    events = drt.identify_drought_events(drought_df, cfg.drought)
                    if events:
                        pooled_preds = pd.DataFrame(cell_result.oof_predictions + [
                            {"fold": "final_test", "time": r["time"], "model": r["model"], "y_true": r["y_true"], "y_pred": r["y_pred"]}
                            for r in cell_result.final_test_predictions
                        ])
                        if len(pooled_preds):
                            per_event, overall = drt.evaluate_drought_performance(pooled_preds, events)
                            drought_records.append({"lat": lat, "lon": lon, "events": events,
                                                     "per_event_metrics": per_event, "overall_metrics": overall})

            if not skip_shap and cell_result.selected_config.get("hyperparameters"):
                try:
                    shap_records.extend(_compute_cell_shap(df_cell, cell_result, cfg, lat, lon, models_to_run=models_to_run))
                except Exception as exc:  # pragma: no cover - SHAP is best-effort
                    log.warning("SHAP failed for cell (%.3f, %.3f): %s", lat, lon, exc)

        except Exception as exc:
            log.error("Cell (%.3f, %.3f) failed: %s", lat, lon, exc)
            log.debug(traceback.format_exc())
            skipped_cells.append({"lat": lat, "lon": lon, "message": f"Exception: {exc}"})

        finally:
            # Release this cell's dataframes/arrays and any lingering
            # TF/Keras graph state before moving to the next cell -- with
            # potentially thousands of cells in the Godavari basin, even a
            # modest per-cell residual adds up over a whole-basin run.
            clear_keras_memory()

            # --- Progress reporting (so a whole-basin run can be monitored
            # without guessing) ---
            now = time.time()
            elapsed = now - loop_start_time
            avg_per_cell = elapsed / cell_i
            remaining_cells = n_total_cells - cell_i
            eta_seconds = avg_per_cell * remaining_cells
            pct_done = 100.0 * cell_i / n_total_cells if n_total_cells else 100.0
            progress_line = (
                f"PROGRESS: cell {cell_i}/{n_total_cells} done ({pct_done:.1f}%). "
                f"This cell took {_format_duration(now - cell_start_time)}. "
                f"Elapsed: {_format_duration(elapsed)}. Avg: {avg_per_cell:.1f}s/cell. "
                f"Est. remaining: {_format_duration(eta_seconds)} "
                f"({len(validation_results)} modeled, {len(skipped_cells)} skipped so far)."
            )
            log.info(progress_line)
            try:
                progress_path.write_text(progress_line + "\n")
            except OSError as exc:  # pragma: no cover - progress file is best-effort
                log.debug("Could not write progress.txt: %s", exc)

    log.info("=" * 80)
    log.info("STEP 6: Exporting all required outputs")
    log.info("=" * 80)
    exp.export_fold_metrics(validation_results, outdirs["validation"])
    exp.export_oof_predictions(validation_results, outdirs["validation"])
    exp.export_final_test(validation_results, outdirs["final_test"])
    exp.export_hyperparameters(validation_results, outdirs["hyperparams"])
    exp.export_feature_selection(validation_results, outdirs["feature_selection"])
    exp.export_correlation_matrices(validation_results, outdirs["correlation"])
    exp.export_normalization_diagnostics(validation_results, outdirs["normalization"])
    exp.export_model_diagnostics(validation_results, skipped_cells, outdirs["diagnostics"])
    if shap_records:
        exp.export_shap_results(shap_records, outdirs["shap"])
    if drought_records:
        exp.export_drought_results(drought_records, outdirs["drought"])
    if reconstruction_results:
        exp.export_reconstruction_netcdf(reconstruction_results, grace_masked["lat"].values, grace_masked["lon"].values, cfg, outdirs["reconstruction"])

    log.info("Pipeline complete. %d cell(s) modeled, %d cell(s) skipped.", len(validation_results), len(skipped_cells))


def _compute_cell_shap(
    df_cell, cell_result: val.CellValidationResult, cfg: Config, lat: float, lon: float,
    models_to_run: Tuple[str, ...] = MODEL_GROUPS,
) -> List[Dict]:
    """Re-fits each tuned model family on the development period (same data
    SHAP is allowed to see, per spec section 11) purely to obtain a model
    object to explain -- this refit does not alter any reported metric."""
    import models as mdl
    import preprocessing as prep

    records = []
    hparams = cell_result.selected_config.get("hyperparameters", {})
    retained = cell_result.selected_config.get("retained_features")
    if not hparams or not retained:
        log.info("[%.3f, %.3f] SHAP skipped: no hyperparameters/retained features selected during validation.", lat, lon)
        return records
    log.info("[%.3f, %.3f] Starting SHAP analysis for model families: %s (features: %s)",
              lat, lon, list(hparams.keys()), retained)

    X_tab_all, y_tab_all = feat.make_tabular_dataset(df_cell, lags=cfg.features.lags_tabular)
    dev_mask = (X_tab_all.index >= pd.Timestamp(cfg.temporal.grace_development_start)) & \
               (X_tab_all.index <= pd.Timestamp(cfg.temporal.grace_development_end)) & y_tab_all.notna()
    X_dev, y_dev = X_tab_all.loc[dev_mask, retained], y_tab_all.loc[dev_mask]
    if len(X_dev) < cfg.features.min_training_months:
        return records

    scaler = prep.FoldScaler().fit(X_dev, y_dev)
    X_dev_s, _ = scaler.transform_X(X_dev)
    y_dev_s = scaler.transform_y(y_dev)

    # Each model's SHAP computation is guarded independently so one model's
    # failure (e.g. a SHAP/TensorFlow version mismatch) does not discard
    # results already obtained for the others.
    if "random_forest" in hparams:
        try:
            rf = mdl.fit_rf_with_params(X_dev_s, y_dev_s, hparams["random_forest"], cfg.models.random_state)
            res = interp.shap_for_random_forest(rf, X_dev_s, retained)
            records.append({"lat": lat, "lon": lon, "model": "random_forest", **res})
            top = res["variable_importance"].head(5).round(4).to_dict()
            log.info("[%.3f, %.3f] SHAP (random_forest, %s, %d samples) top features by mean |SHAP|: %s",
                      lat, lon, res["method"], res["n_samples_explained"], top)
            del rf
        except Exception as exc:  # pragma: no cover - best-effort interpretability
            log.warning("SHAP (random_forest) failed for cell (%.3f, %.3f): %s", lat, lon, exc)

    if "ann" in hparams:
        try:
            n_inner_val = max(6, int(0.2 * len(X_dev_s)))
            n_inner_val = min(n_inner_val, len(X_dev_s) - 1)
            if n_inner_val > 0:
                ann = mdl.fit_ann_with_params(X_dev_s.values, y_dev_s.values, hparams["ann"], cfg.models, n_inner_val)
                res = interp.shap_for_ann(ann, X_dev_s.values, retained)
                records.append({"lat": lat, "lon": lon, "model": "ann", **res})
                top = res["variable_importance"].head(5).round(4).to_dict()
                log.info("[%.3f, %.3f] SHAP (ann, %s, %d samples) top features by mean |SHAP|: %s",
                          lat, lon, res["method"], res["n_samples_explained"], top)
                del ann
        except Exception as exc:  # pragma: no cover
            log.warning("SHAP (ann) failed for cell (%.3f, %.3f): %s", lat, lon, exc)
        finally:
            clear_keras_memory()

    X_seq_all, y_seq_all, channel_names = feat.make_sequence_dataset(
        df_cell, window=cfg.features.lookback_window, include_target_month=cfg.features.sequence_includes_target_month,
    )
    seq_dev_mask = (y_seq_all.index >= pd.Timestamp(cfg.temporal.grace_development_start)) & \
                   (y_seq_all.index <= pd.Timestamp(cfg.temporal.grace_development_end)) & y_seq_all.notna()
    X_seq_dev, y_seq_dev = X_seq_all[seq_dev_mask.values], y_seq_all.loc[seq_dev_mask]
    # NOTE: gated on EITHER family being present, not just "lstm" -- a run
    # that only requested --models bilstm has "bilstm" in hparams but not
    # "lstm", and previously this whole block (including bilstm SHAP) was
    # skipped in that case. Each family is still fit/explained/cleaned up
    # independently below.
    seq_shap_models = [m for m in ("lstm", "bilstm") if m in hparams]
    if seq_shap_models and len(X_seq_dev) >= cfg.features.min_training_months:
        seq_scaler_tgt = prep.FoldScaler().fit(pd.DataFrame({"twsa": y_seq_dev.values}), y_seq_dev)
        y_seq_dev_s = seq_scaler_tgt.transform_y(y_seq_dev)
        seq_scaler = prep.SequenceScaler().fit(X_seq_dev)
        X_seq_dev_s, _ = seq_scaler.transform(X_seq_dev)
        n_inner_val_seq = max(6, int(0.2 * len(X_seq_dev_s)))
        n_inner_val_seq = min(n_inner_val_seq, len(X_seq_dev_s) - 1)
        if n_inner_val_seq > 0:
            for model_name in seq_shap_models:
                try:
                    m_shap = mdl.fit_rnn_with_params(
                        X_seq_dev_s, y_seq_dev_s.values, hparams[model_name], cfg.models,
                        n_inner_val_seq, bidirectional=(model_name == "bilstm"),
                    )
                    res_seq = interp.shap_for_sequence_model(m_shap, X_seq_dev_s, channel_names)
                    records.append({"lat": lat, "lon": lon, "model": model_name, **res_seq})
                    log.info("[%.3f, %.3f] SHAP (%s, %s, %d samples) top channels by mean |SHAP|: %s; "
                              "top lookback steps: %s", lat, lon, model_name, res_seq["method"], res_seq["n_samples_explained"],
                              res_seq["variable_importance"].head(5).round(4).to_dict(),
                              res_seq["timestep_importance"].sort_values(ascending=False).head(5).round(4).to_dict())
                    del m_shap
                except Exception as exc:  # pragma: no cover
                    log.warning("SHAP (%s) failed for cell (%.3f, %.3f): %s", model_name, lat, lon, exc)
                finally:
                    clear_keras_memory()

    return records


if __name__ == "__main__":
    args = parse_args()
    cfg = load_config()
    if args.max_cells is not None:
        cfg.max_grid_cells = args.max_cells
    if args.precip_source is not None:
        cfg.precipitation_source = args.precip_source
    models_to_run = _parse_models_arg(args.models) if args.models else tuple(cfg.models_to_run)

    # Route this run's outputs/logs into a scenario-labeled subfolder so
    # that running once with --precip-source GLDAS and once with
    # --precip-source IMD never overwrites either run's results -- see
    # the module docstring's "--precip-source and the two precipitation
    # scenarios" section. This only affects the CLI entrypoint (not
    # run_pipeline() called directly, e.g. from tests/test_smoke.py,
    # which keeps full control over cfg.paths.output_dir/log_dir).
    scenario_label = f"precip_{cfg.precipitation_source.upper()}"
    cfg.paths.output_dir = str(Path(cfg.paths.output_dir) / scenario_label)
    cfg.paths.log_dir = str(Path(cfg.paths.log_dir) / scenario_label)
    print(f"Precipitation scenario: {cfg.precipitation_source} -> outputs in {cfg.paths.output_dir}")

    try:
        run_pipeline(cfg, max_cells=cfg.max_grid_cells, skip_shap=args.skip_shap, skip_drought=args.skip_drought,
                     models_to_run=models_to_run, run_basin_average=not args.skip_basin_average)
    except PipelineError as exc:
        log.error("Pipeline aborted: %s", exc)
        sys.exit(1)
